
import { execSync } from 'child_process';

const name = process.argv[2];
if (!name) {
  console.error('❌ Please provide a migration name, e.g. npm run migration:generate AddRolesTable');
  process.exit(1);
}

execSync(
  `npm run build && npx typeorm migration:generate ./src/migrations/${name} -d ./dist/data-source.js`,
  { stdio: 'inherit' }
);

// // migration-create.js
// const { execSync } = require('child_process');

// // Get migration name from CLI argument
// const name = process.argv[2];

// if (!name) {
//   console.error('\n❌ Please provide a migration name.');
//   console.error('👉 Example: npm run migration:create add_users_table\n');
//   process.exit(1);
// }

// // Generate timestamp prefix YYYYMMDDHHMMSS
// const timestamp = new Date()
//   .toISOString()
//   .replace(/[-:TZ.]/g, '')
//   .slice(0, 14);

// const fileName = `${name}`;

// console.log(`\n🛠️ Creating migration file: ${fileName}.ts\n`);

// try {
//   execSync(`npx typeorm migration:create src/migrations/${fileName}`, {
//     stdio: 'inherit',
//   });

//   console.log(`\n✅ Migration created successfully: src/migrations/${fileName}.ts\n`);
// } catch (err) {
//   console.error('\n❌ Error creating migration:', err.message);
//   process.exit(1);
// }

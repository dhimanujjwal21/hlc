import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToMany,
  OneToMany,
} from 'typeorm';
import { User } from './users.entity';
import { UserHlc } from './user-hlc.entity';

@Entity('t_hlc')
export class Hlc {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'slug', type: 'varchar', length: 150, unique: true })
  slug: string;

  @Column({ name: 'name', type: 'varchar', length: 500 })
  name: string;

  @OneToMany(() => UserHlc, (userHlc) => userHlc.hlc)
  userHlcs: UserHlc[];

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

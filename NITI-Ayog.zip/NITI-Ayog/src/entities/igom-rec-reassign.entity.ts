import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Unique,
  OneToMany,
} from 'typeorm';
import { Departments } from './departments.entity';
import { Ministry } from './ministry.entity';
import { Hlc } from './hlc.entity';
import { RecommendationFile } from './recommendation-file.entity';
import { RecommendationUpdates } from './recommendation-updates.entity';
import { ClosureStatusEnum } from 'src/constants/enums';
import { User } from './users.entity';
import { Igom } from './igom.entity';
import { IgomRecommendationUpdates } from './igom-recommendation-updates.entity';
import { IgomRecommendation } from './igom-recommendation.entity';

@Entity('t_igom_rec_reassign')
export class IgomRecReassign {
  @PrimaryGeneratedColumn()
  id!: number;

  @ManyToOne(() => Igom, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'igom_id' })
  igom?: Igom | null;

  @ManyToOne(() => IgomRecommendation, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'prev_igom_rec_id' })
  prevIgomRecommendation!: IgomRecommendation;


  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'prev_department_id' })
  prevDepartment?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'prev_ministry_id' })
  prevMinistry?: Ministry | null;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'current_department_id' })
  currentDepartment?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'current_ministry_id' })
  currentMinistry?: Ministry | null;


  @Column({
    name: 'reassign_status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  status?: string;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'reassign_user_id' })
  reassignedBy?: User | null;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'review_user_id' })
  reviewdBy?: User | null;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt!: Date;

  @Column({
    name: 'reviewed_at',
    type: 'timestamp',
    nullable: true,
    default: null,
  })
  reviewedAt?: Date | null;

  @Column({
    name: 'reassign_reason',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  reason?: string;

  @Column({
    name: 'remarks',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  remarks: string | null;
}

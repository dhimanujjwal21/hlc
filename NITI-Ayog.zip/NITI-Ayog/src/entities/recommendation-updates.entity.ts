import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { User } from './users.entity';
import { Recommendation } from './recommendation.entity';

@Entity('t_recommendation_updates')
export class RecommendationUpdates {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Recommendation, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'recommendation_id' })
  recommendation: Recommendation;

  @Column({ name: 'reason_not_implemented', type: 'text', nullable: true })
  reasonNotImplemented?: string | null;

  @Column({
    name: 'status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  status?: string;

  @Column({ name: 'action_taken_by_ministry', type: 'text', nullable: true })
  actionTakenByMinistry?: string;

  @Column({ type: 'text', nullable: true })
  remark?: string;

  @Column({ name:'ministry_approver_status', type: 'varchar', nullable: true })
  ministryApproverStatus?: string;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'user_id' })
  user?: User | null;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

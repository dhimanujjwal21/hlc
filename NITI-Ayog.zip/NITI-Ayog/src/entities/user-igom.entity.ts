import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  Unique,
} from 'typeorm';
import { User } from './users.entity';
import { Igom } from './igom.entity';

@Entity('t_user_igom')
@Unique(['user', 'igom']) // prevent duplicate entries
export class UserIgom {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, (user) => user.userIgoms, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Igom, (igom) => igom.userIgom, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'igom_id' })
  igom: Igom;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;
}

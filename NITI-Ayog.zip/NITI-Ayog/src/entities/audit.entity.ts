import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('t_audit_logs')
export class AuditLogs {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'user_id', type: 'int', nullable: true })
  userId: number;

  @Column({ name: 'method', type: 'varchar', length: 50 })
  method: string;

  @Column({ name: 'route', type: 'varchar', length: 255, nullable: true })
  route: string;

  @Column({ name: 'params', type: 'json', nullable: true })
  params: Record<string, any>;

  @Column({ name: 'query', type: 'json', nullable: true })
  query: Record<string, any>;

  @Column({ name: 'body', type: 'json', nullable: true })
  body: Record<string, any>;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  createdAt: Date;
}

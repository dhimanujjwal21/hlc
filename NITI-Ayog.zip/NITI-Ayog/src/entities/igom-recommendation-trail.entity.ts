import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { User } from './users.entity';
import { IgomRecommendation } from './igom-recommendation.entity';

@Entity('t_igom_recommendation_trail')
export class IgomRecommendationTrail {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => IgomRecommendation, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'igom_recommendation_id' })
  igomRecommendation?: IgomRecommendation | null;

  @Column({ name: 'current_status', type: 'varchar', length: 100 })
  currentStatus?: string | null;

  @Column({ name: 'next_status', type: 'varchar', length: 100 })
  nextStatus: string | null;

  @Column({ name: 'user_name', type: 'varchar', length: 100 })
  userName!: string | null;

  @Column({ name: 'user_email', type: 'varchar', length: 100 })
  userEmail!: string | null;

  @Column({ name: 'user_role', type: 'varchar', length: 100 })
  userRole!: string | null;

  @Column({ name: 'route', type: 'varchar', length: 255, nullable: true })
  route: string;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'user_id' })
  user?: User | null;

  @Column({ type: 'text', nullable: true })
  description?: string | null;

  @Column({ name: 'other_details', type: 'json', nullable: true })
  otherDetails?: Record<string, any>;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  createdAt: Date;
}

import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    Index,
    ManyToOne,
    JoinColumn,
} from 'typeorm';
import { Departments } from './departments.entity';
import { Ministry } from './ministry.entity';

export enum NotificationTypeEnum {
    OVERDUE_RECOMMENDATION = 'OVERDUE_RECOMMENDATION',
}

export enum NotificationChannelEnum {
    EMAIL = 'email',
    SMS = 'sms',
    BOTH = 'both',
}

export enum NotificationStatusEnum {
    SENT = 'SENT',
    FAILED = 'FAILED',
}

@Entity('t_notification_logs')
export class NotificationLog {
    @PrimaryGeneratedColumn()
    id: string;

    @Column({ type: 'varchar', name: 'batch_key' })
    batchKey: string;

    @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
    @JoinColumn({ name: 'department_id' })
    department?: Departments | null;

    @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
    @JoinColumn({ name: 'ministry_id' })
    ministry?: Ministry | null;

    @Column({ type: 'varchar' })
    type: string;

    @Column({ type: 'varchar' })
    channel: string;

    @Column({ type: 'varchar' })
    status: string;

    @Column({ type: 'date', name: 'notification_date' })
    notificationDate: string;

    @Column({ type: 'int', nullable: true, name: 'recommendation_count' })
    recommendationCount?: number;

    @Column({ type: 'text', nullable: true })
    error?: string;

    @CreateDateColumn({
        name: 'created_at',
        type: 'timestamp',
        precision: 0,
        default: () => 'CURRENT_TIMESTAMP',
    })
    createdAt: Date;
}

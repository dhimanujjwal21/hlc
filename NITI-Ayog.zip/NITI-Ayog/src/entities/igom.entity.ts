import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToMany,
  OneToMany,
  Unique,
} from 'typeorm';
import { UserIgom } from './user-igom.entity';

@Entity('t_igom')
export class Igom {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'slug', type: 'varchar', length: 150, unique: true })
  slug: string;

  @Column({ name: 'name', type: 'varchar', length: 500 })
  name: string;

  @OneToMany(() => UserIgom, (userIgom) => userIgom.igom)
  userIgom: UserIgom[];

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

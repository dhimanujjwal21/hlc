import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Unique,
  OneToMany,
} from 'typeorm';
import { Departments } from './departments.entity';
import { Ministry } from './ministry.entity';
import { Hlc } from './hlc.entity';
import { RecommendationFile } from './recommendation-file.entity';
import { RecommendationUpdates } from './recommendation-updates.entity';
import { ClosureStatusEnum } from 'src/constants/enums';
import { User } from './users.entity';
import { Igom } from './igom.entity';
import { IgomRecommendationUpdates } from './igom-recommendation-updates.entity';

@Entity('t_igom_recommendation')
@Unique(['recommendationSlug', 'department', 'ministry'])
export class IgomRecommendation {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Igom, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'igom_id' })
  igom?: Igom | null;

  @Column({
    name: 'recommendation_slug',
    type: 'varchar',
    length: 100,
  })
  recommendationSlug: string;

  @Column({
    nullable: true,
    name: 'implementing_agency',
    type: 'varchar',
  })
  implementingAgency?: string;

  @Column({
    name: 'report_number',
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  reportNumber?: string;

  @Column({ type: 'text', nullable: true })
  name: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_department_id' })
  primaryDepartment?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_ministry_id' })
  primaryMinistry?: Ministry | null;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'department_id' })
  department?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'ministry_id' })
  ministry?: Ministry | null;

  @Column({ name: 'timeline', type: 'timestamp', precision: 0, nullable: true })
  timeline?: Date;

  @Column({
    name: 'meeting_date',
    type: 'timestamp',
    precision: 0,
    nullable: true,
  })
  meetingDate?: Date;

  @Column({
    name: 'proposal_nature',
    type: 'text',
    nullable: true,
  })
  proposalNature!: string;

  @Column({
    name: 'budgetary_category',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  budgetaryCategory!: string;

  @Column({ name: 'niti_approved', type: 'boolean', default: false })
  nitiApproved?: Boolean;

  @Column({
    name: 'updated_timeline',
    type: 'timestamp',
    precision: 0,
    nullable: true,
  })
  updatedTimeline?: Date;

  @Column({ name: 'reason_not_implemented', type: 'text', nullable: true })
  reasonNotImplemented?: string | null;

  @Column({
    name: 'current_status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  currentStatus?: string;

  @Column({
    name: 'current_stage',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  currentStage?: string;

  @Column({ name: 'action_taken_by_ministry', type: 'text', nullable: true })
  actionTakenByMinistry?: string;

  @Column({ type: 'text', nullable: true })
  remark?: string;

  @Column({ name: 'niti_remark', type: 'text', nullable: true })
  nitiRemark?: string;

  @Column({
    name: 'stage',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  stage?: string;

  // @OneToMany(() => RecommendationFile, (file) => file.recommendation)
  // files: RecommendationFile[];

  @OneToMany(
    () => IgomRecommendationUpdates,
    (update) => update.igomRecommendation,
  )
  igomRecommendationUpdates: IgomRecommendationUpdates[];

  @Column({
    name: 'closure_status',
    type: 'varchar',
    length: 20,
    default: ClosureStatusEnum.OPEN,
  })
  closureStatus: ClosureStatusEnum;

  @Column({
    name: 'closed_at',
    type: 'timestamp',
    precision: 0,
    nullable: true,
  })
  closedAt?: Date;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'closed_by' })
  closedBy?: User | null;

  @Column({
    name: 'closure_remark',
    type: 'text',
    nullable: true,
  })
  closureRemark?: string;

  @Column({
    name: 'acts_rules_provisions_modified',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  actsRulesProvisionsModified?: string | null;

  @Column({
    name: 'other_ministries_consulted',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  otherMinistriesConsulted?: string | null;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt!: Date;

  @Column({ name: 'is_active', type: 'boolean', default: true })
  isActive?: Boolean;

  @Column({ name: 'is_reassigned', type: 'boolean', default: false })
  isReassigned?: Boolean;

  @Column({
    name: 'reassign_status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  reassignStatus?: string | null;;

  @Column({
    name: 'reassign_comments',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  reassignComments?: string | null;;

  @Column({
    name: 'hlc_ref_id',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  hlcRefId?: string;
}

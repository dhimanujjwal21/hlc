import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Recommendation } from './recommendation.entity';

@Entity('t_recommendation_files')
export class RecommendationFile {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Recommendation, (r) => r.files, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'recommendation_id' })
  recommendation: Recommendation;

  @Column({ name: 'file_name', type: 'varchar', length: 255 })
  fileName: string;

  @Column({ name: 's3_key', type: 'varchar', length: 500 })
  s3Key: string;

  @Column({ name: 'url', type: 'text' })
  url: string;

  @Column({ name: 'file_size', type: 'bigint' })
  fileSize: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}

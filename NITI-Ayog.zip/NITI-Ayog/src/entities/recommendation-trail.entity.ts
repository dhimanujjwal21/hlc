import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { Recommendation } from './recommendation.entity';
import { User } from './users.entity';

@Entity('t_recommendation_trail')
export class RecommendationTrail {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Recommendation, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'recommendation_id' })
  recommendation?: Recommendation | null;

  @Column({ name: 'current_status', type: 'varchar', length: 100 })
  currentStatus?: string | null;

  @Column({ name: 'next_status', type: 'varchar', length: 100 })
  nextStatus: string | null;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'user_id' })
  user?: User | null;

  @Column({ type: 'text', nullable: true })
  description?: string | null;

  @Column({ name: 'other_details', type: 'json', nullable: true })
  otherDetails?: Record<string, any>;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
  })
  createdAt: Date;
}

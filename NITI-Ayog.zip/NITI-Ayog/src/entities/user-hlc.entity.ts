import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  Unique,
} from 'typeorm';
import { User } from './users.entity';
import { Hlc } from './hlc.entity';

@Entity('t_user_hlc')
@Unique(['user', 'hlc']) // prevent duplicate entries
export class UserHlc {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, (user) => user.userHlcs, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Hlc, (hlc) => hlc.userHlcs, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'hlc_id' })
  hlc: Hlc;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;
}

import {
  Entity,
  Unique,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
  Column,
  UpdateDateColumn,
  CreateDateColumn,
} from 'typeorm';
import { User } from './users.entity';
import { Hlc } from './hlc.entity';
import { Ministry } from './ministry.entity';
import { Departments } from './departments.entity';
import { Recommendation } from './recommendation.entity';
import { DraftRoleEnum, DraftStatusEnum, RoleEnum } from 'src/constants/enums';

@Entity('t_recommendation_draft')
export class RecommendationDraft {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'user_id' })
  user?: User | null;

  // Niti Director Keys
  @Column({
    nullable: true,
    name: 'recommendation_slug',
    type: 'varchar',
    length: 100,
  })
  recommendationSlug?: string;

  @Column({ type: 'text', nullable: true })
  name?: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'department_id' })
  department?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'ministry_id' })
  ministry?: Ministry | null;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_department_id' })
  primaryDepartment?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_ministry_id' })
  primaryMinistry?: Ministry | null;

  @ManyToOne(() => Hlc, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'hlc_id' })
  hlc?: Hlc | null;

  @Column({ name: 'timeline', type: 'timestamp', precision: 0, nullable: true })
  timeline?: Date;

  @Column({
    name: 'report_number',
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  reportNumber?: string;

  // Ministry Director
  @Column({ name: 'reason_not_implemented', type: 'text', nullable: true })
  reasonNotImplemented?: string | null;

  @Column({
    name: 'current_status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  currentStatus?: string;

  @Column({ name: 'action_taken_by_ministry', type: 'text', nullable: true })
  actionTakenByMinistry?: string;

  @ManyToOne(() => Recommendation, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'recommendation_id' })
  recommendation?: Recommendation | null;

  // Role: Ministry Director / Niti Director
  @Column({
    name: 'role',
    type: 'enum',
    enum: RoleEnum,
    default: RoleEnum.NITI_DIRECTOR,
    nullable: true,
  })
  role?: RoleEnum;

  @Column({
    name: 'draft_status',
    type: 'enum',
    enum: DraftStatusEnum,
    default: DraftStatusEnum.PENDING,
  })
  draftStatus?: DraftStatusEnum;

   @Column({ name: 'related_to_hlc', type: 'boolean', default: false })
  relatedToHlc?: Boolean;

   @Column({
    name: 'hlc_ref_id',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  hlcRefId?: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

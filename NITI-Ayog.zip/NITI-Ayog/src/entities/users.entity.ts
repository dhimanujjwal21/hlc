import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  ManyToMany,
  JoinTable,
  OneToMany,
} from 'typeorm';
import { Role } from './roles.entity';
import { Ministry } from './ministry.entity';
import { Hlc } from './hlc.entity';
import { UserHlc } from './user-hlc.entity';
import { Departments } from './departments.entity';
import { UserIgom } from './user-igom.entity';
import { UserRoles } from './user-roles.entity';

@Entity('t_users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column({
    name: 'display_name',
    type: 'varchar',
    length: 200,
    nullable: true,
  })
  displayName?: string;

  @Index()
  @Column({ type: 'varchar', length: 150, unique: true })
  email: string;

  @Column({ type: 'varchar', length: 200, nullable: true })
  designation: string;

  @Column({
    name: 'mobile_number',
    type: 'varchar',
    length: 15,
    nullable: true,
  })
  mobileNumber: string;

  @Column({ type: 'varchar', length: 255 })
  password: string;

  @ManyToOne(() => Role, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'role_id' })
  role?: Role | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'ministry_id' })
  ministry?: Ministry | null;

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'department_id' })
  department?: Departments | null;

  @OneToMany(() => UserRoles, (UserRoles) => UserRoles.user)
  userRoles: UserRoles[];

  @OneToMany(() => UserHlc, (userHlc) => userHlc.user)
  userHlcs: UserHlc[];

  @OneToMany(() => UserIgom, (UserIgom) => UserIgom.user)
  userIgoms: UserIgom[];

  @Column({ name: 'dashboard_view', type: 'boolean', default: false })
  dashboardView: boolean;

  @Column({ name: 'viewing_access', type: 'boolean', default: false })
  viewingAccess: boolean;

  @Column({ name: 'home_view', type: 'boolean', default: true })
  homeView: boolean;

  @Column({
    name: 'last_login',
    type: 'timestamp',
    nullable: true,
  })
  lastLogin: Date | null;

  @Column({
    name: 'is_disabled',
    type: 'boolean',
    default: false,
  })
  isDisabled: boolean;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

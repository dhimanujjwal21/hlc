import {
  Entity,
  Unique,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
  Column,
  UpdateDateColumn,
  CreateDateColumn,
} from 'typeorm';
import { User } from './users.entity';
import { Ministry } from './ministry.entity';
import { Departments } from './departments.entity';
import { DraftStatusEnum, RoleEnum } from 'src/constants/enums';
import { Igom } from './igom.entity';
import { IgomRecommendation } from './igom-recommendation.entity';

@Entity('t_igom_recommendation_draft')
export class IgomRecommendationDraft {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'user_id' })
  user?: User | null;

  // Niti Director Keys
  @Column({
    nullable: true,
    name: 'recommendation_slug',
    type: 'varchar',
    length: 100,
  })
  recommendationSlug?: string;

  @Column({
    nullable: true,
    name: 'implementing_agency',
    type: 'varchar',
  })
  implementingAgency?: string;

  @Column({ type: 'text', nullable: true })
  name?: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({
    name: 'department_ids',
    type: 'simple-json',
    nullable: true,
  })
  departmentIds?: number[];

  @Column({
    name: 'ministry_ids',
    type: 'simple-json',
    nullable: true,
  })
  ministryIds?: number[];

  @ManyToOne(() => Departments, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_department_id' })
  primaryDepartment?: Departments | null;

  @ManyToOne(() => Ministry, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'primary_ministry_id' })
  primaryMinistry?: Ministry | null;

  @ManyToOne(() => Igom, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'igom_id' })
  igom?: Igom | null;

  @Column({ name: 'timeline', type: 'timestamp', precision: 0, nullable: true })
  timeline?: Date;

  @Column({
    name: 'meeting_date',
    type: 'timestamp',
    precision: 0,
    nullable: true,
  })
  meetingDate?: Date;

  @Column({
    name: 'proposal_nature',
    type: 'text',
    nullable: true,
  })
  proposalNature: string;
  @Column({
    name: 'budgetary_category',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  budgetaryCategory: string;

  @Column({
    name: 'report_number',
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  reportNumber?: string;

  // Ministry Director
  @Column({ name: 'reason_not_implemented', type: 'text', nullable: true })
  reasonNotImplemented?: string | null;

  @Column({
    name: 'current_status',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  currentStatus?: string;

  @Column({ name: 'action_taken_by_ministry', type: 'text', nullable: true })
  actionTakenByMinistry?: string;

  @ManyToOne(() => IgomRecommendation, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'igom_recommendation_id' })
  igomRecommendation?: IgomRecommendation | null;

  // Role: Ministry Director / Niti Director
  @Column({
    name: 'role',
    type: 'enum',
    enum: RoleEnum,
    default: RoleEnum.NITI_DIRECTOR,
    nullable: true,
  })
  role?: RoleEnum;

  @Column({
    name: 'draft_status',
    type: 'enum',
    enum: DraftStatusEnum,
    default: DraftStatusEnum.PENDING,
  })
  draftStatus?: DraftStatusEnum;

  @Column({ name: 'related_to_hlc', type: 'boolean', default: false })
  relatedToHlc?: boolean;

  @Column({
    name: 'hlc_ref_id',
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  hlcRefId?: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 0,
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;
}

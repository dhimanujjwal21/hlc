import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable, map, catchError, throwError } from 'rxjs';
import { RAW_RESPONSE_KEY } from 'src/decorators/raw-response.decorator';

interface CommonResponse<T = any> {
  isError: boolean;
  success: boolean;
  message: string;
  data?: T;
}

function makeResponse<T>(
  message: string,
  data?: T,
  success = true,
): CommonResponse<T> {
  return {
    isError: !success,
    success,
    message,
    data,
  };
}

@Injectable()
export class ResponseInterceptor<T> implements NestInterceptor<T, any> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    if (Reflect.getMetadata(RAW_RESPONSE_KEY, context.getHandler())) {
      return next.handle();
    }

    return next.handle().pipe(
      map((data) => {
        // If controller already returned a formatted response, keep it
        if (
          data &&
          typeof data === 'object' &&
          'isError' in data &&
          'success' in data
        ) {
          return data;
        }

        // Otherwise wrap it
        return makeResponse('Success', data, true);
      }),
      catchError((err) => {
        const message = err?.response?.message || err.message || 'Something went wrong';
        return throwError(() => err);
      }),
    );
  }
}

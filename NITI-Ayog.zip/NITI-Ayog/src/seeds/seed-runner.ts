import { DataSource } from 'typeorm';
import { seedRolesAndPermissions } from './role-permission.seed';
import { AppDataSource } from '../../data-source';
import { seedMinistries } from './ministry-department.seeds';
import { seedUsers } from './user.seed';
import { seedHlcs } from './hlc.seed';

AppDataSource.initialize()
  .then(async (dataSource: DataSource) => {
    const appEnv = (process.env.APP_ENV || '').toLowerCase();

    if (appEnv !== 'development') {
      throw new Error(
        `Database seeding is disabled in '${appEnv || 'unknown'}' environment`,
      );
    }

    await seedRolesAndPermissions(dataSource);
    await seedMinistries(dataSource);
    await seedUsers(dataSource);
    await seedHlcs(dataSource);

    console.log('✅ Seeding done!');

    await dataSource.destroy();
    process.exit(0);
  })
  .catch(async (error) => {
    console.error('Seeding error:', error);
    process.exit(1);
  });
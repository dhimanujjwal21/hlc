import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { randomBytes } from 'crypto';

import { User } from '../entities/users.entity';
import { Role } from '../entities/roles.entity';
import { Ministry } from '../entities/ministry.entity';

export async function seedUsers(ds: DataSource) {
  const appEnv = (process.env.APP_ENV || '').toLowerCase();

  if (appEnv !== 'development') {
    throw new Error(
      `User seeding is disabled in '${appEnv || 'unknown'}' environment`,
    );
  }

  const userRepo = ds.getRepository(User);
  const roleRepo = ds.getRepository(Role);
  const ministryRepo = ds.getRepository(Ministry);

  const roles = await roleRepo.find();
  const roleMap = new Map(roles.map((r) => [r.roleName.toLowerCase(), r]));

  const ministries = await ministryRepo.find();
  const ministryMap = new Map(ministries.map((m) => [m.name.toLowerCase(), m]));

  const users = [
    {
      name: 'Super Admin',
      email: 'super.admin@gov.in',
      roleName: 'super admin',
      ministryName: null,
    },
    {
      name: 'NITI Director',
      email: 'niti.director@gov.in',
      roleName: 'niti director',
      ministryName: null,
    },
    {
      name: 'NITI Approver',
      email: 'niti.approver@gov.in',
      roleName: 'niti approver',
      ministryName: null,
    },
    {
      name: 'Ministry Director',
      email: 'ministry.director@gov.in',
      roleName: 'ministry director',
      ministryName: 'Ministry of Agriculture and Farmers Welfare',
    },
    {
      name: 'Ministry Approver',
      email: 'ministry.approver@gov.in',
      roleName: 'ministry approver',
      ministryName: 'Ministry of Agriculture and Farmers Welfare',
    },
  ];

  for (const userData of users) {
    const existing = await userRepo.findOne({
      where: { email: userData.email },
    });

    if (existing) {
      console.log(`⚠️ User already exists: ${userData.email}`);
      continue;
    }

    const role = roleMap.get(userData.roleName.toLowerCase());

    if (!role) {
      console.warn(`❌ Role not found for user: ${userData.name}`);
      continue;
    }

    let ministry: Ministry | null = null;

    if (userData.ministryName) {
      ministry = ministryMap.get(userData.ministryName.toLowerCase()) ?? null;
    }

    const temporaryPassword = randomBytes(24).toString('base64url');

    const hashedPassword = await bcrypt.hash(temporaryPassword, 12);

    const user = userRepo.create({
      name: userData.name,
      email: userData.email,
      password: hashedPassword,
      role,
      ministry,
    });

    await userRepo.save(user);

    console.log(
      `[DEV ONLY] ${userData.email} temporary password: ${temporaryPassword}`,
    );
  }

  console.log('🎉 User seeding complete!');
}
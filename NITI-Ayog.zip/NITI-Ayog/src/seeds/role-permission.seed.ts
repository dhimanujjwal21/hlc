import { DataSource } from 'typeorm';
import { RolePermission } from '../entities/role-permission.entity';
import { PermissionsEnum, PermissionsDescriptionEnum, RoleEnum } from '../constants/enums';
import { Permission } from '../entities/permissions.entity';
import { Role } from '../entities/roles.entity';

export async function seedRolesAndPermissions(dataSource: DataSource) {
  const permRepo = dataSource.getRepository(Permission);
  const roleRepo = dataSource.getRepository(Role);
  const rolePermRepo = dataSource.getRepository(RolePermission);

  const allPermissionNames = Object.values(PermissionsEnum);
  const existingPermissions = await permRepo.find();

  const newPermissions = allPermissionNames
    .filter((name: string) => !existingPermissions.some((p) => p.permissionName.toLowerCase() === name.toLowerCase()))
    .map((name) => permRepo.create({ permissionName: name, description: PermissionsDescriptionEnum[name] }))
  
  console.log(newPermissions)

  if (newPermissions.length > 0) {
    await permRepo.save(newPermissions);
    console.log(`✅ Added ${newPermissions.length} new permissions`);
  }

  const allPermissions = await permRepo.find();

  const roles =  Object.values(RoleEnum);

  const existingRoles = await roleRepo.find();
  const newRoles = roles
    .filter((r) => !existingRoles.some((er) => er.roleName.toLowerCase() === r.toLowerCase()))
    .map((r) => roleRepo.create({roleName: r}));


    console.log(existingRoles)
    console.log(newRoles)

  if (newRoles.length > 0) {
    await roleRepo.save(newRoles);
    console.log(`✅ Added ${newRoles.length} new roles`);
  }

  const allRoles = await roleRepo.find();

  const superAdmin = allRoles.find((r) => r.roleName === 'Super Admin');
  const nitiDirector = allRoles.find((r) => r.roleName === 'Niti Director');
  const nitiApprover = allRoles.find((r) => r.roleName === 'Niti Approver');
  const ministryDirector = allRoles.find((r) => r.roleName === 'Ministry Director');
  const ministryApprover = allRoles.find((r) => r.roleName === 'Ministry Approver');

  const mappings: { role: Role | undefined; permissionNames: PermissionsEnum[] }[] = [
    { role: superAdmin, permissionNames: allPermissionNames },
    {
      role: nitiDirector,
      permissionNames: [
        PermissionsEnum.ADD_RECOMMENDATION,
        PermissionsEnum.EDIT_RECOMMENDATION,
      ],
    },
    {
      role: nitiApprover,
      permissionNames: [PermissionsEnum.NITI_APPROVER_REQUEST],
    },
    {
      role: ministryDirector,
      permissionNames: [PermissionsEnum.MINISTRY_DIRECTOR_REQUEST],
    },
    {
      role: ministryApprover,
      permissionNames: [PermissionsEnum.MINISTRY_APPROVER_REQUEST],
    },
  ];

  for (const { role, permissionNames } of mappings) {
    if (!role) continue;

    const existingRolePerms = await rolePermRepo.find({ where: { role: { id: role.id } }, relations: ['permission'] });
    const newRolePerms = permissionNames
      .filter(
        (pname) =>
          !existingRolePerms.some((rp) => rp.permission.permissionName === pname),
      )
      .map((pname) => {
        const perm = allPermissions.find((p) => p.permissionName === pname);
        return rolePermRepo.create({ role, permission: perm });
      });

    if (newRolePerms.length > 0) {
      await rolePermRepo.save(newRolePerms);
      console.log(`✅ Assigned ${newRolePerms.length} new permissions to ${role.roleName}`);
    }
  }

  console.log('🎉 Role & Permission seeding completed');
}

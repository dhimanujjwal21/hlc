import { Departments } from '../entities/departments.entity';
import { Ministry } from '../entities/ministry.entity';

export const ministries = [
  {
    name: 'Ministry of Agriculture and Farmers Welfare',
    departments: [
      { name: 'Department of Agricultural Research and Education' },
      { name: 'Department of Agriculture and Farmers Welfare' },
    ],
  },
  {
    name: 'Ministry of AYUSH',
    departments: [],
  },
  {
    name: 'Ministry of Chemicals and Fertilizers',
    departments: [
      { name: 'Department of Chemicals and Petrochemicals' },
      { name: 'Department of Fertilizers' },
      { name: 'Department of Pharmaceuticals' },
    ],
  },
  {
    name: 'Ministry of Civil Aviation',
    departments: [],
  },
  {
    name: 'Ministry of Coal',
    departments: [],
  },
  {
    name: 'Ministry of Commerce and Industry',
    departments: [
      { name: 'Department of Commerce' },
      { name: 'Department for Promotion of Industry and Internal Trade' },
    ],
  },
  {
    name: 'Ministry of Consumer Affairs, Food and Public Distribution',
    departments: [
      { name: 'Department of Consumer Affairs' },
      { name: 'Department of Food and Public Distribution' },
    ],
  },
  {
    name: 'Ministry of Communications',
    departments: [
      { name: 'Department of Posts' },
      { name: 'Department of Telecommunications' },
    ],
  },
  {
    name: 'Ministry of Corporate Affairs',
    departments: [],
  },
  {
    name: 'Ministry of Culture',
    departments: [],
  },
  {
    name: 'Ministry of Defence',
    departments: [
      { name: 'Department of Defence' },
      { name: 'Department of Defence Production' },
      { name: 'Department of Defence Research and Development' },
      { name: 'Department of Ex-Servicemen Welfare' },
      { name: 'Department of Military Affairs' },
    ],
  },
  {
    name: 'Ministry of Development of North Eastern Region',
    departments: [],
  },
  {
    name: 'Ministry of Earth Sciences',
    departments: [],
  },
  {
    name: 'Ministry of Electronics and Information Technology',
    departments: [],
  },
  {
    name: 'Ministry of Environment, Forest and Climate Change',
    departments: [],
  },
  {
    name: 'Ministry of External Affairs',
    departments: [],
  },
  {
    name: 'Ministry of Finance',
    departments: [
      { name: 'Department of Economic Affairs' },
      { name: 'Department of Expenditure' },
      { name: 'Department of Financial Services' },
      { name: 'Department of Investment and Public Asset Management' },
      { name: 'Department of Public Enterprises' },
      { name: 'Department of Revenue' },
    ],
  },
  {
    name: 'Ministry of Fisheries, Animal Husbandry and Dairying',
    departments: [
      { name: 'Department of Animal Husbandry and Dairying' },
      { name: 'Department of Fisheries' },
    ],
  },
  {
    name: 'Ministry of Food Processing Industries',
    departments: [],
  },
  {
    name: 'Ministry of Health & Family Welfare',
    departments: [
      { name: 'Department of Health Research' },
      { name: 'Department of Health and Family Welfare' },
    ],
  },
  {
    name: 'Ministry of Heavy Industries',
    departments: [],
  },
  {
    name: 'Ministry of Home Affairs',
    departments: [
      { name: 'Department of Home' },
      { name: 'Department of Official Language' },
      { name: 'Department of Border Management' },
    ],
  },
  {
    name: 'Ministry of Housing and Urban Affairs',
    departments: [],
  },
  {
    name: 'Ministry of Education',
    departments: [
      { name: 'Department of Higher Education' },
      { name: 'Department of School Education and Literacy' },
    ],
  },
  {
    name: 'Ministry of Information and Broadcasting',
    departments: [],
  },
  {
    name: 'Ministry of Jal Shakti',
    departments: [
      { name: 'Department of Drinking Water and Sanitation' },
      {
        name: 'Department of Water Resources, River Development and Ganga Rejuvenation',
      },
    ],
  },
  {
    name: 'Ministry of Labour & Employment',
    departments: [],
  },
  {
    name: 'Ministry of Law and Justice',
    departments: [
      { name: 'Department of Justice' },
      { name: 'Department of Legal Affairs' },
      { name: 'Legislative Department' },
    ],
  },
  {
    name: 'Ministry of Micro, Small and Medium Enterprises',
    departments: [],
  },
  {
    name: 'Ministry of Mines',
    departments: [],
  },
  {
    name: 'Ministry of Minority Affairs',
    departments: [],
  },
  {
    name: 'Ministry of New and Renewable Energy',
    departments: [],
  },
  {
    name: 'Ministry of Panchayati Raj',
    departments: [],
  },
  {
    name: 'Ministry of Parliamentary Affairs',
    departments: [],
  },
  {
    name: 'Ministry of Personnel, Public Grievances and Pensions',
    departments: [
      {
        name: 'Department of Administrative Reforms and Public Grievances',
      },
      { name: "Department of Pension & Pensioner's Welfare" },
      { name: 'Department of Personnel and Training' },
    ],
  },
  {
    name: 'Ministry of Petroleum and Natural Gas',
    departments: [],
  },
  {
    name: 'Ministry of Power',
    departments: [],
  },
  {
    name: 'Ministry of Railways',
    departments: [],
  },
  {
    name: 'Ministry of Road Transport and Highways',
    departments: [],
  },
  {
    name: 'Ministry of Rural Development',
    departments: [
      { name: 'Department of Land Resources' },
      { name: 'Department of Rural Development' },
    ],
  },
  {
    name: 'Ministry of Science and Technology',
    departments: [
      { name: 'Department of Bio-Technology' },
      { name: 'Department of Science and Technology' },
      {
        name: 'Department of Scientific and Industrial Research',
      },
    ],
  },
  {
    name: 'Ministry of Skill Development and Entrepreneurship',
    departments: [],
  },
  {
    name: 'Ministry of Social Justice and Empowerment',
    departments: [
      {
        name: 'Department of Empowerment of Persons with Disabilities',
        code: 'DEPWD',
      },
      { name: 'Department of Social Justice and Empowerment' },
    ],
  },
  {
    name: 'Ministry of Statistics and Programme Implementation',
    departments: [],
  },
  {
    name: 'Ministry of Steel',
    departments: [],
  },
  {
    name: 'Ministry of Textiles',
    departments: [],
  },
  {
    name: 'Ministry of Tourism',
    departments: [],
  },
  {
    name: 'Ministry of Tribal Affairs',
    departments: [],
  },
  {
    name: 'Ministry of Women and Child Development',
    departments: [],
  },
  {
    name: 'Ministry of Youth Affairs and Sports',
    departments: [
      { name: 'Department of Sports' },
      { name: 'Department of Youth Affairs' },
    ],
  },
  {
    name: 'Ministry of Cooperation',
    departments: [],
  },
  {
    name: 'Ministry of Ports, Shipping and Waterways',
    departments: [],
  },
  {
    name: 'Ministry of Planning',
    departments: [],
  },
  {
    name: 'Department of Atomic Energy',
    departments: [{ name: 'Department of Atomic Energy' }],
  },
  {
    name: 'Department of Space',
    department: [{ name: 'Department of Space' }],
  },
];

export async function seedMinistries(ds) {
  const ministryRepo = ds.getRepository(Ministry);
  const deptRepo = ds.getRepository(Departments);

  for (const item of ministries) {
    // 1️⃣ Check if ministry exists
    let ministry = await ministryRepo.findOne({
      where: { name: item.name },
    });

    if (!ministry) {
      ministry = ministryRepo.create({ name: item.name });
      ministry = await ministryRepo.save(ministry);
      console.log(`✅ Inserted Ministry: ${item.name}`);
    }

    // 2️⃣ Seed Departments for this ministry
    if (item.departments && item.departments.length > 0) {
      for (const deptData of item.departments) {
        const existingDept = await deptRepo.findOne({
          where: { name: deptData.name, ministry: { id: ministry.id } },
          relations: ['ministry'],
        });

        if (!existingDept) {
          const dept = deptRepo.create({
            name: deptData.name,
            ministry: ministry,
          });
          await deptRepo.save(dept);
          console.log(`   ↳ Added Department: ${deptData.name}`);
        }
      }
    }
  }

  console.log('🎉 Ministry & Department seeding completed!');
}

import { DataSource } from 'typeorm';
import { Hlc } from '../entities/hlc.entity';

export async function seedHlcs(ds: DataSource) {
  const hlcRepo = ds.getRepository(Hlc);

  const hlcData = [
    {
      slug: 'A',
      name: 'HLC-A - High Level Committee on implementation of Viksit Bharat Goals',
    },
    {
      slug: 'B',
      name: 'HLC-B - High Level Committee on Non-Financial Regulatory Reforms',
    },
  ];

  for (const hlc of hlcData) {
    const exists = await hlcRepo.findOne({ where: { slug: hlc.slug } });
    if (exists) {
      console.log(`⚠️ HLC already exists: ${hlc.slug}`);
      continue;
    }

    await hlcRepo.save(hlcRepo.create(hlc));
    console.log(`✅ Inserted HLC: ${hlc.slug}`);
  }

  console.log('🎯 HLC seeding completed!');
}

import { SetMetadata } from '@nestjs/common';

export const RAW_RESPONSE_KEY = 'rawResponse';
// Skips the global ResponseInterceptor wrapping, for APIs with an externally agreed response shape
export const RawResponse = () => SetMetadata(RAW_RESPONSE_KEY, true);

import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  IsNumber,
  IsEnum,
  IsDateString,
  IsInt,
  IsArray,
  ValidateIf,
  IsBoolean,
} from 'class-validator';
import { DraftRoleEnum, DraftStatusEnum } from '../../constants/enums';
import { Type } from 'class-transformer';

export class IgomRecommendationDraftDto {
  // ---- NITI Director Fields ----

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  recommendationSlug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  implementingAgency?: string;

  @ApiPropertyOptional({ description: 'Department IDs', type: [Number] })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  departmentIds?: number[]; // CHANGED: now an array

  @ApiPropertyOptional({ description: 'Ministry IDs', type: [Number] })
  @IsOptional()
  @IsArray()
  @IsNumber({}, { each: true })
  ministryIds?: number[]; // CHANGED: now an array

  @ApiPropertyOptional({ description: 'Primary Department ID' })
  @IsOptional()
  @IsNumber()
  primaryDepartmentId?: number;

  @ApiPropertyOptional({ description: 'Primary Ministry ID' })
  @IsOptional()
  @IsNumber()
  primaryMinistryId?: number;

  @ApiPropertyOptional({ description: 'IGOM ID' })
  @IsOptional()
  @IsNumber()
  igomId?: number;

  @ApiPropertyOptional({ description: 'Timeline (YYYY-MM-DD)' })
  @IsOptional()
  @IsDateString()
  timeline?: string;

  @ApiPropertyOptional({ description: 'Timeline (YYYY-MM-DD)' })
  @IsOptional()
  @IsDateString()
  meetingDate?: string;

  @ApiPropertyOptional({ description: 'Timeline (YYYY-MM-DD)' })
  @IsOptional()
  @IsString()
  proposalNature?: string;

  @ApiPropertyOptional({ description: 'Timeline (YYYY-MM-DD)' })
  @IsOptional()
  @IsString()
  BudgetaryCategory?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reportNumber?: string;

  // ---- Ministry Director Fields ----

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reasonIfNotImplemented?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  actionTakenByMinistry?: string;

  // ---- Linking to Recommendation ----

  @ApiPropertyOptional({
    description: 'Existing Recommendation ID (for editing)',
  })
  @IsOptional()
  @IsNumber()
  recommendationId?: number;

  // ---- Role ----

  // @ApiPropertyOptional({ enum: DraftRoleEnum })
  // @IsOptional()
  // @IsEnum(DraftRoleEnum)
  // role?: DraftRoleEnum;

  // ---- Draft Status ----

  @ApiPropertyOptional({ enum: DraftStatusEnum })
  @IsOptional()
  @IsEnum(DraftStatusEnum)
  draftStatus?: DraftStatusEnum;

   @ApiPropertyOptional({ description: 'HLC Reference ID' })
  @ValidateIf(o => o.isHlcRelated === true)
  @IsString()
  hlcRefId?: string;

  @ApiPropertyOptional({ description: 'Is HLC related' })
  @IsOptional()
  @IsBoolean()
  isHlcRelated?: boolean;
}

export class IgomGetRecommendationDraftQueryDto {
  @ApiPropertyOptional({ description: 'Filter by department ID' })
  @IsOptional()
  @IsString()
  departmentId?: string;

  @ApiPropertyOptional({ description: 'Filter by ministry ID' })
  @IsOptional()
  @IsString()
  ministryId?: string;
  @ApiPropertyOptional({ description: 'Filter by IGOM ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  igomId?: number;

  @IsOptional()
  @IsString()
  implementingAgency?: string;

  @ApiPropertyOptional({
    description: 'budgetary category filter',
  })
  @IsOptional()
  @IsString()
  budgetaryCategory?: string;

  @ApiPropertyOptional({
    description: 'proposal nature filter',
  })
  @IsOptional()
  @IsString()
  proposalNature?: string;

  @ApiPropertyOptional({
    description: 'Filter recommendations by month and year of this date',
  })
  @IsOptional()
  @IsDateString(
    {},
    { message: 'meeting Date must be a valid ISO date string (e.g., 2025-11-01)' },
  )
  meetingDate?: string;


  @ApiPropertyOptional({
    description: 'Filter by current status',
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({
    description: 'Page number for pagination',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  page?: number = 1;

  @ApiPropertyOptional({ description: 'Number of items per page' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  limit?: number = 10;

  @ApiPropertyOptional({ description: 'Report Number' })
  @IsOptional()
  @IsString()
  reportNumber?: string;

  @ApiPropertyOptional({
    description: 'Search by name, slug, description, or report number',
  })
  @IsOptional()
  @IsString()
  search?: string;
}

export class IgomApproveRejectDraftDto {
  @ApiProperty({
    enum: [DraftStatusEnum.APPROVED, DraftStatusEnum.REJECTED],
  })
  @IsEnum(DraftStatusEnum)
  status?: DraftStatusEnum;
}

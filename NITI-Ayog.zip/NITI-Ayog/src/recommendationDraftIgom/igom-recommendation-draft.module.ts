import { Module } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecommendationDraft } from 'src/entities/recommendation-draft.entity';
import { IgomRecommendationDraftService } from './igom-recommendation-draft.service';
import { IgomRecommendationDraftController } from './igom-recommendation-draft.controller';
import { User } from 'src/entities/users.entity';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';
import { RecommendationFile } from 'src/entities/recommendation-file.entity';
import { Igom } from 'src/entities/igom.entity';
import { IgomRecommendationService } from 'src/recommendation-igom/igom-recommendation.service';
import { IgomRecommendationDraft } from 'src/entities/igom-recommendation-draft.entity';
import { IgomRecommendationUpdates } from 'src/entities/igom-recommendation-updates.entity';
import { IgomRecommendation } from 'src/entities/igom-recommendation.entity';
import { IgomRecReassign } from 'src/entities/igom-rec-reassign.entity';
import { IgomRecommendationTrail } from 'src/entities/igom-recommendation-trail.entity';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Igom,
      User,
      Departments,
      Ministry,
      IgomRecommendationDraft,
      IgomRecommendation,
      RecommendationTrail,
      IgomRecommendationTrail,
      IgomRecommendationUpdates,
      RecommendationFile,
      IgomRecReassign,
      RecommendationUpdates,
    ]),
  ],
  controllers: [IgomRecommendationDraftController],
  providers: [
    IgomRecommendationDraftService,
    JwtService,
    IgomRecommendationService,
  ],
  exports: [],
})
export class IgomRecommendationDraftModule {}

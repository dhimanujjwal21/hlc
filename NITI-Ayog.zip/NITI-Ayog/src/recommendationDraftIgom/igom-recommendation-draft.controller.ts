import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IgomRecommendationDraftService } from './igom-recommendation-draft.service';
import {
  IgomApproveRejectDraftDto,
  IgomGetRecommendationDraftQueryDto,
  IgomRecommendationDraftDto,
} from './dto/igom-recommendation-draft.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { IgomRecommendation } from 'src/entities/igom-recommendation.entity';
import {DraftStatusEnum} from "../constants/enums";

@ApiTags('Igom Recommendation Draft')
@Controller({
  path: 'igom-recommendation-draft',
  version: '1',
})
export class IgomRecommendationDraftController {
  constructor(
    private readonly recommendationDraftService: IgomRecommendationDraftService,
  ) {}

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('')
  async draftRecommendation(@Req() req, @Body() body: IgomRecommendationDraftDto) {
    await this.recommendationDraftService.draftIgomRecommendation(
      body,
      req?.user?.id,
    );
    return { message: 'Igom Recommendation Draft saved Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('')
  async getDraftRecommendation(
    @Req() req,
    @Query() query: IgomGetRecommendationDraftQueryDto,
  ) {
    return this.recommendationDraftService.getDraftRecommendation(
      query,
      req?.user?.id,
    );
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put(':id')
  async editDraft(
    @Req() req,
    @Param('id') id: number,
    @Body() body: IgomRecommendationDraftDto,
  ) {
    await this.recommendationDraftService.editDraft(id, body, req.user.id);
    return { message: 'Igom Recommendation Draft Edited Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('approve/:id')
  async approveRejectDraft(
    @Req() req,
    @Param('id') id: number,
    @Body() body: IgomApproveRejectDraftDto,
  ) {
    await this.recommendationDraftService.approveRejectDraft(
      id,
      body,
      req.user.id,
    );
    const message =
      body.status === DraftStatusEnum.APPROVED
        ? 'Igom Recommendation Draft approved successfully'
        : 'Igom Recommendation Draft rejected successfully';

    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Delete(':id')
  async deleteDraft(@Req() req, @Param('id') id: number) {
    await this.recommendationDraftService.deleteDraft(id, req.user.id);
    return { message: 'Igom Recommendation Draft deleted Successfully' };
  }
}

import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { RecommendationDraft } from 'src/entities/recommendation-draft.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { In, IsNull, Not, Repository } from 'typeorm';
import {
  IgomApproveRejectDraftDto,
  IgomGetRecommendationDraftQueryDto,
  IgomRecommendationDraftDto,
} from './dto/igom-recommendation-draft.dto';
import {
  DraftRoleEnum,
  DraftStatusEnum,
  RoleEnum,
  StatusEnum,
} from 'src/constants/enums';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import { RecommendationService } from 'src/recommendation/recommendation.service';
import { Role } from 'src/entities/roles.entity';
import { IgomRecommendation } from 'src/entities/igom-recommendation.entity';
import { IgomRecommendationDraft } from 'src/entities/igom-recommendation-draft.entity';
import { Igom } from 'src/entities/igom.entity';
import { CreateIgomRecommendationDto } from 'src/recommendation-igom/dto/igom-recommendation.dto';
import { IgomRecommendationService } from 'src/recommendation-igom/igom-recommendation.service';

@Injectable()
export class IgomRecommendationDraftService {
  constructor(
    @InjectRepository(IgomRecommendation)
    private readonly igomRecommendationRepository: Repository<IgomRecommendation>,
    @InjectRepository(IgomRecommendationDraft)
    private readonly igomRecommendationDraftRepository: Repository<IgomRecommendationDraft>,
    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,
    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,
    @InjectRepository(Igom)
    private readonly igomRepository: Repository<Igom>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    private igomRecommendationService: IgomRecommendationService,
  ) {}

  async draftIgomRecommendation(
    body: IgomRecommendationDraftDto,
    userId: number,
  ) {
    const {
      departmentIds = [],
      ministryIds = [],
      primaryMinistryId,
      primaryDepartmentId,
      igomId,
    } = body;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });

    if (!user) throw new BadRequestException('Invalid user');

    const role = user.role?.roleName as RoleEnum | undefined;

    if (
      !role ||
      (role !== RoleEnum.DEA_DIRECTOR && role !== RoleEnum.MINISTRY_DIRECTOR)
    ) {
      throw new ForbiddenException(
        'You are not allowed to create or update drafts',
      );
    }

    // ---------------- EXISTING RECOMMENDATION ----------------
    let igomRecommendation: IgomRecommendation | null = null;

    if (body.recommendationId) {
      igomRecommendation = await this.igomRecommendationRepository.findOne({
        where: { id: body.recommendationId },
      });

      if (!igomRecommendation) {
        throw new BadRequestException('Recommendation not found');
      }
    }

    if (role === RoleEnum.DEA_DIRECTOR) {
      if (!body.recommendationSlug && !igomRecommendation) {
        throw new BadRequestException(
          'Recommendation id is required for DEA Director',
        );
      }
    }

    if (role === RoleEnum.MINISTRY_DIRECTOR && !body.recommendationId) {
      throw new BadRequestException(
        'Ministry Director must draft against an existing recommendation',
      );
    }

    // ---------------- PRIMARY ENTITIES ----------------
    let primaryDepartment: Departments | null = null;
    let primaryMinistry: Ministry | null = null;

    if (primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: primaryDepartmentId },
        relations: ['ministry'],
      });

      if (!primaryDepartment) {
        throw new NotFoundException(
          `Department with ID ${primaryDepartmentId} not found`,
        );
      }
    }

    if (primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: primaryMinistryId },
      });

      if (!primaryMinistry) {
        throw new NotFoundException(
          `Ministry with ID ${primaryMinistryId} not found`,
        );
      }
    }

    if (
      primaryDepartment &&
      primaryDepartment?.ministry?.id !== primaryMinistryId
    ) {
      throw new BadRequestException(
        `Primary Department belongs to ministry ${primaryDepartment.ministry?.id}`,
      );
    }

    // ---------------- IGOM ----------------
    let igom: Igom | null = null;

    if (igomId) {
      igom = await this.igomRepository.findOne({
        where: { id: igomId },
      });

      if (!igom) {
        throw new NotFoundException(`Igom with ID ${igomId} not found`);
      }
    }

    // ---------------- FETCH DEPARTMENTS & MINISTRIES ----------------
    const departmentIdsSafe = Array.isArray(departmentIds) ? departmentIds : [];
    const ministryIdsSafe = Array.isArray(ministryIds) ? ministryIds : [];

    const departments = await this.departmentRepository.find({
      where: { id: In(departmentIdsSafe) },
      relations: ['ministry'],
    });

    const ministries = await this.ministryRepository.find({
      where: { id: In(ministryIdsSafe) },
    });

    const departmentMap = new Map(departments.map((d) => [d.id, d]));
    const ministryMap = new Map(ministries.map((m) => [m.id, m]));

    departmentIdsSafe.forEach((id) => {
      if (!departmentMap.has(id)) {
        throw new NotFoundException(`Department with ID ${id} not found`);
      }
    });

    ministryIdsSafe.forEach((id) => {
      if (!ministryMap.has(id)) {
        throw new NotFoundException(`Ministry with ID ${id} not found`);
      }
    });

    // ---------------- BUILD PAIRS ----------------
    const pairs: { department: any; ministry: any }[] = [];
    const ministriesWithDepts = new Set<number>();

    for (const department of departments) {
      if (department.ministry) {
        if (!ministryMap.has(department.ministry.id)) {
          throw new NotFoundException(
            `Department ${department.id} has ministry ${department.ministry.id} not in payload`,
          );
        }

        pairs.push({
          department,
          ministry: ministryMap.get(department.ministry.id),
        });

        ministriesWithDepts.add(department.ministry.id);
      } else {
        pairs.push({ department, ministry: null });
      }
    }

    for (const ministry of ministries) {
      if (!ministriesWithDepts.has(ministry.id)) {
        pairs.push({ department: null, ministry });
      }
    }

    // ---------------- CREATE DRAFT ----------------
    const igomDraft = this.igomRecommendationDraftRepository.create({
      user,
      role,
      igomRecommendation,
      draftStatus: DraftStatusEnum.PENDING,
    });

    // ---------------- CONFLICT CHECK ----------------
    if (body.recommendationSlug) {
      const drafts = await this.igomRecommendationDraftRepository.find({
        where: {
          recommendationSlug: body.recommendationSlug,
          draftStatus: In([DraftStatusEnum.PENDING, DraftStatusEnum.APPROVED]),
        },
      });

      for (const { department, ministry } of pairs) {
        // Existing recommendation check
        const existing = await this.igomRecommendationRepository.findOne({
          where: {
            recommendationSlug: body.recommendationSlug,
            department: department ? { id: department.id } : IsNull(),
            ministry: ministry ? { id: ministry.id } : IsNull(),
          },
        });

        if (existing) {
          throw new ConflictException(
            `Recommendation "${body.recommendationSlug}" already exists for department ${department?.name ?? ''}/ministry ${ministry?.name ?? ''}`,
          );
        }

        // Draft conflict check (ID based)
        const conflictDraft = drafts.find((draft) => {
          const draftDeptIds: number[] = draft.departmentIds ?? [];
          const draftMinIds: number[] = draft.ministryIds ?? [];

          const deptMatch = department
            ? draftDeptIds.includes(department.id)
            : draftDeptIds.length === 0;

          const minMatch = ministry
            ? draftMinIds.includes(ministry.id)
            : draftMinIds.length === 0;

          return deptMatch && minMatch;
        });

        if (conflictDraft) {
          throw new ConflictException(
            `Draft already exists for department ${department?.name ?? ''} and ministry ${ministry?.name ?? ''}`,
          );
        }
      }

      // ---------------- ASSIGN VALUES ----------------
      Object.assign(igomDraft, {
        recommendationSlug:
          body.recommendationSlug ?? igomRecommendation?.recommendationSlug,

        name: body.name ?? igomRecommendation?.name,
        description: body.description ?? igomRecommendation?.description,

        departmentIds: departmentIdsSafe,
        ministryIds: ministryIdsSafe,

        igom,
        primaryDepartment,
        primaryMinistry,

        timeline: body.timeline ?? igomRecommendation?.timeline,
        reportNumber: body.reportNumber ?? igomRecommendation?.reportNumber,

        budgetaryCategory:
          body.BudgetaryCategory ?? igomRecommendation?.budgetaryCategory,

        proposalNature:
          body.proposalNature ?? igomRecommendation?.proposalNature,

        meetingDate: body.meetingDate ?? igomRecommendation?.meetingDate,

        implementingAgency:
          body.implementingAgency ?? igomRecommendation?.implementingAgency,
      });
    }

    // ---------------- MINISTRY DIRECTOR VALIDATION ----------------
    if (role === RoleEnum.MINISTRY_DIRECTOR) {
      const existingDraft =
        await this.igomRecommendationDraftRepository.findOne({
          where: {
            role,
            draftStatus: DraftStatusEnum.PENDING,
            user: { id: userId },
            igomRecommendation: {
              id: body.recommendationId,
            },
          },
        });

      if (existingDraft) {
        throw new BadRequestException(
          'Draft for this recommendation already exists',
        );
      }

      Object.assign(igomDraft, {
        currentStatus: body.status,
        actionTakenByMinistry: body.actionTakenByMinistry,
        reasonNotImplemented: body.reasonIfNotImplemented,
        hlcRefId: body.hlcRefId,
        relatedToHlc: body.isHlcRelated,
      });
    }

    // ---------------- SAVE ----------------
    await this.igomRecommendationDraftRepository.save(igomDraft);

    return {
      message: 'IGOM draft saved successfully',
      data: igomDraft,
    };
  }

  async getDraftRecommendation(
    data: IgomGetRecommendationDraftQueryDto,
    userId: number,
  ) {
    const {
      departmentId,
      ministryId,
      igomId,
      status,
      search,
      reportNumber,
      meetingDate,
      proposalNature,
      implementingAgency,
      budgetaryCategory,
      page = 1,
      limit = 10,
    } = data;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const qb = this.igomRecommendationDraftRepository
      .createQueryBuilder('draft')
      .leftJoin('draft.igomRecommendation', 'recommendation')

      .leftJoin('recommendation.department', 'recDept')
      .leftJoin('recommendation.ministry', 'recMin')
      .leftJoin('recommendation.primaryDepartment', 'recPrimaryDept')
      .leftJoin('recommendation.primaryMinistry', 'recPrimaryMin')
      .leftJoin('recommendation.igom', 'recIgom')

      .leftJoin('draft.primaryDepartment', 'draftPrimaryDept')
      .leftJoin('draft.primaryMinistry', 'draftPrimaryMin')
      .leftJoin('draft.igom', 'draftIgom');

    // ✅ SELECT (JSONB CAST FIX APPLIED)
    qb.select([
      'draft.id AS id',
      'draft.role AS role',
      'draft.draft_status AS draftstatus',
      'draft.meeting_date AS meetingdate',
      'draft.hlc_ref_id AS hlcrefid',
      'draft.related_to_hlc AS ishlcrelated',
      'COALESCE(draft.budgetary_category,recommendation.budgetary_category) AS budgetarycategory',
      'COALESCE(draft.proposal_nature,recommendation.proposal_nature) AS proposalnature',
      'COALESCE(draft.implementing_agency,recommendation.implementing_agency) AS implementingagency',

      'COALESCE(draft.recommendation_slug, recommendation.recommendation_slug) AS recommendationslug',
      'COALESCE(draft.name, recommendation.name) AS name',
      'COALESCE(draft.description, recommendation.description) AS description',
      'COALESCE(draft.timeline, recommendation.timeline) AS timeline',
      'COALESCE(draft.report_number, recommendation.report_number) AS reportnumber',

      // ✅ KEY FIX HERE
      `COALESCE(draft.department_ids::jsonb, '[]'::jsonb) AS draftdepartmentids`,
      `COALESCE(draft.ministry_ids::jsonb, '[]'::jsonb) AS draftministryids`,

      'recDept.id AS recdeptid',
      'recMin.id AS recminid',

      'draft.current_status AS currentstatus',
      'draft.action_taken_by_ministry AS actiontakenbyministry',
      'draft.reason_not_implemented AS reasonnotimplemented',

      'recPrimaryDept.id AS recprimarydeptid',
      'recPrimaryDept.name AS recprimarydeptname',
      'recPrimaryMin.id AS recprimaryminid',
      'recPrimaryMin.name AS recprimaryminname',

      'draftPrimaryDept.id AS draftprimarydeptid',
      'draftPrimaryDept.name AS draftprimarydeptname',
      'draftPrimaryMin.id AS draftprimaryminid',
      'draftPrimaryMin.name AS draftprimaryminname',

      'draftIgom.id AS draftigomid',
      'draftIgom.name AS draftigomname',
      'draftIgom.slug AS draftigomslug',

      'recIgom.id AS recigomid',
      'recIgom.name AS recigomname',
      'recIgom.slug AS recigomslug',
    ]);

    // ✅ BASE CONDITIONS
    qb.where('draft.user_id = :userId', { userId }).andWhere(
      'draft.draft_status = :draftStatus',
      {
        draftStatus: 'pending',
      },
    );

    // ✅ FILTERS
    if (departmentId) {
      qb.andWhere(`draft.department_ids::jsonb @> :departmentId`, {
        departmentId: JSON.stringify([departmentId]),
      });
    }

    if (ministryId) {
      qb.andWhere(`draft.ministry_ids::jsonb @> :ministryId`, {
        ministryId: JSON.stringify([ministryId]),
      });
    }

    if (igomId) {
      qb.andWhere('draft.igom_id = :igomId', { igomId });
    }

    if (proposalNature) {
      qb.andWhere('draft.proposal_nature = :proposalNature', {
        proposalNature,
      });
    }

    if (implementingAgency) {
      qb.andWhere('draft.implementing_agency = :implementingAgency', {
        implementingAgency,
      });
    }

    if (budgetaryCategory) {
      qb.andWhere('draft.budgetary_category = :budgetaryCategory', {
        budgetaryCategory,
      });
    }

    if (meetingDate) {
      const parsedDate = new Date(meetingDate);
      if (isNaN(parsedDate.getTime())) {
        throw new BadRequestException('Invalid date format');
      }

      qb.andWhere(
        `EXTRACT(MONTH FROM recommendation.created_at) = :month 
       AND EXTRACT(YEAR FROM recommendation.created_at) = :year`,
        {
          month: parsedDate.getMonth() + 1,
          year: parsedDate.getFullYear(),
        },
      );
    }

    if (status) {
      qb.andWhere('draft.draft_status = :status', { status });
    }

    if (reportNumber) {
      qb.andWhere(
        `COALESCE(draft.report_number, recommendation.report_number) ILIKE :reportNumber`,
        { reportNumber: `%${reportNumber}%` },
      );
    }

    if (search) {
      qb.andWhere(
        `(COALESCE(draft.name, recommendation.name) ILIKE :search
      OR COALESCE(draft.description, recommendation.description) ILIKE :search
      OR COALESCE(draft.recommendation_slug, recommendation.recommendation_slug) ILIKE :search)`,
        { search: `%${search}%` },
      );
    }

    // ✅ PAGINATION
    qb.orderBy('draft.updated_at', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    const [rawRows, total] = await Promise.all([
      qb.getRawMany(),
      qb.getCount(),
    ]);

    // ✅ PRELOAD IDS (NO PARSING NEEDED)
    const allDeptIds = new Set<number>();
    const allMinIds = new Set<number>();

    rawRows.forEach((row) => {
      row.draftdepartmentids.forEach((id: number) => allDeptIds.add(id));
      row.draftministryids.forEach((id: number) => allMinIds.add(id));

      if (row.recdeptid) allDeptIds.add(row.recdeptid);
      if (row.recminid) allMinIds.add(row.recminid);
    });

    const departments = await this.departmentRepository.find({
      where: { id: In([...allDeptIds]) },
      relations: ['ministry'],
    });

    const ministries = await this.ministryRepository.find({
      where: { id: In([...allMinIds]) },
    });

    const deptMap = new Map(departments.map((d) => [d.id, d]));
    const minMap = new Map(ministries.map((m) => [m.id, m]));

    // ✅ FORMAT RESPONSE
    const results = rawRows.map((row) => {
      const deptIds =
        row.draftdepartmentids.length > 0
          ? row.draftdepartmentids
          : row.recdeptid
            ? [row.recdeptid]
            : [];

      const minIds =
        row.draftministryids.length > 0
          ? row.draftministryids
          : row.recminid
            ? [row.recminid]
            : [];

      const implementingMinistries = minIds.map((minId: number) => {
        const ministry = minMap.get(minId);

        return {
          id: ministry?.id,
          name: ministry?.name,
          departments: deptIds
            .map((dId: number) => deptMap.get(dId))
            .filter((d) => d && d.ministry?.id === minId)
            .map((d) => ({
              id: d.id,
              name: d.name,
            })),
        };
      });

      return {
        id: row.id,
        recommendationSlug: row.recommendationslug,
        name: row.name,
        description: row.description,

        implementingMinistries,

        primaryDepartment: row.draftprimarydeptid
          ? { id: row.draftprimarydeptid, name: row.draftprimarydeptname }
          : row.recprimarydeptid
            ? { id: row.recprimarydeptid, name: row.recprimarydeptname }
            : null,

        primaryMinistry: row.draftprimaryminid
          ? { id: row.draftprimaryminid, name: row.draftprimaryminname }
          : row.recprimaryminid
            ? { id: row.recprimaryminid, name: row.recprimaryminname }
            : null,

        igom: row.draftigomid
          ? {
              id: row.draftigomid,
              name: row.draftigomname,
              slug: row.draftigomslug,
            }
          : row.recigomid
            ? {
                id: row.recigomid,
                name: row.recigomname,
                slug: row.recigomslug,
              }
            : null,

        timeline: row.timeline,
        reportNumber: row.reportnumber,

        currentStatus: row.currentstatus,
        actionTakenByMinistry: row.actiontakenbyministry,
        reasonNotImplemented: row.reasonnotimplemented,

        draftStatus: row.draftstatus,
        role: row.role,
        meetingDate: row.meetingdate,
        hlcRefId: row.hlcrefid,
        isHlcRelated: row.ishlcrelated,
        budgetaryCategory: row.budgetarycategory,
        proposalNature: row.proposalnature,
        implAgency: row.implementingagency,
      };
    });

    return {
      total,
      page,
      limit,
      results,
    };
  }
  async approveRejectDraft(
    draftId: number,
    body: IgomApproveRejectDraftDto,
    userId: number,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });

    if (!user) {
      throw new BadRequestException('Invalid user');
    }

    const draft = await this.igomRecommendationDraftRepository.findOne({
      where: { id: draftId, draftStatus: DraftStatusEnum.PENDING },
      relations: [
        'igomRecommendation',
        'igom',
        'user',
        'primaryDepartment',
        'primaryMinistry',
      ],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found or already processed');
    }

    if (user.id !== draft.user?.id) {
      throw new BadRequestException('You cannot approve / reject this draft');
    }

    // ✅ REJECT
    if (body.status === DraftStatusEnum.REJECTED) {
      draft.draftStatus = DraftStatusEnum.REJECTED;
      await this.igomRecommendationDraftRepository.save(draft);

      return { message: 'Draft rejected successfully' };
    }

    // ✅ USE IDS DIRECTLY
    const departmentIds: number[] = draft.departmentIds ?? [];
    const ministryIds: number[] = draft.ministryIds ?? [];

    // ---------------- APPROVE ----------------

    // ✅ CREATE (DEA / NITI Director case)
    if (draft.role === RoleEnum.DEA_DIRECTOR && !draft.igomRecommendation) {
      await this.igomRecommendationService.createRecommendation(
        {
          recommendationSlug: draft.recommendationSlug || '',
          name: draft.name || '',
          description: draft.description || '',

          departmentIds,
          ministryIds,

          primaryDepartmentId: draft.primaryDepartment?.id || 0,
          primaryMinistryId: draft.primaryMinistry?.id || 0,
          igomId: draft.igom?.id || 0,

          timeline: draft.timeline,
          reportNumber: draft.reportNumber || '',

          BudgetaryCategory: draft.budgetaryCategory ?? '',
          proposalNature: draft.proposalNature ?? '',
          meetingDate: draft.meetingDate ?? new Date(),
          implementingAgency: draft.implementingAgency ?? '',
        },
        userId,
      );
    }

    // ✅ MINISTRY DIRECTOR FLOW
    else if (draft.role === RoleEnum.MINISTRY_DIRECTOR) {
      if (!draft.igomRecommendation) {
        throw new BadRequestException('Recommendation not linked');
      }

      await this.igomRecommendationService.ministryDirectorRequest(
        {
          status: draft.currentStatus as StatusEnum,
          actionTakenByMinistry: draft.actionTakenByMinistry || '',
          reasonIfNotImplemented: draft.reasonNotImplemented || '',
          hlcRefId: draft.hlcRefId ?? '',
          isHlcRelated: draft.relatedToHlc ?? false,
        },
        draft.igomRecommendation.id,
        userId,
        true,
      );
    }

    // ✅ FINAL UPDATE
    draft.draftStatus = DraftStatusEnum.APPROVED;
    await this.igomRecommendationDraftRepository.save(draft);

    return { message: 'Draft approved successfully' };
  }

  async editDraft(
    draftId: number,
    body: IgomRecommendationDraftDto,
    userId: number,
  ) {
    const {
      departmentIds = [],
      ministryIds = [],
      primaryMinistryId,
      primaryDepartmentId,
      igomId,
    } = body;

    const departmentIdsSafe = Array.isArray(departmentIds)
      ? departmentIds
      : departmentIds
        ? [Number(departmentIds)]
        : [];

    const ministryIdsSafe = Array.isArray(ministryIds)
      ? ministryIds
      : ministryIds
        ? [Number(ministryIds)]
        : [];

    if (departmentIdsSafe.some((id) => !Number.isFinite(Number(id)))) {
      throw new BadRequestException(
        'departmentIds must be an array of numbers',
      );
    }

    if (ministryIdsSafe.some((id) => !Number.isFinite(Number(id)))) {
      throw new BadRequestException('ministryIds must be an array of numbers');
    }

    const draft = await this.igomRecommendationDraftRepository.findOne({
      where: { id: draftId },
      relations: ['user', 'primaryMinistry', 'primaryDepartment', 'igom'],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found');
    }

    if (draft.draftStatus !== DraftStatusEnum.PENDING) {
      throw new ForbiddenException('Only pending drafts can be edited');
    }

    if (draft.user?.id !== userId) {
      throw new ForbiddenException('You are not allowed to edit this draft');
    }

    // ---------------- SLUG CONFLICT ----------------
    if (body.recommendationSlug) {
      const existingSlug = await this.igomRecommendationDraftRepository.findOne(
        {
          where: {
            recommendationSlug: body.recommendationSlug,
            id: Not(draft.id),
            draftStatus: DraftStatusEnum.PENDING,
          },
        },
      );

      if (existingSlug) {
        throw new ConflictException(
          'Draft with this recommendation id already exists',
        );
      }
    }

    // ---------------- PRIMARY ENTITIES ----------------
    let primaryDepartment: Departments | null = null;
    let primaryMinistry: Ministry | null = null;
    let igom: Igom | null = null;

    if (primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: primaryDepartmentId },
        relations: ['ministry'],
      });

      if (!primaryDepartment) {
        throw new NotFoundException(
          `Department with ID ${primaryDepartmentId} not found`,
        );
      }
    }

    if (primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: primaryMinistryId },
      });

      if (!primaryMinistry) {
        throw new NotFoundException(
          `Ministry with ID ${primaryMinistryId} not found`,
        );
      }
    }

    if (
      primaryDepartment &&
      primaryDepartment?.ministry?.id !== primaryMinistryId
    ) {
      throw new BadRequestException(
        `Primary Department belongs to ministry ${primaryDepartment.ministry?.id}`,
      );
    }

    if (igomId) {
      igom = await this.igomRepository.findOne({
        where: { id: igomId },
      });

      if (!igom) {
        throw new NotFoundException(`Igom with ID ${igomId} not found`);
      }
    }

    // ---------------- FETCH ENTITIES ----------------
    const departments = await this.departmentRepository.find({
      where: { id: In(departmentIdsSafe) },
      relations: ['ministry'],
    });

    const ministries = await this.ministryRepository.find({
      where: { id: In(ministryIdsSafe) },
    });

    const departmentMap = new Map(departments.map((d) => [d.id, d]));
    const ministryMap = new Map(ministries.map((m) => [m.id, m]));

    departmentIdsSafe.forEach((id) => {
      if (!departmentMap.has(id)) {
        throw new NotFoundException(`Department with ID ${id} not found`);
      }
    });

    ministryIdsSafe.forEach((id) => {
      if (!ministryMap.has(id)) {
        throw new NotFoundException(`Ministry with ID ${id} not found`);
      }
    });

    // ---------------- BUILD PAIRS ----------------
    const pairs: { department: any; ministry: any }[] = [];
    const ministriesWithDepts = new Set<number>();

    for (const department of departments) {
      if (department.ministry) {
        if (!ministryMap.has(department.ministry.id)) {
          throw new NotFoundException(
            `Department ${department.id} has ministry ${department.ministry.id} not in payload`,
          );
        }

        pairs.push({
          department,
          ministry: ministryMap.get(department.ministry.id),
        });

        ministriesWithDepts.add(department.ministry.id);
      } else {
        pairs.push({ department, ministry: null });
      }
    }

    for (const ministry of ministries) {
      if (!ministriesWithDepts.has(ministry.id)) {
        pairs.push({ department: null, ministry });
      }
    }

    // ---------------- CONFLICT CHECK ----------------
    if (body.recommendationSlug) {
      const drafts = await this.igomRecommendationDraftRepository.find({
        where: {
          recommendationSlug: body.recommendationSlug,
          draftStatus: In([DraftStatusEnum.PENDING, DraftStatusEnum.APPROVED]),
          id: Not(draft.id),
        },
      });

      for (const { department, ministry } of pairs) {
        // Existing recommendation
        const existing = await this.igomRecommendationRepository.findOne({
          where: {
            recommendationSlug: body.recommendationSlug,
            department: department ? { id: department.id } : IsNull(),
            ministry: ministry ? { id: ministry.id } : IsNull(),
          },
        });

        if (existing) {
          throw new ConflictException(
            `Recommendation already exists for department ${department?.id ?? ''}/ministry ${ministry?.id ?? ''}`,
          );
        }

        // Draft conflict (ID based)
        const conflictDraft = drafts.find((d) => {
          const draftDeptIds: number[] = d.departmentIds ?? [];
          const draftMinIds: number[] = d.ministryIds ?? [];

          const deptMatch = department
            ? draftDeptIds.includes(department.id)
            : draftDeptIds.length === 0;

          const minMatch = ministry
            ? draftMinIds.includes(ministry.id)
            : draftMinIds.length === 0;

          return deptMatch && minMatch;
        });

        if (conflictDraft) {
          throw new ConflictException(
            `Draft already exists for department ${department?.id ?? ''} and ministry ${ministry?.id ?? ''}`,
          );
        }
      }
    }

    // ---------------- UPDATE DRAFT ----------------
    if (draft.role === RoleEnum.DEA_DIRECTOR) {
      Object.assign(draft, {
        recommendationSlug: body.recommendationSlug ?? draft.recommendationSlug,
        name: body.name ?? draft.name,
        description: body.description ?? draft.description,

        departmentIds:
          body.departmentIds !== undefined
            ? departmentIdsSafe
            : draft.departmentIds,
        ministryIds:
          body.ministryIds !== undefined ? ministryIdsSafe : draft.ministryIds,

        igom: igom ?? draft.igom,
        primaryDepartment: primaryDepartment ?? draft.primaryDepartment,
        primaryMinistry: primaryMinistry ?? draft.primaryMinistry,

        timeline: body.timeline ?? draft.timeline,
        reportNumber: body.reportNumber ?? draft.reportNumber,

        budgetaryCategory: body.BudgetaryCategory ?? draft.budgetaryCategory,
        proposalNature: body.proposalNature ?? draft.proposalNature,
        meetingDate: body.meetingDate ?? draft.meetingDate,
        implementingAgency: body.implementingAgency ?? draft.implementingAgency,
      });
    } else if (draft.role === RoleEnum.MINISTRY_DIRECTOR) {
      Object.assign(draft, {
        currentStatus: body.status ?? draft.currentStatus,
        actionTakenByMinistry:
          body.actionTakenByMinistry ?? draft.actionTakenByMinistry,
        reasonNotImplemented:
          body.reasonIfNotImplemented ?? draft.reasonNotImplemented,
        relatedToHlc: body.isHlcRelated ?? draft.relatedToHlc,
        hlcRefId: body.hlcRefId ?? draft.hlcRefId,
      });
    }

    // ✅ SAVE ONCE (FIXED)
    await this.igomRecommendationDraftRepository.save(draft);

    return {
      message: 'Draft updated successfully',
      data: draft,
    };
  }
  async deleteDraft(draftId: number, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role', 'ministry'],
    });

    if (!user) {
      throw new BadRequestException('Invalid user');
    }

    const draft = await this.igomRecommendationDraftRepository.findOne({
      where: { id: draftId },
      relations: ['igomRecommendation', 'user'],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found');
    }

    if (draft.draftStatus !== DraftStatusEnum.PENDING) {
      throw new BadRequestException('Only pending drafts can be deleted');
    }

    if (user.id !== draft.user?.id) {
      throw new ForbiddenException(
        'You do not have permission to delete this draft',
      );
    }

    await this.igomRecommendationDraftRepository.remove(draft);

    return {
      message: 'Draft deleted successfully',
    };
  }
}

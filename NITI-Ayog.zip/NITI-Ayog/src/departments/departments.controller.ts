import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { DepartmentsService } from './departments.service';
import {
  CreateDepartmentDto,
  DepartmentListDto,
  MultipleDepartmentDto,
  UpdateDepartmentDto,
} from './dto/departments.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
import { Public } from 'src/decorators/public.decorator';

@ApiTags('Departments')
@Controller({
  path: 'departments',
  version: '1',
})
export class DepartmentsController {
  constructor(private readonly departmentsService: DepartmentsService) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_DEPARTMENT)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Create a new department' })
  async createDepartment(@Body() createDepartmentDto: CreateDepartmentDto) {
    return await this.departmentsService.createDepartment(createDepartmentDto);
  }

  @Public()
  @Get('list')
  @ApiOperation({ summary: 'Get all departments' })
  async getAllDepartments(@Query() query: DepartmentListDto) {
    return await this.departmentsService.getAllDepartments(query);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_DEPARTMENT)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Update a department by ID' })
  @ApiParam({ name: 'id', type: Number, description: 'Department ID' })
  async updateDepartment(
    @Param('id') id: number,
    @Body() dto: UpdateDepartmentDto,
  ) {
    return await this.departmentsService.updateDepartment(id, dto);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DELETE_DEPARTMENT)
  @ApiBearerAuth()
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a department by ID' })
  @ApiParam({ name: 'id', type: Number, description: 'Department ID' })
  async deleteDepartment(@Param('id') id: number) {
    return await this.departmentsService.deleteDepartment(id);
  }

    @Public()
  @Get('multiple-minsistry/list')
  @ApiOperation({ summary: 'Get multiple ministry departments' })
  async getMultipleMinistryDepartments(@Query() query: MultipleDepartmentDto) {
    return await this.departmentsService.getMultipleDepartments(query);
  }

}

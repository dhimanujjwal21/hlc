import { Module } from '@nestjs/common';
import { DepartmentsController } from './departments.controller';
import { DepartmentsService } from './departments.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Departments } from 'src/entities/departments.entity';
import { JwtService } from '@nestjs/jwt';
import { Ministry } from 'src/entities/ministry.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Departments, Ministry])],
  controllers: [DepartmentsController],
  providers: [DepartmentsService, JwtService],
  exports: [],
})
export class DepartmentsModule {}

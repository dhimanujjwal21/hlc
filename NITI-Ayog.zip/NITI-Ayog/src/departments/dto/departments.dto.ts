import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, IsInt, Min, IsArray } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateDepartmentDto {
  @ApiProperty({
    example: 'Finance Department',
    description: 'Name of the department',
  })
  @IsNotEmpty({ message: 'Department name is required' })
  @IsString({ message: 'Department name must be a string' })
  name!: string;

  @ApiProperty({
    example: 3,
    description: 'ID of the ministry to which this department belongs',
  })
  @IsNotEmpty({ message: 'Ministry ID is required' })
  @Type(() => Number)
  @IsInt({ message: 'Ministry ID must be an integer' })
  @Min(1, { message: 'Ministry ID must be greater than zero' })
  ministryId!: number;
}

export class UpdateDepartmentDto extends PartialType(CreateDepartmentDto) {
  @ApiPropertyOptional({
    example: 'Updated Department Name',
    description: 'New name of the department (optional)',
  })
  @IsOptional()
  @IsString({ message: 'Department name must be a string' })
  name?: string;

  @ApiPropertyOptional({
    example: 5,
    description: 'Updated Ministry ID (optional)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'Ministry ID must be an integer' })
  @Min(1, { message: 'Ministry ID must be greater than zero' })
  ministryId?: number;
}

export class DepartmentListDto {
  @ApiPropertyOptional({
    example: 5,
    description: 'Ministry ID (optional)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'Ministry ID must be an integer' })
  @Min(1, { message: 'Ministry ID must be greater than zero' })
  ministryId?: number;
}

export class MultipleDepartmentDto {
    @ApiPropertyOptional({
      description: 'multiple ministries ids',
      type: [Number],
      example: [1, 2, 3],
    })
    @IsOptional()
    @IsArray()
    @Type(() => Number)
    @IsInt({ each: true })
    ministryIds?: number[];
  
}

import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Departments } from '../entities/departments.entity';
import {
  CreateDepartmentDto,
  DepartmentListDto,
  MultipleDepartmentDto,
  UpdateDepartmentDto,
} from './dto/departments.dto';
import { Ministry } from 'src/entities/ministry.entity';

@Injectable()
export class DepartmentsService {
  constructor(
    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,
  ) {}

  async createDepartment(dto: CreateDepartmentDto) {
    const { name, ministryId } = dto;

    const normalizedName = name.trim();

    if (!normalizedName) {
      throw new BadRequestException('Department name cannot be empty');
    }

    const ministry = await this.ministryRepository.findOne({
      where: { id: ministryId },
    });

    if (!ministry) {
      throw new BadRequestException('Ministry does not exist');
    }

    const existingDepartment = await this.departmentRepository.findOne({
      where: { name: normalizedName },
    });

    if (existingDepartment) {
      throw new BadRequestException(
        `Department name "${normalizedName}" already exists`,
      );
    }

    const department = this.departmentRepository.create({
      name: normalizedName,
      ministry,
    });

    await this.departmentRepository.save(department);

    return {
      message: 'Department created successfully',
      department: {
        id: department.id,
        name: department.name,
        ministry: { id: ministry.id, name: ministry.name },
      },
    };
  }

  async getAllDepartments(query: DepartmentListDto) {
    const { ministryId } = query;

    const where: any = {};

    if (ministryId) {
      where.ministry = { id: ministryId };
    }

    const departments = await this.departmentRepository.find({
      where,
      relations: ['ministry'],
      order: { name: 'ASC' },
    });

    return departments.map((dept) => ({
      id: dept.id,
      name: dept.name,
      ministry: dept.ministry
        ? { id: dept.ministry.id, name: dept.ministry.name }
        : null,
    }));
  }

  async updateDepartment(id: number, dto: UpdateDepartmentDto) {
    const { name, ministryId } = dto;
    const department: any = await this.departmentRepository.findOne({
      where: { id },
    });
    if (!department) throw new NotFoundException('Department not found');

    const existing = await this.departmentRepository.findOne({
      where: { name },
    });

    if (existing && existing.id !== id) {
      throw new BadRequestException('Department name already exists');
    }

    if (ministryId) {
      const ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });

      if (!ministry) {
        throw new BadRequestException('Ministry does not exist');
      }
      department.ministry = ministry;
    }
    department.name = name;
    department.updatedAt = new Date();
    return await this.departmentRepository.save(department);
  }

  async deleteDepartment(id: number) {
    const department = await this.departmentRepository.findOne({
      where: { id },
    });
    if (!department) throw new NotFoundException('Department not found');

    await this.departmentRepository.delete(id);
    return { message: 'Department deleted successfully' };
  }

    async getMultipleDepartments(query: MultipleDepartmentDto) {
    const { ministryIds } = query;

    const where: any = {};

  if (ministryIds && ministryIds.length > 0) {
  where.ministry = { id: In(ministryIds) };
}

    const departments = await this.departmentRepository.find({
      where,
      relations: ['ministry'],
      order: { name: 'ASC' },
    });

    return departments.map((dept) => ({
      id: dept.id,
      name: dept.name,
      ministry: dept.ministry
        ? { id: dept.ministry.id, name: dept.ministry.name }
        : null,
    }));
  }

}

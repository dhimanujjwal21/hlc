import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { readFileSync } from 'fs';
import { join } from 'path';
import axios from 'axios';
import https from 'https';

import { Recommendation } from 'src/entities/recommendation.entity';
import { RoleEnum, StatusEnum } from 'src/constants/enums';
import { CC_EMAILS } from 'src/constants/constants';
import { EmailService } from './services/email.service';
import { ConfigService } from '@nestjs/config';
import { NotificationChannelEnum, NotificationLog, NotificationStatusEnum, NotificationTypeEnum } from 'src/entities/notification-log.entity';

@Injectable()
export class NotificationService {
  private readonly DAILY_LIMIT = 15;

  constructor(
    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,

    @InjectRepository(NotificationLog)
    private readonly notificationLogRepository: Repository<NotificationLog>,

    private readonly emailService: EmailService,
    private readonly configService: ConfigService,
  ) { }

  /* -------------------------------------------------------------------------- */
  /*                               TEMPLATE UTILS                                */
  /* -------------------------------------------------------------------------- */

  private getTemplate(path: string): string {
    return readFileSync(join(__dirname, path), 'utf8');
  }

  private buildEmailHtml(
    templatePath: string,
    rows: string,
    extra?: Record<string, string>,
  ): string {
    let html = this.getTemplate(templatePath).replace('{{rows}}', rows);

    if (extra) {
      Object.entries(extra).forEach(([key, value]) => {
        html = html.replace(`{{${key}}}`, value);
      });
    }

    return html;
  }

  private formatDate(date: Date): string {
    return date.toLocaleDateString('en-IN', {
      timeZone: 'Asia/Kolkata',
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });
  }

  private getWeeklyBatchKey(date = new Date()): string {
    const year = date.getUTCFullYear();
    const week = Math.ceil(
      (((date.getTime() - new Date(year, 0, 1).getTime()) / 86400000) +
        new Date(year, 0, 1).getDay() +
        1) /
      7,
    );
    return `${year}-W${week}`;
  }

  private today(): string {
    return new Date().toISOString().slice(0, 10);
  }

  /* -------------------------------------------------------------------------- */
  /*                               HTML BUILDERS                                 */
  /* -------------------------------------------------------------------------- */

  private buildOverDueRows(list: any[]): string {
    return list
      .map(
        (item) => `
        <tr>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug[0]}</td>
          <td style="border:1px solid #000; text-align:center">${item.reportNumber}</td>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug}</td>
        </tr>`,
      )
      .join('');
  }

  private buildDueRows(list: any[]): string {
    return list
      .map(
        (item) => `
        <tr>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug[0]}</td>
          <td style="border:1px solid #000; text-align:center">${item.reportNumber}</td>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug}</td>
          <td style="border:1px solid #000; text-align:center">
            ${this.formatDate(new Date(item.updatedTimeline || item.timeline))}
          </td>
        </tr>`,
      )
      .join('');
  }

  /* -------------------------------------------------------------------------- */
  /*                                 SMS UTILS                                   */
  /* -------------------------------------------------------------------------- */

  private async sendSMS(
    numbers: string[],
    message: string,
    smsTemplateId: string,
    smsSignature: string,
  ): Promise<void> {
    if (!numbers || numbers.length === 0) return;

    const url =
      `${this.configService.get('SMS_BASE_URL')}?` +
      `username=${this.configService.get('SMS_USERNAME')}&` +
      `pin=${this.configService.get('SMS_PIN')}&` +
      `message=${message}&` +
      `mnumber=${numbers.join(',')}&` +
      `signature=${smsSignature}&` +
      `dlt_entity_id=${this.configService.get('SMS_DLT_ENTITY_ID')}&` +
      `dlt_template_id=${smsTemplateId}`;

    // const url =
    // `${this.configService.get('SMS_BASE_URL')}?` +
    // `username=hlcalt.sms&` +
    // `pin=Nic%40%232025&` +
    // `message=${message}&` +
    // `mnumber=${numbers.join(',')}&` +
    // `signature=HLCALT&` +
    // `dlt_entity_id=1101612760000040914&` +
    // `dlt_template_id=1107176561231338477`;

    //    console.log('SMS URL --->', url);
    try {
      const response = await axios.get(url, {
        httpsAgent: new https.Agent({ rejectUnauthorized: false }),
        timeout: 15000,
      });

      // console.log('SMS sent successfully', {
      //   numbers,
      //   response: response.data,
      // });
    } catch (error: any) {
      /*       console.error('SMS sending failed', {
        numbers,
        message,
        error: error?.response?.data || error?.message,
      });
 */
      throw new Error(
        `SMS gateway failure: ${error?.response?.data || error?.message}`,
      );
    }
  }

  /* -------------------------------------------------------------------------- */
  /*                          COMMON NOTIFICATION DISPATCHER                     */
  /* -------------------------------------------------------------------------- */

  private async notify(
    channel: 'email' | 'sms' | 'both',
    emails: string[],
    mobiles: string[],
    email?: { subject: string; html: string },
    sms?: {
      smsTemplateId: string;
      smsSignature: string;
      message: string;
    },
  ): Promise<void> {
    const tasks: Promise<any>[] = [];

    if ((channel === 'email' || channel === 'both') && email) {
      tasks.push(
        this.emailService.sendEmail(
          emails,
          CC_EMAILS,
          // ['rambirla022@gmail.com'],
          email.subject,
          email.html,
        ),
      );
    }

    if ((channel === 'sms' || channel === 'both') && sms) {
      tasks.push(
        this.sendSMS(mobiles, sms.message, sms.smsTemplateId, sms.smsSignature),
      );
    }

    await Promise.all(tasks);
  }

  /* -------------------------------------------------------------------------- */
  /*                        FETCH OVERDUE RECOMMENDATIONS                        */
  /* -------------------------------------------------------------------------- */

  async fetchOverdueRecommendation() {
    const rows = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'hlc')
      .leftJoin(
        't_users',
        'u',
        `
        u.ministry_id = m.id
        AND (r.department_id IS NULL OR u.department_id = r.department_id)
      `,
      )
      .leftJoin(
        't_roles',
        'role',
        `
        role.id = u.role_id
        AND role.roleName IN (:...roles)
      `,
      )
      .select([
        'm.id AS ministry_id',
        'm.name AS ministry_name',
        'r.id AS recommendation_id',
        'r.recommendationSlug AS recommendation_slug',
        'r.reportNumber AS report_number',
        'r.department_id AS recommendation_department_id',
        'r.updated_timeline AS updated_timeline',
        'r.timeline AS timeline',
        'hlc.name AS hlc_name',
        'hlc.slug AS hlc_slug',
        'u.email AS user_email',
        'u.mobileNumber AS mobile_number',
        'role.roleName AS role_name'
      ])
      .where(`COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE`)
      .andWhere(
        `
        (
          r.current_status IN (:...statuses)
          OR r.current_status IS NULL
          OR r.current_status = ''
        )
      `,
      )
      .andWhere('r.niti_approved = true')
      .andWhere('r.current_stage != :closedStage', {
        closedStage: 'Closed by HLC',
      })
      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
        roles: [
          RoleEnum.MINISTRY_APPROVER,
          RoleEnum.MINISTRY_DIRECTOR,
          RoleEnum.MINISTRY_SECRETARY,
        ],
      })
      .orderBy('r.recommendationSlug', 'ASC')
      .getRawMany();

    return this.groupMinistryWise(rows);
  }

  /* -------------------------------------------------------------------------- */
  /*                  FETCH OVERDUE RECOMMENDATIONS 15 Emails                    */
  /* -------------------------------------------------------------------------- */

  async processOverdueRecommendationsBatch(channel: 'email' | 'sms' | 'both') {
    const batchKey = this.getWeeklyBatchKey();
    const today = this.today();

    const sentCount = await this.notificationLogRepository.count({
      where: {
        type: NotificationTypeEnum.OVERDUE_RECOMMENDATION,
        batchKey,
        status: NotificationStatusEnum.SENT,
        notificationDate: today,
      },
    });

    console.log("Sent Count -->", sentCount)

    if (sentCount >= this.DAILY_LIMIT) {
      return { message: 'Daily limit already reached' };
    }

    // 2️⃣ Fetch overdue ministries
    let ministries = await this.fetchOverdueRecommendation();

    console.log("TOTAL -->", ministries.length)
    const alreadyProcessed = await this.notificationLogRepository.find({
      where: {
        type: NotificationTypeEnum.OVERDUE_RECOMMENDATION,
        batchKey,
        status: NotificationStatusEnum.SENT,
      },
      relations: ['ministry', 'department'],
      select: {
        ministry: { id: true },
        department: { id: true },
      },
    });

    const processedKeys = new Set(
      alreadyProcessed.map(
        (l) =>
          `${l.ministry?.id}_${l.department?.id ?? 'ALL'}`,
      ),
    );

    console.log(processedKeys);

    ministries = ministries
      .filter(
        (m) =>
          !processedKeys.has(
            `${m.ministryId}_${m.departmentId ?? 'ALL'}`,
          ),
      )
      .slice(0, this.DAILY_LIMIT - sentCount);

    // 4️⃣ Send notifications one-by-one (safe logging)
    for (const ministry of ministries) {
      await this.sendOverdueForMinistry(
        ministry,
        channel,
        batchKey,
        today,
      );
    }

    return {
      message: `Processed ${ministries.length} ministries for batch ${batchKey}`,
    };
  }

  private async sendOverdueForMinistry(
    ministry: any,
    channel: 'email' | 'sms' | 'both',
    batchKey: string,
    today: string,
  ) {
    try {
      await this.notify(
        channel,
        // ['ram.birla@in.ey.com'],
        // ['8516971855'],
        ministry.users.map((u) => u.email),
        ministry.users
          .filter((u) =>
            [RoleEnum.MINISTRY_APPROVER, RoleEnum.MINISTRY_DIRECTOR].includes(
              u.role,
            ),
          )
          .map((u) => u.mobileNumber),
        {
          subject: 'Overdue Recommendation(s) – reg',
          html: this.buildEmailHtml(
            '../resources/templates/email/overdue.html',
            this.buildOverDueRows(ministry.recommendations),
          ),
        },
        {
          smsTemplateId: this.configService.get<string>(
            'SMS_DLT_TEMPLATE_ID',
          )!,
          smsSignature: this.configService.get<string>(
            'SMS_SIGNATURE',
          )!,
          message:
            `Sir/Madam,%0A` +
            `Overdue+alert:+${ministry.recommendations.length}+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0A` +
            `Please+take+immediate+action.%0A` +
            `With+Regards,%0A` +
            `Team+HLC+Sameeksha+Portal%0A` +
            `NITI+Aayog`,
        },
      );

      await this.notificationLogRepository.insert({
        batchKey,
        ministry: { id: ministry.ministryId },
        department: ministry.departmentId
          ? { id: ministry.departmentId }
          : null,
        type: NotificationTypeEnum.OVERDUE_RECOMMENDATION,
        channel: channel as NotificationChannelEnum,
        status: NotificationStatusEnum.SENT,
        notificationDate: today,
        recommendationCount: ministry.recommendations.length,
      });
    } catch (error: any) {
      await this.notificationLogRepository.insert({
        batchKey,
        ministry: { id: ministry.ministryId },
        department: ministry.departmentId
          ? { id: ministry.departmentId }
          : null,
        type: NotificationTypeEnum.OVERDUE_RECOMMENDATION,
        channel: channel as NotificationChannelEnum,
        status: NotificationStatusEnum.FAILED,
        notificationDate: today,
        error: error?.message ?? 'Unknown error',
      });
    }
  }


  /* -------------------------------------------------------------------------- */
  /*                         FETCH DUE RECOMMENDATIONS                           */
  /* -------------------------------------------------------------------------- */

  async fetchDueRecommendations(days: number) {
    const rows = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'hlc')
      .leftJoin(
        't_users',
        'u',
        `
        u.ministry_id = m.id
        AND (r.department_id IS NULL OR u.department_id = r.department_id)
      `,
      )
      .leftJoin(
        't_roles',
        'role',
        `
        role.id = u.role_id
        AND role.roleName IN (:...roles)
      `,
      )
      .select([
        'm.id AS ministry_id',
        'm.name AS ministry_name',
        'r.id AS recommendation_id',
        'r.recommendationSlug AS recommendation_slug',
        'r.reportNumber AS report_number',
        'r.department_id AS recommendation_department_id',
        'r.updated_timeline AS updated_timeline',
        'r.timeline AS timeline',
        'hlc.name AS hlc_name',
        'hlc.slug AS hlc_slug',
        'u.email AS user_email',
        'u.mobileNumber AS mobile_number',
        'role.roleName AS role_name',
      ])
      .where(
        `
        (COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata')
          >= date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')
            + (:days || ' day')::interval
        AND
        (COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata')
          <  date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')
            + ((:days::int + 1) || ' day')::interval
        `,
        { days },
      )
      .andWhere(
        `
        (
          r.current_status IS NULL
          OR r.current_status = ''
          OR r.current_status IN (:...statuses)
        )
      `,
      )
      .andWhere('r.niti_approved = true')
      .andWhere('r.current_stage != :closedStage', {
      closedStage: 'Closed by HLC',
      })
      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
        roles: [RoleEnum.MINISTRY_APPROVER, RoleEnum.MINISTRY_DIRECTOR],
      })
      .orderBy('r.recommendationSlug', 'ASC')
      .getRawMany();

    return this.groupMinistryWise(rows);
  }

  /* -------------------------------------------------------------------------- */
  /*                         COMMON GROUPING LOGIC                               */
  /* -------------------------------------------------------------------------- */

  private groupMinistryWise(rows: any[]) {
    const map = new Map<string, any[]>();

    rows.forEach((r) => {
      const key = `${r.ministry_id}_${r.recommendation_department_id ?? 'ALL'}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(r);
    });

    return Array.from(map.values()).map((recs) => {
      const recMap = new Map<number, any>();
      const userMap = new Map<string, any>();

      recs.forEach((r) => {
        recMap.set(r.recommendation_id, {
          recommendationSlug: r.recommendation_slug,
          reportNumber: r.report_number,
          hlcSlug: r.hlc_slug,
          hlcName: r.hlc_name,
          updatedTimeline: r.updated_timeline,
          timeline: r.timeline,
        });

        if (r.user_email) {
          userMap.set(r.user_email, {
            email: r.user_email,
            mobileNumber: r.mobile_number,
            role: r.role_name,
          });
        }
      });

      return {
        ministryId: recs[0].ministry_id,
        ministryName: recs[0].ministry_name,
        departmentId: recs[0].recommendation_department_id,
        recommendations: Array.from(recMap.values()),
        users: Array.from(userMap.values()),
      };
    });
  }

  /* -------------------------------------------------------------------------- */
  /*                         PROCESS OVERDUE NOTIFICATIONS                       */
  /* -------------------------------------------------------------------------- */

  async processOverdueRecommendations(channel: 'email' | 'sms' | 'both') {
    let ministries = await this.fetchOverdueRecommendation();
    // ministries = [ministries[0]]
    await Promise.all(
      ministries.map((ministry) =>
        this.notify(
          channel,
          // ['ram.birla@in.ey.com'],
          // ['8516971855', '8817878003'],
          ministry.users.map((u) => u.email),
          ministry.users
            .filter(u => [RoleEnum.MINISTRY_APPROVER, RoleEnum.MINISTRY_DIRECTOR].includes(u.role))
            .map(u => u.mobileNumber),
          {
            subject: 'Overdue Recommendation(s) – reg',
            html: this.buildEmailHtml(
              '../resources/templates/email/overdue.html',
              this.buildOverDueRows(ministry.recommendations),
            ),
          },
          {
            smsTemplateId: <string>(
              this.configService.get('SMS_DLT_TEMPLATE_ID')
            ),
            smsSignature: <string>this.configService.get('SMS_SIGNATURE'),
            message:
              `Sir/Madam,%0A` +
              `Overdue+alert:+${ministry.recommendations.length || 0}+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0A` +
              `Please+take+immediate+action.%0A` +
              `With+Regards,%0A` +
              `Team+HLC+Sameeksha+Portal%0A` +
              `NITI+Aayog`,
            // `Sir/Madam,%0A` +
            // `Overdue+alert:+${ministry.recommendations.length}+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0A` +
            // `Please+take+immediate+action.%0A` +
            // `With+Regards%0A` +
            // `Team+HLC+Sameeksha+Portal%0A` +
            // `NITI+Aayog`,
          },
        ),
      ),
    );

    return { message: 'Notification Sent Successfully' };
  }

  /* -------------------------------------------------------------------------- */
  /*                           PROCESS DUE NOTIFICATIONS                         */
  /* -------------------------------------------------------------------------- */

  async processDueRecommendations(
    channel: 'email' | 'sms' | 'both',
    days: number,
  ) {
    let ministries = await this.fetchDueRecommendations(days);
    const today = new Date();
    const dueDate = new Date(today);
    dueDate.setDate(today.getDate() + days);
    const formattedDueDate = this.formatDate(dueDate);
    let subject = 'Timeline approaching for HLC Recommendation(s) - reg;';
    if (days === 14)
      subject = 'Timeline approaching for HLC Recommendation(s) - reg;';
    else if (days === 7)
      subject =
        'Alert: Timeline due within 7 days for HLC Recommendation(s) - reg;';
    else if (days === 1)
      subject =
        'Deadline Tomorrow: Timeline due for HLC Recommendation(s) - reg;';
    else if (days === 6)
      subject = 'Alert: Timeline due within 7 days for HLC Recommendation(s) - reg;';
    else if (days === 5)
      subject = 'Alert: Timeline due within 6 days for HLC Recommendation(s) - reg;';
    else subject = 'Timeline approaching for HLC Recommendation(s) - reg;';

    // const m = [ministries[0]]
    // await Promise.all(
    //   m.map((ministry) => {
    //     console.log(ministry.users.map((u) => u.email));
    //     this.notify(
    //       channel,
    //       ['ram.birla@in.ey.com', 'nancynikita.s@niti.gov.in'],
    //       ['9572425060', '8516971855'],
    //       {
    //         subject,
    //         html: this.buildEmailHtml(
    //           `../resources/templates/email/${days === 1 ? 1 : 7}due.html`,
    //           this.buildDueRows(ministry.recommendations),
    //           { date: formattedDueDate },
    //         ),
    //       },
    //       {
    //         smsTemplateId: <string>(
    //           this.configService.get('SMS_DLT_TEMPLATE_ID_TIMELINE')
    //         ),
    //         smsSignature: <string>(
    //           this.configService.get('SMS_SIGNATURE_TIMELINE')
    //         ),
    //         message:
    //           `Sir/Madam,%0A` +
    //           `Alert:+Implementation+timeline+of+${ministry.recommendations.length || 0}+Recommendation(s)+related+to+your+Ministry/Department+is/are+due+by+${encodeURIComponent(formattedDueDate)}.%0A` +
    //           `Please+take+necessary+action.%0A` +
    //           `With+Regards,%0A` +
    //           `Team+HLC+Sameeksha+Portal%0A` +
    //           `NITI+Aayog`,
    //       },
    //     );
    //   }),
    // );
    await Promise.all(
      ministries.map((ministry) => {
        console.log(ministry.users.map((u) => u.email));
        this.notify(
          channel,
          ministry.users.map((u) => u.email),
          ministry.users.map((u) => u.mobileNumber),
          {
            subject,
            html: this.buildEmailHtml(
              `../resources/templates/email/${days === 1 ? 1 : 7}due.html`,
              this.buildDueRows(ministry.recommendations),
              { date: formattedDueDate },
            ),
          },
          {
            smsTemplateId: <string>(
              this.configService.get('SMS_DLT_TEMPLATE_ID_TIMELINE')
            ),
            smsSignature: <string>(
              this.configService.get('SMS_SIGNATURE_TIMELINE')
            ),
            message:
              `Sir/Madam,%0A` +
              `Alert:+Implementation+timeline+of+${ministry.recommendations.length || 0}+Recommendation(s)+related+to+your+Ministry/Department+is/are+due+by+${encodeURIComponent(formattedDueDate)}.%0A` +
              `Please+take+necessary+action.%0A` +
              `With+Regards,%0A` +
              `Team+HLC+Sameeksha+Portal%0A` +
              `NITI+Aayog`,
          },
        );
      }),
    );

    return { message: 'Notification Sent Successfully' };
  }
}

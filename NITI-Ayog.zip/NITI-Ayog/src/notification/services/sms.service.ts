import { Inject, Injectable, Logger } from '@nestjs/common';
import { SNSClient, PublishCommand } from '@aws-sdk/client-sns';

@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private sns: SNSClient;
  private SMS_SENDER_D = process.env.SNS_SENDER_ID;
  private SNS_SMS_TYPE = process.env.SNS_SMS_TYPE;
  
  constructor(@Inject('AWS_CONFIG') private config: any) {
    this.sns = new SNSClient({
      region: this.config.region,
      credentials: this.config.credentials,
    });
  }

  async sendSms(phoneNumber: string, message: string) {
    try {
      const command = new PublishCommand({
        PhoneNumber: phoneNumber,
        Message: message,
      });

      await this.sns.send(command);
      this.logger.log(`SMS sent to ${phoneNumber}`);
      return true;
    } catch (err) {
      this.logger.error(`SMS sending failed: ${err}`);
      return false;
    }
  }
}

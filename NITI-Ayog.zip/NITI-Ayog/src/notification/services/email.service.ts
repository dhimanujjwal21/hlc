import { Inject, Injectable, Logger } from '@nestjs/common';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);
  private ses: SESClient;
  private fromEmail: string;

  constructor(@Inject('AWS_CONFIG') private config: any) {
    this.ses = new SESClient({
      region: this.config.region,
      credentials: this.config.credentials,
    });

    this.fromEmail = this.config.sesFromEmail;
  }

  async sendEmail(to: string[], cc: string[], subject: string, htmlBody: string) {
    try {
      const command = new SendEmailCommand({
        // Source: this.fromEmail,
        Source: `Update from HLC Sameeksha Portal <${this.fromEmail}>`,
        Destination: {
          ToAddresses: to,
          CcAddresses: cc || [],
        },
        Message: {
          Subject: { Data: subject },
          Body: { Html: { Data: htmlBody } },
        },
      });

      const res = await this.ses.send(command);
      /*       console.log("Result ====>", res)
      this.logger.log(`Email sent to ${to}`); */
      return true;
    } catch (err) {
      /*       console.log(err)
      this.logger.error(`Email sending failed: ${err}`); */
      return err;
    }
  }
}

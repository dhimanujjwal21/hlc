import {
  Controller,
  Get,
  Headers,
  Post,
  Query,
  UnauthorizedException,
} from '@nestjs/common';
import { NotificationService } from './notification.service';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('Notification')
@Controller({
  path: 'notification',
  version: '1',
})
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  @Post('send-overdue-alerts')
  async sendOverdueAlerts(
    @Headers('x-cron-secret') cronSecret: string,

    @Query('channel')
    channel: 'sms' | 'email' | 'both' = 'both',
  ) {
    if (!cronSecret || cronSecret !== process.env.CRON_SECRET) {
      throw new UnauthorizedException('Invalid cron secret');
    }

    const env = process.env.APP_ENV;

    if (env?.toLowerCase() === 'production') {
      if (channel === 'email') {
        return await this.notificationService.processOverdueRecommendationsBatch(
          channel,
        );
      }

      return await this.notificationService.processOverdueRecommendations(
        channel,
      );
    }

    return {
      message: 'Notification service disabled outside production environment',
    };
  }

  /*   @Get('send-overdue-alerts')
  async sendOverdueAlerts(
    @Query('channel') channel: 'sms' | 'email' | 'both' = 'both',
  ) {
    const env = process.env.APP_ENV;
    if (env?.toLowerCase() === 'production') {
      if (channel == 'email')
        return this.notificationService.processOverdueRecommendationsBatch(
          channel,
        );
      return this.notificationService.processOverdueRecommendations(channel);
    } else {
      // if(channel == 'email')
      //   return this.notificationService.processOverdueRecommendationsBatch(channel);
      // return this.notificationService.processOverdueRecommendations(channel);
    }
  }
 */
  /*   @Get('send-due-alerts')
  async sendDueAlerts(
    @Query('channel') channel: 'sms' | 'email' | 'both' = 'both',
    @Query('days') days: '14' | '7' | '1',
  ) {
    const env = process.env.APP_ENV;
    if (env?.toLowerCase() === 'production') {
      return this.notificationService.processDueRecommendations(channel, Number(days));
    } else {
      // return this.notificationService.processDueRecommendations(channel, Number(days));
    }
  }
 */

  @Post('send-due-alerts')
  async sendDueAlerts(
    @Headers('x-cron-secret') cronSecret: string,

    @Query('channel')
    channel: 'sms' | 'email' | 'both' = 'both',

    @Query('days')
    days: '14' | '7' | '1',
  ) {
    if (!cronSecret || cronSecret !== process.env.CRON_SECRET) {
      throw new UnauthorizedException('Invalid cron secret');
    }

    if (process.env.APP_ENV?.toLowerCase() === 'production') {
      return await this.notificationService.processDueRecommendations(
        channel,
        Number(days),
      );
    }

    return {
      message: 'Notification service disabled outside production environment',
    };
  }
}

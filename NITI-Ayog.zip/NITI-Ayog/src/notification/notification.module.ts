import { Module } from '@nestjs/common';
import { EmailService } from './services/email.service';
import { SmsService } from './services/sms.service';
import { NotificationController } from './notification.controller';
import { NotificationService } from './notification.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Recommendation } from 'src/entities/recommendation.entity';
import { NotificationLog } from 'src/entities/notification-log.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Recommendation, NotificationLog])],
  controllers: [NotificationController],
  providers: [
    {
      provide: 'AWS_CONFIG',
      useFactory: () => ({
        region: process.env.AWS_REGION,
        credentials: {
          accessKeyId: process.env.AWS_ACCESS_KEY,
          secretAccessKey: process.env.AWS_SECRET_KEY,
        },
        sesFromEmail: process.env.AWS_SES_EMAIL,
      }),
    },
    EmailService,
    SmsService,
    NotificationService,
  ],
  exports: [EmailService, SmsService, NotificationService],
})
export class NotificationModule {}

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { RoleEnum, StatusEnum } from 'src/constants/enums';
import { Recommendation } from 'src/entities/recommendation.entity';
import { Repository } from 'typeorm';
import { EmailService } from './services/email.service';
import { readFileSync } from 'fs';
import { join } from 'path';
import axios from 'axios';
import https from 'https';
import { CC_EMAILS } from 'src/constants/constants';
@Injectable()
export class NotificationService {
  /*   constructor(
    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,

    private emailService: EmailService,
  ) {}

  getTemplate(path: string): string {
    return readFileSync(join(__dirname, path), 'utf8');
  }

  buildOverDueRows(list: any[]) {
    return list
      .map(
        (item) => `
        <tr>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug[0]}</td>
          <td style="border:1px solid #000; text-align:center">${item.reportNumber}</td>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug}</td>
        </tr>
      `,
      )
      .join('');
  }

  buildDueRows(list: any[]) {
    return list
      .map(
        (item) => `
        <tr>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug[0]}</td>
          <td style="border:1px solid #000; text-align:center">${item.reportNumber}</td>
          <td style="border:1px solid #000; text-align:center">${item.recommendationSlug}</td>
          <td style="border:1px solid #000; text-align:center">${new Date(
            item.updatedTimeline || item.timeline,
          ).toLocaleDateString('en-IN', {
            timeZone: 'Asia/Kolkata',
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          })}
            </td>
        </tr>
      `,
      )
      .join('');
  }

  async sendSMSStaging(ministry: any) {
    const baseUrl = 'https://smsgw.sms.gov.in/failsafe/MLink';
    const numbers = ['9818434009', '9176784107', '8516971855', '8817878003'];
    const count = ministry.recommendations.length || 0;
    const message =
      `Sir/Madam,%0A` +
      `Overdue+alert:+${count}+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0A` +
      `Please+take+immediate+action.%0A` +
      `With+Regards%0A` +
      `Team+HLC+Sameeksha+Portal%0A` +
      `NITI+Aayog`;

    const url =
      `${baseUrl}?` +
      `username=hlcalt.sms&` +
      `pin=Nic%40%232025&` +
      `message=${message}&` +
      `mnumber=${numbers.join(',')}&` +
      `signature=HLCALT&` +
      `dlt_entity_id=1101612760000040914&` +
      `dlt_template_id=1107176561231338477`;

    try {
      const response = await axios.get(url, {
        httpsAgent: new https.Agent({
          rejectUnauthorized: false, // same as curl -k
        }),
      });

      console.log('SMS sent:', response.data);
    } catch (err: any) {
      console.error('SMS failed:', err.response?.data || err.message);
    }
  }

  async sendEmailStaging(ministry: any) {
    const template = this.getTemplate(
      '../resources/templates/email/overdue.html',
    );
    const rowsHtml = this.buildOverDueRows(ministry.recommendations);
    const html = template.replace('{{rows}}', rowsHtml);
    const userEmail = ['Anupam.Sahu@in.ey.com'];
    const cc = ['ram.birla@in.ey.com'];
    await this.emailService.sendEmail(
      userEmail,
      cc,
      'Overdue Recommendation(s) – reg',
      html,
    );
  }

  async processOverdueRecommendationsStaging(channel: string) {
    try {
      let ministryList = await this.fetchOverdueRecommendation();
      ministryList = [ministryList[0]];
      for (const ministry of ministryList) {
        if (channel === 'email' || channel === 'both')
          await this.sendEmailStaging(ministry);

        if (channel === 'sms' || channel === 'both')
          await this.sendSMSStaging(ministry);
      }

      return { message: 'Staging: Email Sent Successfully' };
    } catch (err) {
      console.error(err);
      throw err;
    }
  }

  async fetchOverdueRecommendation() {
    const recommendations = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'hlc')
      .leftJoin(
        't_users',
        'u',
        `
        u.ministry_id = m.id
        AND (
          r.department_id IS NULL
          OR u.department_id = r.department_id
        )
      `,
      )
      .select([
        'm.id AS ministry_id',
        'm.name AS ministry_name',
        'r.id AS recommendation_id',
        'r.recommendationSlug AS recommendation_slug',
        'r.reportNumber AS report_number',
        'r.department_id AS recommendation_department_id',
        'hlc.name AS hlc_name',
        'hlc.slug AS hlc_slug',
        'u.email AS user_email',
        'u.mobileNumber AS mobile_number',
        'u.department_id AS department_id',
      ])
      .where(`COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE`)
      .andWhere(
        `
      (
        r.current_status IN (:...statuses)
        OR r.current_status IS NULL
        OR r.current_status = ''
      )
    `,
      )
      .andWhere('r.niti_approved = true')
      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
      })
      .orderBy('r.recommendationSlug', 'ASC')
      .getRawMany();

    const ministryMap: Map<string, any[]> = new Map();

    recommendations.forEach((rec) => {
      const key = `${rec.ministry_id}_${rec.recommendation_department_id ?? 'ALL'}`;

      if (!ministryMap.has(key)) {
        ministryMap.set(key, []);
      }

      ministryMap.get(key)!.push(rec);
    });

    const ministries = Array.from(ministryMap.entries()).map(
      ([key, recs]: any) => {
        const { ministry_id, ministry_name, recommendation_department_id } =
          recs[0];

        // ---- Recommendations (unique) ----
        const recMap: Map<number, any> = new Map();
        recs.forEach((r) => {
          if (!recMap.has(r.recommendation_id)) {
            recMap.set(r.recommendation_id, {
              recommendationSlug: r.recommendation_slug,
              reportNumber: r.report_number,
              hlcSlug: r.hlc_slug,
              hlcName: r.hlc_name,
            });
          }
        });

        // ---- Users (unique) ----
        const usersMap: Map<string, any> = new Map();
        recs.forEach((r) => {
          if (r.user_email) {
            usersMap.set(r.user_email, {
              email: r.user_email,
              mobileNumber: r.mobile_number,
              departmentId: r.department_id,
            });
          }
        });

        const sortedRecommendations = Array.from(recMap.values()).sort(
          (a: any, b: any) =>
            a.recommendationSlug.localeCompare(
              b.recommendationSlug,
              undefined,
              {
                numeric: true,
                sensitivity: 'base',
              },
            ),
        );

        return {
          ministryId: ministry_id,
          ministryName: ministry_name,
          departmentId: recommendation_department_id, // NULL means ALL departments
          recommendations: sortedRecommendations,
          users: Array.from(usersMap.values()),
        };
      },
    );

    return ministries;
  }

  async sendSMS(numbers: any[], message: string) {
    const baseUrl = 'https://smsgw.sms.gov.in/failsafe/MLink';
    // const numbers = ['98111731300', '8516971855', '8817878003'];

    const url =
      `${baseUrl}?` +
      `username=hlcalt.sms&` +
      `pin=Nic%40%232025&` +
      `message=${message}&` +
      `mnumber=${numbers.join(',')}&` +
      `signature=HLCALT&` +
      `dlt_entity_id=1101612760000040914&` +
      `dlt_template_id=1107176561231338477`;

    try {
      const response = await axios.get(url, {
        httpsAgent: new https.Agent({
          rejectUnauthorized: false, // same as curl -k
        }),
      });

      console.log('SMS sent:', response.data);
    } catch (err: any) {
      console.error('SMS failed:', err.response?.data || err.message);
    }
  }

  async processOverdueRecommendations(channel: string) {
    try {
      const ministryList = await this.fetchOverdueRecommendation();

      for (const ministry of ministryList) {
        if (channel === 'email' || channel === 'both') {
          const template = this.getTemplate(
            `../resources/templates/email/overdue.html`,
          );
          const rowsHtml = this.buildOverDueRows(ministry.recommendations);
          const html = template.replace('{{rows}}', rowsHtml);
          const userEmail = ministry.users.map((u: any) => u.email);
          await this.emailService.sendEmail(
            userEmail,
            CC_EMAILS,
            'Overdue Recommendation(s) – reg',
            html,
          );
          // await this.sendEmail(html, userEmail);
        }

        if (channel === 'sms' || channel === 'both') {
          const numbers = ministry.users.map((u: any) => u.mobileNumber);
          const message =
            `Sir/Madam,%0A` +
            `Overdue+alert:+${ministry.recommendations.length || 0}+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0A` +
            `Please+take+immediate+action.%0A` +
            `With+Regards%0A` +
            `Team+HLC+Sameeksha+Portal%0A` +
            `NITI+Aayog`;
          await this.sendSMS(numbers, message);
        }
      }

      return { message: 'Notification Sent Successfully' };
    } catch (err) {
      console.error(err);
      throw err;
    }
  }

  async fetchDueRecommendations(days: number) {
    const recommendations = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'hlc')
      .leftJoin(
        't_users',
        'u',
        `
        u.ministry_id = m.id
        AND (
          r.department_id IS NULL
          OR u.department_id = r.department_id
        )
      `,
      )
      .leftJoin(
        't_roles',
        'role',
        `
        role.id = u.role_id
        AND role.name IN (:...roleNames)
      `,
      )
      .select([
        'm.id AS ministry_id',
        'm.name AS ministry_name',
        'r.id AS recommendation_id',
        'r.recommendationSlug AS recommendation_slug',
        'r.reportNumber AS report_number',
        'r.department_id AS recommendation_department_id',
        'hlc.name AS hlc_name',
        'hlc.slug AS hlc_slug',
        'u.email AS user_email',
        'u.mobileNumber AS mobile_number',
        'u.department_id AS department_id',
        'role.name AS role_name',
      ])
      .where(
        `
      COALESCE(r.updated_timeline, r.timeline)
      BETWEEN CURRENT_DATE
      AND (CURRENT_DATE + INTERVAL :days DAY)
    `,
      )
      .andWhere(
        `
      (
        r.current_status IN (:...statuses)
        OR r.current_status IS NULL
        OR r.current_status = ''
      )
    `,
      )
      .andWhere('r.niti_approved = true')
      .setParameters({
        days,
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
        roleNames: [RoleEnum.MINISTRY_APPROVER, RoleEnum.MINISTRY_DIRECTOR],
      })
      .orderBy('r.recommendationSlug', 'ASC')
      .getRawMany();

    const ministryMap: Map<string, any[]> = new Map();

    recommendations.forEach((rec) => {
      const key = `${rec.ministry_id}_${rec.recommendation_department_id ?? 'ALL'}`;

      if (!ministryMap.has(key)) {
        ministryMap.set(key, []);
      }

      ministryMap.get(key)!.push(rec);
    });

    const ministries = Array.from(ministryMap.entries()).map(
      ([_, recs]: any) => {
        const { ministry_id, ministry_name, recommendation_department_id } =
          recs[0];

        // ---- Unique Recommendations ----
        const recMap: Map<number, any> = new Map();
        recs.forEach((r) => {
          if (!recMap.has(r.recommendation_id)) {
            recMap.set(r.recommendation_id, {
              recommendationSlug: r.recommendation_slug,
              reportNumber: r.report_number,
              hlcSlug: r.hlc_slug,
              hlcName: r.hlc_name,
            });
          }
        });

        // ---- Unique Users ----
        const usersMap: Map<string, any> = new Map();
        recs.forEach((r) => {
          if (r.user_email) {
            usersMap.set(r.user_email, {
              email: r.user_email,
              mobileNumber: r.mobile_number,
              departmentId: r.department_id,
              role: r.role_name,
            });
          }
        });

        const sortedRecommendations = Array.from(recMap.values()).sort(
          (a: any, b: any) =>
            a.recommendationSlug.localeCompare(
              b.recommendationSlug,
              undefined,
              { numeric: true, sensitivity: 'base' },
            ),
        );

        return {
          ministryId: ministry_id,
          ministryName: ministry_name,
          departmentId: recommendation_department_id, // NULL = all departments
          recommendations: sortedRecommendations,
          users: Array.from(usersMap.values()),
        };
      },
    );

    return ministries;
  }

  async processDueRecommendations(channel: string, days: number) {
    try {
      let subject = 'Due Recommendation';
      switch (days) {
        case 14:
          subject = 'Timeline approaching for HLC Recommendation(s) - reg;';
          break;

        case 7:
          subject =
            'Alert: Timeline due within 7 days for HLC Recommendation(s) - reg;';
          break;

        case 1:
          subject =
            'Deadline Tomorrow: Timeline due for HLC Recommendation(s) - reg;';
          break;
      }
      const date = new Date().toLocaleDateString('en-IN', {
        timeZone: 'Asia/Kolkata',
        month: 'short',
        day: '2-digit',
        year: 'numeric',
      });
      const ministryList = await this.fetchDueRecommendations(days);

      for (const ministry of ministryList) {
        if (channel === 'email' || channel === 'both') {
          const template = this.getTemplate(
            `../resources/templates/email/due.html`,
          );
          const rowsHtml = this.buildOverDueRows(ministry.recommendations);
          const html = template.replace('{{rows}}', rowsHtml);
          html.replace('{{date}}', date);
          const userEmail = ministry.users.map((u: any) => u.email);
          await this.emailService.sendEmail(
            ['ram.birla@in.ey.com'],
            ['rambirla022@gmail.com'],
            // userEmail,
            // CC_EMAILS,
            subject,
            html,
          );
        }

        if (channel === 'sms' || channel === 'both') {
          const numbers = ministry.users.map((u: any) => u.mobileNumber);
          const message =
            `Sir/Madam,%0A` +
            `Alert:+Implementation+timeline+of+${ministry.recommendations.length || 0}+Recommendation(s)+related+to+your+Ministry/Department+is/are+due+by+${date}.%0A` +
            `Please+take+immediate+action.%0A` +
            `With+Regards%0A` +
            `Team+HLC+Sameeksha+Portal%0A` +
            `NITI+Aayog`;
          await this.sendSMS(['8516971855'], message);
        }
      }

      return { message: 'Notification Sent Successfully' };
    } catch (err) {
      console.error(err);
      throw err;
    }
  }

  async processDueRecommendationsStaging(channel: string, days: number) {}

  // curl -k 'https://smsgw.sms.gov.in/failsafe/MLink?username=hlcalt.sms&pin=Nic%40%232025&message=Sir/Madam,%0AOverdue+alert:+12343+Recommendation(s)+related+to+your+Ministry/Department+are+overdue.%0APlease+take+immediate+action.%0AWith+Regards%0ATeam+HLC+Sameeksha+Portal%0ANITI+Aayog&mnumber=98111731300&signature=HLCALT&dlt_entity_id=1101612760000040914&dlt_template_id=1107176561231338477' */
}

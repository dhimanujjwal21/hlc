import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRecommendationTable1762609757930 implements MigrationInterface {
    name = 'AddRecommendationTable1762609757930'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE \`t_hlc\` (\`id\` int NOT NULL AUTO_INCREMENT, \`slug\` varchar(150) NOT NULL, \`name\` varchar(500) NOT NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE INDEX \`IDX_798d355078376c926925fe3621\` (\`slug\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_recommendation\` (\`id\` int NOT NULL AUTO_INCREMENT, \`recommendation_slug\` varchar(100) NOT NULL, \`name\` varchar(255) NOT NULL, \`description\` text NULL, \`timeline\` timestamp(0) NULL, \`updated_timeline\` timestamp(0) NULL, \`report_number\` varchar(50) NULL, \`reason_not_implemented\` text NULL, \`current_status\` varchar(100) NULL, \`action_taken_by_ministry\` text NULL, \`remark\` text NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, \`department_id\` int NULL, \`ministry_id\` int NULL, \`hlc_id\` int NULL, UNIQUE INDEX \`IDX_91c5dbbb1036ecc6ecefd4525f\` (\`recommendation_slug\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` ADD CONSTRAINT \`FK_85b95f7160fcaed6914e8763c56\` FOREIGN KEY (\`department_id\`) REFERENCES \`t_departments\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` ADD CONSTRAINT \`FK_5b6eedc2d9a60f8a81b25fcbeba\` FOREIGN KEY (\`ministry_id\`) REFERENCES \`t_ministry\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` ADD CONSTRAINT \`FK_91afb01ac04513fe673f4195cca\` FOREIGN KEY (\`hlc_id\`) REFERENCES \`t_hlc\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` DROP FOREIGN KEY \`FK_91afb01ac04513fe673f4195cca\``);
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` DROP FOREIGN KEY \`FK_5b6eedc2d9a60f8a81b25fcbeba\``);
        await queryRunner.query(`ALTER TABLE \`t_recommendation\` DROP FOREIGN KEY \`FK_85b95f7160fcaed6914e8763c56\``);
        await queryRunner.query(`DROP INDEX \`IDX_91c5dbbb1036ecc6ecefd4525f\` ON \`t_recommendation\``);
        await queryRunner.query(`DROP TABLE \`t_recommendation\``);
        await queryRunner.query(`DROP INDEX \`IDX_798d355078376c926925fe3621\` ON \`t_hlc\``);
        await queryRunner.query(`DROP TABLE \`t_hlc\``);
    }

}

import { MigrationInterface, QueryRunner } from "typeorm";

export class InitSchema1762591217915 implements MigrationInterface {
    name = 'InitSchema1762591217915'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE \`t_roles\` (\`id\` int NOT NULL AUTO_INCREMENT, \`role_name\` varchar(50) NOT NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE INDEX \`IDX_9a017d0b931d0f18ee9b58e625\` (\`role_name\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_users\` (\`id\` int NOT NULL AUTO_INCREMENT, \`name\` varchar(100) NOT NULL, \`email\` varchar(150) NOT NULL, \`password\` varchar(255) NOT NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, \`role_id\` int NULL, UNIQUE INDEX \`IDX_1b1275aba2e3044ce094936619\` (\`email\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_ministry\` (\`id\` int NOT NULL AUTO_INCREMENT, \`name\` varchar(255) NOT NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE INDEX \`IDX_60401bfce503cb24c430a4014b\` (\`name\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_departments\` (\`id\` int NOT NULL AUTO_INCREMENT, \`name\` varchar(255) NOT NULL, \`created_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP, \`updated_at\` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE INDEX \`IDX_4d10812fd7a2b650761f301579\` (\`name\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`ALTER TABLE \`t_users\` ADD CONSTRAINT \`FK_b11a2681f2a0474892f1e695d59\` FOREIGN KEY (\`role_id\`) REFERENCES \`t_roles\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_users\` DROP FOREIGN KEY \`FK_b11a2681f2a0474892f1e695d59\``);
        await queryRunner.query(`DROP INDEX \`IDX_4d10812fd7a2b650761f301579\` ON \`t_departments\``);
        await queryRunner.query(`DROP TABLE \`t_departments\``);
        await queryRunner.query(`DROP INDEX \`IDX_60401bfce503cb24c430a4014b\` ON \`t_ministry\``);
        await queryRunner.query(`DROP TABLE \`t_ministry\``);
        await queryRunner.query(`DROP INDEX \`IDX_1b1275aba2e3044ce094936619\` ON \`t_users\``);
        await queryRunner.query(`DROP TABLE \`t_users\``);
        await queryRunner.query(`DROP INDEX \`IDX_9a017d0b931d0f18ee9b58e625\` ON \`t_roles\``);
        await queryRunner.query(`DROP TABLE \`t_roles\``);
    }

}

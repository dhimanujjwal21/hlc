import { MigrationInterface, QueryRunner } from "typeorm";

export class RecommendationTrailTable1762749151771 implements MigrationInterface {
    name = 'RecommendationTrailTable1762749151771'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE \`t_recommendation_trail\` (\`id\` int NOT NULL AUTO_INCREMENT, \`current_status\` varchar(100) NOT NULL, \`next_status\` varchar(100) NOT NULL, \`description\` text NULL, \`created_at\` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), \`recommendation_id\` int NULL, \`user_id\` int NULL, PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`ALTER TABLE \`t_departments\` ADD \`ministry_id\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`t_departments\` ADD CONSTRAINT \`FK_337e71ed2ea593215e8fc4a2550\` FOREIGN KEY (\`ministry_id\`) REFERENCES \`t_ministry\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`t_recommendation_trail\` ADD CONSTRAINT \`FK_eea97d079aeba15405fd7d2420a\` FOREIGN KEY (\`recommendation_id\`) REFERENCES \`t_recommendation\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`t_recommendation_trail\` ADD CONSTRAINT \`FK_eec55bb0e742df1ed0bebc28885\` FOREIGN KEY (\`user_id\`) REFERENCES \`t_users\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_recommendation_trail\` DROP FOREIGN KEY \`FK_eec55bb0e742df1ed0bebc28885\``);
        await queryRunner.query(`ALTER TABLE \`t_recommendation_trail\` DROP FOREIGN KEY \`FK_eea97d079aeba15405fd7d2420a\``);
        await queryRunner.query(`ALTER TABLE \`t_departments\` DROP FOREIGN KEY \`FK_337e71ed2ea593215e8fc4a2550\``);
        await queryRunner.query(`ALTER TABLE \`t_departments\` DROP COLUMN \`ministry_id\``);
        await queryRunner.query(`DROP TABLE \`t_recommendation_trail\``);
    }

}

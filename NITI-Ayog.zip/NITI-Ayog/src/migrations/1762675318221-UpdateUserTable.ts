import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateUserTable1762675318221 implements MigrationInterface {
    name = 'UpdateUserTable1762675318221'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_users\` ADD \`ministry_id\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`t_users\` ADD CONSTRAINT \`FK_826118c756b80c58120c1bc58df\` FOREIGN KEY (\`ministry_id\`) REFERENCES \`t_ministry\`(\`id\`) ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_users\` DROP FOREIGN KEY \`FK_826118c756b80c58120c1bc58df\``);
        await queryRunner.query(`ALTER TABLE \`t_users\` DROP COLUMN \`ministry_id\``);
    }

}

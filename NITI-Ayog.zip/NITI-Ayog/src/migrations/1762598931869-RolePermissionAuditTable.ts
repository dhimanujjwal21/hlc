import { MigrationInterface, QueryRunner } from "typeorm";

export class RolePermissionAuditTable1762598931869 implements MigrationInterface {
    name = 'RolePermissionAuditTable1762598931869'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE \`t_permissions\` (\`id\` int NOT NULL AUTO_INCREMENT, \`permission_name\` varchar(100) NOT NULL, \`description\` varchar(255) NULL, \`created_at\` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), \`updated_at\` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6), UNIQUE INDEX \`IDX_f9883156aecb244801739eb9fd\` (\`permission_name\`), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_role_permissions\` (\`id\` int NOT NULL AUTO_INCREMENT, \`role_id\` int NULL, \`permission_id\` int NULL, PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`CREATE TABLE \`t_audit_logs\` (\`id\` int NOT NULL AUTO_INCREMENT, \`user_id\` int NULL, \`method\` varchar(50) NOT NULL, \`route\` varchar(255) NULL, \`params\` json NULL, \`query\` json NULL, \`body\` json NULL, \`created_at\` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), PRIMARY KEY (\`id\`)) ENGINE=InnoDB`);
        await queryRunner.query(`ALTER TABLE \`t_role_permissions\` ADD CONSTRAINT \`FK_2aa1d58c6f8b3517048c54a6004\` FOREIGN KEY (\`role_id\`) REFERENCES \`t_roles\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE \`t_role_permissions\` ADD CONSTRAINT \`FK_3cf79ac62ab624ee5862e2452c6\` FOREIGN KEY (\`permission_id\`) REFERENCES \`t_permissions\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`t_role_permissions\` DROP FOREIGN KEY \`FK_3cf79ac62ab624ee5862e2452c6\``);
        await queryRunner.query(`ALTER TABLE \`t_role_permissions\` DROP FOREIGN KEY \`FK_2aa1d58c6f8b3517048c54a6004\``);
        await queryRunner.query(`DROP TABLE \`t_audit_logs\``);
        await queryRunner.query(`DROP TABLE \`t_role_permissions\``);
        await queryRunner.query(`DROP INDEX \`IDX_f9883156aecb244801739eb9fd\` ON \`t_permissions\``);
        await queryRunner.query(`DROP TABLE \`t_permissions\``);
    }

}

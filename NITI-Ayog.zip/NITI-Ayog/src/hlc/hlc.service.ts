import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Hlc } from 'src/entities/hlc.entity';
import { CreateHlcDto, UpdateHlcDto } from './dto/hlc.dto';
import { RoleEnum } from 'src/constants/enums';
import { User } from 'src/entities/users.entity';

@Injectable()
export class HlcService {
  constructor(
    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  async createHlc(dto: CreateHlcDto): Promise<Hlc> {
    const slugExists = await this.hlcRepository.findOne({
      where: { slug: dto.slug },
    });
    if (slugExists) {
      throw new ConflictException('Hlc slug already exists');
    }
    const hlc = this.hlcRepository.create(dto);
    return this.hlcRepository.save(hlc);
  }

  async findAll() {
    return this.hlcRepository.find();
  }

  async updateHlc(id: number, dto: UpdateHlcDto): Promise<Hlc> {
    const { name, slug } = dto;
    const hlc: any = await this.hlcRepository.findOne({ where: { id } });
    if (!hlc) throw new NotFoundException(`HLC with ID ${id} not found`);

    const slugExists = await this.hlcRepository.findOne({
      where: { slug },
    });
    if (slugExists && slugExists.id !== id) {
      throw new ConflictException('Hlc slug already exists');
    }

    hlc.name = name;
    hlc.slug = slug;
    hlc.updatedAt = new Date();
    return this.hlcRepository.save(hlc);
  }

  async deleteHlc(id: number): Promise<{ message: string }> {
    const result = await this.hlcRepository.delete(id);
    if (result.affected === 0)
      throw new NotFoundException(`HLC with ID ${id} not found`);
    return { message: 'HLC deleted successfully' };
  }
}

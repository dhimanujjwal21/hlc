import {
  Body,
  Controller,
  Get,
  Post,
  Put,
  Param,
  Delete,
  ParseIntPipe,
  UseGuards,
  Req,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiParam,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { HlcService } from './hlc.service';
import { Hlc } from 'src/entities/hlc.entity';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
import { Public } from 'src/decorators/public.decorator';
import { CreateHlcDto, UpdateHlcDto } from './dto/hlc.dto';

@ApiTags('HLC')
@Controller({
  path: 'hlc',
  version: '1',
})
export class HlcController {
  constructor(private readonly hlcService: HlcService) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_HLC)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Add new HLC' })
  @ApiBody({ type: CreateHlcDto })
  async createHlc(@Body() dto: CreateHlcDto): Promise<Hlc> {
    return this.hlcService.createHlc(dto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all HLC records' })
  async getAllHlc(@Req() req): Promise<Hlc[]> {
    return this.hlcService.findAll();
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_HLC)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Update existing HLC by ID' })
  @ApiParam({ name: 'id', type: Number })
  @ApiBody({ type: UpdateHlcDto })
  async updateHlc(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateHlcDto,
  ): Promise<Hlc> {
    return this.hlcService.updateHlc(id, dto);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DELETE_HLC)
  @ApiBearerAuth()
  @Delete(':id')
  @ApiOperation({ summary: 'Delete HLC by ID' })
  @ApiParam({ name: 'id', type: Number })
  async deleteHlc(
    @Param('id', ParseIntPipe) id: number,
  ): Promise<{ message: string }> {
    return this.hlcService.deleteHlc(id);
  }
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Departments } from 'src/entities/departments.entity';
import { JwtService } from '@nestjs/jwt';
import { Hlc } from 'src/entities/hlc.entity';
import { HlcService } from './hlc.service';
import { HlcController } from './hlc.controller';
import { User } from 'src/entities/users.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Hlc, User])],
  controllers: [HlcController],
  providers: [HlcService, JwtService],
  exports: [],
})
export class HlcModule {}

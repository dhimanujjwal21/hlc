import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, Length } from 'class-validator';

export class CreateHlcDto {
  @ApiProperty({
    example: 'High-Level Committee Implementation of Viksit Bharat Goals',
    description: 'Unique name of the HLC (High Level Committee)',
  })
  @IsString()
  @Length(2, 100)
  name: string;

  @ApiProperty({
    example: 'hlc-001',
    description: 'Slug identifier (URL-friendly, lowercase, hyphenated)',
  })
  @IsString()
  slug: string;
}

export class UpdateHlcDto {
  @ApiProperty({ example: 'Updated HLC name', required: false })
  @IsOptional()
  @IsString()
  @Length(2, 100)
  name?: string;

  @ApiProperty({ example: 'updated-hlc', required: false })
  @IsOptional()
  @IsString()
  slug?: string;
}
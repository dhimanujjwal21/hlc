import { Module } from '@nestjs/common';
import { UsersModule } from './users/users.module';
import { DepartmentsModule } from './departments/departments.module';
import { MinistryModule } from './ministry/ministry.module';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RolesPermissionsModule } from './rolesPermissions/rolesPermissions.module';
import { HlcModule } from './hlc/hlc.module';
import { RecommendationModule } from './recommendation/recommendation.module';
import { AppDataSource } from 'data-source';
import { DashboardModule } from './dashboard/dashboard.module';
import { NotificationModule } from './notification/notification.module';
import { RecommendationDraftModule } from './recommendationDraft/recommendation-draft.module';
import { IgomRecommendationDraftModule } from './recommendationDraftIgom/igom-recommendation-draft.module';
import { IgomRecommendationModule } from './recommendation-igom/igom-recommendation.module';
import { IgomDashboardModule } from './igomDashboard/igomDashboard.module';
import { EofficeModule } from './eoffice/eoffice.module';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 30000,
        limit: 12,
      },
    ]),
    TypeOrmModule.forRoot({
      ...AppDataSource.options,
      autoLoadEntities: true,
    }),
    UsersModule,
    RolesPermissionsModule,
    MinistryModule,
    DepartmentsModule,
    HlcModule,
    RecommendationModule,
    DashboardModule,
    NotificationModule,
    RecommendationDraftModule,
    IgomRecommendationDraftModule,
    IgomRecommendationModule,
    IgomDashboardModule,
    EofficeModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}

import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Recommendation } from 'src/entities/recommendation.entity';
import { In, IsNull, Repository } from 'typeorm';
import {
  ApproveReassignDto,
  BulkApproveDto,
  CloseRecommendationDto,
  DeaApproverRequestDto,
  ExportRecommendationDto,
  GetRecommendationQueryDto,
  MinistryApproverRequestDto,
  MinistryDirectorRequestDto,
  ReassignEditDto,
  ReassignRecommendationDto,
  UpdateRecommendationDto,
} from './dto/igom-recommendation.dto';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import {
  ClosureStatusEnum,
  DraftStatusEnum,
  FormatEnum,
  ImplementationEnum,
  ImplementationStatusEnum,
  ReassignRecommStatusEnum,
  ReassignRecStatusEnum,
  ReassignStatusEnum,
  RecommendationActionEnum,
  RecommendationStageEnum,
  RequestStatusEnum,
  RoleEnum,
  StageEnum,
  StatusEnum,
  TrailDescriptionEnum,
} from 'src/constants/enums';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import * as XLSX from 'xlsx';
import { Parser } from 'json2csv';
import { AuditLogs } from 'src/entities/audit.entity';
import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { RecommendationFile } from '../entities/recommendation-file.entity';
import { v4 as uuid } from 'uuid';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
// import PDFDocument from 'pdfkit';
// import { PDFDocument as PDFLib } from 'pdf-lib';
import { IgomRecommendation } from 'src/entities/igom-recommendation.entity';
import { CreateIgomRecommendationDto } from './dto/igom-recommendation.dto';
import { Igom } from 'src/entities/igom.entity';
import { it } from 'node:test';
import { IgomRecommendationUpdates } from 'src/entities/igom-recommendation-updates.entity';
import { IgomRecReassign } from 'src/entities/igom-rec-reassign.entity';
import PptxGenJS from 'pptxgenjs';
import {
  Document,
  Packer,
  PageOrientation,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  WidthType,
} from 'docx';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';
import { IgomRecommendationTrail } from 'src/entities/igom-recommendation-trail.entity';
import { IgomRecommendationDraft } from 'src/entities/igom-recommendation-draft.entity';
import { ifError } from 'assert';
var PdfPrinter = require('pdfmake');

@Injectable()
export class IgomRecommendationService {
  private s3 = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY,
      secretAccessKey: process.env.AWS_SECRET_KEY,
    },
  } as any);

  private awsBucket = process.env.AWS_BUCKET;
  private awsRegion = process.env.AWS_REGION;

  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(IgomRecommendation)
    private readonly igomRecommendationRepository: Repository<IgomRecommendation>,

    @InjectRepository(IgomRecReassign)
    private readonly igonRecReassignRepository: Repository<IgomRecReassign>,

    @InjectRepository(IgomRecommendationUpdates)
    private readonly igomRecommendationUpdatesRepository: Repository<IgomRecommendationUpdates>,

    @InjectRepository(IgomRecommendationDraft)
    private readonly igomRecommendationDraftRepository: Repository<IgomRecommendationDraft>,

    @InjectRepository(IgomRecommendationTrail)
    private readonly igomRecommendationTrailRepository: Repository<IgomRecommendationTrail>,
    @InjectRepository(RecommendationUpdates)
    private readonly recommendationUpdatesRepository: Repository<RecommendationUpdates>,

    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,

    @InjectRepository(Igom)
    private readonly igomRepository: Repository<Igom>,

    @InjectRepository(RecommendationFile)
    private readonly recommendationFileRepository: Repository<RecommendationFile>,
  ) {}

  async createRecommendation(
    payload: CreateIgomRecommendationDto,
    userId: number,
  ): Promise<IgomRecommendation[]> {
    const {
      departmentIds,
      ministryIds,
      igomId,
      primaryDepartmentId,
      primaryMinistryId,
    } = payload;
    // Check user validity if needed, similar to before.
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['userIgoms', 'userIgoms.igom', 'role'], // Adjust as per your schema
    });
    if (!user) throw new NotFoundException('User not found');

    const igomIds = user?.userIgoms?.map((i) => i.igom.id) || [];
    if (!igomIds.includes(igomId)) {
      throw new BadRequestException(
        `You cannot add recommendation for this IGOM.`,
      );
    }
    // Validate Igom entity
    const igom = await this.igomRepository.findOne({
      where: { id: payload.igomId },
    });
    if (!igom) throw new NotFoundException('IGOM not found');

    let primaryMinistry;
    if (payload.primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: payload.primaryMinistryId },
      });
      if (!primaryMinistry) {
        throw new NotFoundException('Primary Ministry not found');
      }
    }

    let primaryDepartment;
    if (payload.primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: payload.primaryDepartmentId },
        relations: ['ministry'],
      });
      if (!primaryDepartment) {
        throw new NotFoundException('Primary Department not found');
      }
      if (
        payload.primaryMinistryId &&
        primaryDepartment.ministry?.id !== payload.primaryMinistryId
      ) {
        throw new BadRequestException(
          'Primary Department is not of this ministry',
        );
      }
    }
    const results: IgomRecommendation[] = [];

    const departmentsIds = Array.isArray(payload.departmentIds)
      ? payload.departmentIds
      : payload.departmentIds != null
        ? [payload.departmentIds]
        : [];
    const ministriesIds = Array.isArray(payload.ministryIds)
      ? payload.ministryIds
      : payload.ministryIds != null
        ? [payload.ministryIds]
        : [];
    // 1. Fetch all departments and ministries
    const departments = await this.departmentRepository.find({
      where: { id: In(departmentsIds) },
      relations: ['ministry'],
    });
    const ministries = await this.ministryRepository.find({
      where: { id: In(ministriesIds) },
    });

    // 2. Build lookup maps
    const departmentMap = new Map(departments.map((dep) => [dep.id, dep]));
    const ministryMap = new Map(ministries.map((min) => [min.id, min]));

    // 3. Ensure all IDs exist
    departmentsIds.forEach((id) => {
      if (!departmentMap.has(id))
        throw new NotFoundException(`Department with ID ${id} not found`);
    });
    ministriesIds.forEach((id) => {
      if (!ministryMap.has(id))
        throw new NotFoundException(`Ministry with ID ${id} not found`);
    });

    // 4. Departments: For each, if it has a valid ministry, pair them; otherwise, {dept, null}
    const pairs: { department: any; ministry: any }[] = [];
    const ministriesWithDepts = new Set<number>();

    for (const department of departments) {
      if (department.ministry) {
        if (!ministryMap.has(department.ministry.id)) {
          throw new NotFoundException(
            `Department with id ${department.id} has a ministry (id: ${department.ministry.id}) not included in payload`,
          );
        }
        pairs.push({
          department,
          ministry: ministryMap.get(department.ministry.id),
        });
        ministriesWithDepts.add(department.ministry.id);
      } else {
        pairs.push({ department, ministry: null });
      }
    }

    // 5. Ministries that don't have any department
    for (const ministry of ministries) {
      if (!ministriesWithDepts.has(ministry.id)) {
        pairs.push({ department: null, ministry });
      }
    }

    // 6. (Optional) Departments that don't have any ministry (if not already handled above)
    // Already handled in step 4 by `else` clause

    // 7. Create IGOM recommendations for each pair
    for (const { department, ministry } of pairs) {
      // Optional: conflict check (omit if you want all to fail on conflict, or collect and process after)
      const existing = await this.igomRecommendationRepository.findOne({
        where: {
          recommendationSlug: payload.recommendationSlug,
          department: department ? { id: department.id } : IsNull(),
          ministry: ministry ? { id: ministry.id } : IsNull(),
        },
      });
      if (existing) {
        throw new ConflictException(
          `Recommendation "${payload.recommendationSlug}" already exists for department ${department?.id ?? 'null'}/ministry ${ministry?.id ?? 'null'}`,
        );
      }

      const recommendation = this.igomRecommendationRepository.create({
        recommendationSlug: payload.recommendationSlug,
        name: payload.name,
        description: payload.description,
        timeline: payload.timeline ?? undefined,
        budgetaryCategory: payload.BudgetaryCategory,
        proposalNature: payload.proposalNature,
        meetingDate: payload.meetingDate,
        implementingAgency: payload.implementingAgency,
        reportNumber: payload.reportNumber,
        department,
        ministry,
        igom,
        primaryDepartment,
        primaryMinistry,
        currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        stage: RecommendationStageEnum.DEA_APPROVER,
      });
      results.push(
        await this.igomRecommendationRepository.save(recommendation),
      );
    }

    const trail: IgomRecommendationTrail =
      this.igomRecommendationTrailRepository.create({
        currentStatus: StageEnum.DEA_DIRECTOR_RECOMMENDATION_CREATION,
        nextStatus: StageEnum.PENDING_WITH_DEA_APPROVER,

        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',

        route: 'CREATE RECOMMENDATION',
        user: user,

        description:
          'Recommendation created with recommendation slug: ' +
          payload.recommendationSlug,

        otherDetails: {
          payload,
        },
      });

    await this.igomRecommendationTrailRepository.save(trail);
    return results;
  }

  async updateRecommendation(
    recName: string,
    dto: UpdateRecommendationDto,
    userId: number,
  ): Promise<IgomRecommendation[]> {
    const {
      primaryDepartmentId,
      primaryMinistryId,
      ministryIds,
      departmentIds,
      igomId,
      name,
      description,
      recommendationSlug,
      reportNumber,
      timeline,
      meetingDate,
      proposalNature,
      BudgetaryCategory,
      implementingAgency,
    } = dto;

    // Find recommendations matching the slug
    const existingRecs = await this.igomRecommendationRepository.find({
      where: { recommendationSlug: recName },
      relations: [
        'igomRecommendationUpdates',
        'igom',
        'primaryDepartment',
        'primaryMinistry',
        'department',
        'ministry',
      ],
    });

    if (!existingRecs || existingRecs.length === 0) {
      throw new NotFoundException(
        `Recommendations for id ${recName} not found`,
      );
    }

    // Check if any linked updates exist (not allowed to update if so)
    const hasUpdates = existingRecs.some(
      (rec) =>
        rec.igomRecommendationUpdates &&
        rec.igomRecommendationUpdates.length > 0,
    );
    if (hasUpdates) {
      throw new BadRequestException(
        'Not allowed: One or more recommendations have updates linked.',
      );
    }

    // Check user IGOM permission **EARLY** (before mutations)
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['userIgoms', 'userIgoms.igom', 'role'],
    });
    if (!user) throw new NotFoundException('User not found');
    const igomIds = user.userIgoms?.map((h) => h.igom.id) || [];
    if (typeof igomId !== 'number' || !igomIds.includes(igomId)) {
      throw new BadRequestException(
        'You cannot edit recommendation for this IGOM.',
      );
    }

    // Fetch all departments and ministries requested
    const departments = await this.departmentRepository.find({
      where: { id: In(departmentIds ?? []) },
      relations: ['ministry'],
    });
    const ministries = await this.ministryRepository.find({
      where: { id: In(ministryIds ?? []) },
    });

    // Validate all department/ministry IDs exist
    const departmentMap = new Map(departments.map((dep) => [dep.id, dep]));
    const ministryMap = new Map(ministries.map((min) => [min.id, min]));
    (departmentIds ?? []).forEach((id) => {
      if (!departmentMap.has(id))
        throw new NotFoundException(`Department with ID ${id} not found`);
    });
    (ministryIds ?? []).forEach((id) => {
      if (!ministryMap.has(id))
        throw new NotFoundException(`Ministry with ID ${id} not found`);
    });

    // Prepare department-ministry pairs for fresh creation
    const pairs: { department: any; ministry: any }[] = [];
    const ministriesWithDepts = new Set<number>();
    for (const department of departments) {
      if (department.ministry) {
        if (!ministryMap.has(department.ministry.id)) {
          throw new NotFoundException(
            `Department with id ${department.id} has a ministry (id: ${department.ministry.id}) not included in payload`,
          );
        }
        pairs.push({
          department,
          ministry: ministryMap.get(department.ministry.id),
        });
        ministriesWithDepts.add(department.ministry.id);
      } else {
        pairs.push({ department, ministry: null });
      }
    }
    for (const ministry of ministries) {
      if (!ministriesWithDepts.has(ministry.id)) {
        pairs.push({ department: null, ministry });
      }
    }

    let igom = existingRecs[0].igom;
    let primaryMinistry = existingRecs[0].primaryMinistry;
    let primaryDepartment = existingRecs[0].primaryDepartment;
    if (primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: primaryMinistryId },
      });
      if (!primaryMinistry)
        throw new NotFoundException('Primary Ministry not found');
    }
    if (primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: primaryDepartmentId },
        relations: ['ministry'],
      });
      if (!primaryDepartment)
        throw new NotFoundException('Primary Department not found');
      if (
        primaryDepartment &&
        primaryDepartment.ministry?.id !== primaryMinistryId
      ) {
        throw new BadRequestException(
          'Primary Department is not of this ministry',
        );
      }
    }
    if (igomId) {
      igom = await this.igomRepository.findOne({ where: { id: igomId } });
      if (!igom) throw new NotFoundException('Igom not found');
    }

    await this.igomRecommendationRepository.remove(existingRecs);

    // For each pair, create a new recommendation with DTO fields taking priority
    const updatedRecs: IgomRecommendation[] = [];
    for (const { department, ministry } of pairs) {
      const newRecommendation = this.igomRecommendationRepository.create({
        recommendationSlug:
          recommendationSlug ?? existingRecs[0].recommendationSlug,
        name: name ?? existingRecs[0].name,
        description: description ?? existingRecs[0].description,
        timeline: timeline ?? existingRecs[0].timeline,
        budgetaryCategory:
          BudgetaryCategory ?? existingRecs[0].budgetaryCategory,
        proposalNature: proposalNature ?? existingRecs[0].proposalNature,
        meetingDate: meetingDate ?? existingRecs[0].meetingDate,
        implementingAgency:
          implementingAgency ?? existingRecs[0].implementingAgency,
        reportNumber: reportNumber ?? existingRecs[0].reportNumber,
        igom,
        primaryDepartment,
        primaryMinistry,
        currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        stage: RecommendationStageEnum.DEA_APPROVER,
        ministry: ministry ?? null,
        department: department ?? null,
        updatedAt: new Date(),
        nitiRemark: '',
      });
      const rec =
        await this.igomRecommendationRepository.save(newRecommendation);
      updatedRecs.push(rec);
    }

    const trail: IgomRecommendationTrail =
      this.igomRecommendationTrailRepository.create({
        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',
        currentStatus: existingRecs[0].currentStage,
        nextStatus: StageEnum.PENDING_WITH_DEA_APPROVER,
        route: 'UPDATE RECOMMENDATION',
        user: user,

        description:
          'Recommendation updated with recommendation slug: ' +
          recommendationSlug,

        otherDetails: {
          dto,
        },
      });

    await this.igomRecommendationTrailRepository.save(trail);
    return updatedRecs;
  }

  /*   async findAllALll(
    query: GetRecommendationQueryDto,
    userId: number,
    noPagination = false,
    all = false,
  ) {
    const {
      departmentId,
      ministryId,
      igomId,
      status,
      search,
      meetingDate: date,
      reportNumber,
      page = 1,
      limit = 10,
      recommendations,
      pending,
      implementation,
    } = query;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userIgoms', 'userIgoms.igom'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isMinistryRole =
      user.role?.roleName === RoleEnum.MINISTRY_DIRECTOR ||
      user.role?.roleName === RoleEnum.MINISTRY_APPROVER;

    let pendingCount = 0;

    if (user.ministry?.id) {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          ministry: user.ministry,
        },
      });
    } else if (
      !all &&
      (user.role?.roleName === RoleEnum.NITI_APPROVER ||
        user.role?.roleName === RoleEnum.NITI_DIRECTOR ||
        user.role?.roleName === RoleEnum.NITI_VIEWER)
    ) {
      const userIgomIds = user?.userIgoms?.map((h) => h.igom.id) || [];
      if (igomId && userIgomIds.length > 0 && !userIgomIds.includes(igomId)) {
        throw new ForbiddenException('You do not have access to this Igom');
      }
      const finalIgomIds = igomId ? [igomId] : userIgomIds;
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
          igom: {
            id: In(finalIgomIds),
          },
        },
      });
    } else {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
        },
      });
    }

    let stage: string = RecommendationStageEnum.NITI_APPROVER;
    switch (user.role?.roleName) {
      case RoleEnum.MINISTRY_APPROVER:
        stage = RecommendationStageEnum.MINISTRY_APPROVER;
        break;
      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        break;
      case RoleEnum.NITI_DIRECTOR:
        stage = RecommendationStageEnum.NITI_DIRECTOR;
        break;
      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.NITI_APPROVER;
        break;
      default:
        stage = '';
        break;
    }

    const qb = this.igomRecommendationRepository
      .createQueryBuilder('recommendation')
      .leftJoinAndSelect('recommendation.department', 'department')
      .leftJoinAndSelect('recommendation.ministry', 'ministry')
      .leftJoinAndSelect(
        'recommendation.primaryDepartment',
        'primaryDepartment',
      )
      .leftJoinAndSelect('recommendation.primaryMinistry', 'primaryMinistry')
      .leftJoinAndSelect('recommendation.igom', 'igom');

    if (isMinistryRole) {
      qb.leftJoinAndSelect(
        'recommendation.igomRecommendationUpdates',
        'recommendationUpdates',
      );
    } else {
      qb.leftJoinAndSelect(
        'recommendation.igomRecommendationUpdates',
        'recommendationUpdates',
        'recommendationUpdates.ministryApproverStatus = :approvedStatus',
        { approvedStatus: ImplementationStatusEnum.APPROVED },
      );
    }

    if (user.ministry?.id) {
      const ministryId = user.ministry?.id;

      qb.andWhere('recommendation.nitiApproved = :nitiApproved', {
        nitiApproved: true,
      });

      if (implementation === ImplementationEnum.MY) {
        qb.andWhere('recommendation.ministry_id = :ministryId', {
          ministryId,
        });
      } else if (implementation === ImplementationEnum.OTHER) {
        qb.andWhere('recommendation.primary_ministry_id = :ministryId', {
          ministryId,
        })
          .andWhere('recommendation.ministry_id IS NOT NULL')
          .andWhere('recommendation.ministry_id != :ministryId', {
            ministryId,
          });
      } else if (implementation === ImplementationEnum.TOTAL) {
        qb.andWhere(
          `
            (recommendation.primary_ministry_id = :ministryId
            OR recommendation.ministry_id = :ministryId)
            `,
          { ministryId },
        );
      }
    } else {
      if (ministryId) {
        if (implementation === ImplementationEnum.MY) {
          qb.andWhere('recommendation.ministry_id = :ministryId', {
            ministryId,
          });
        } else if (implementation === ImplementationEnum.OTHER) {
          qb.andWhere('recommendation.primary_ministry_id = :ministryId', {
            ministryId,
          })
            .andWhere('recommendation.ministry_id IS NOT NULL')
            .andWhere('recommendation.ministry_id != :ministryId', {
              ministryId,
            });
        } else if (implementation === ImplementationEnum.TOTAL) {
          qb.andWhere(
            `
            (recommendation.primary_ministry_id = :ministryId
            OR recommendation.ministry_id = :ministryId)
            `,
            { ministryId },
          );
        } else {
          qb.andWhere('recommendation.ministry_id = :ministryId', {
            ministryId,
          });
        }
      }
    }

    if (departmentId)
      qb.andWhere('recommendation.department_id = :departmentId', {
        departmentId,
      });

    if (
      !all &&
      (user.role?.roleName == RoleEnum.NITI_APPROVER ||
        user.role?.roleName === RoleEnum.NITI_DIRECTOR)
    ) {
      const userIgomIds = user.userIgoms?.map((h) => h.igom.id) || [];
      if (igomId && userIgomIds.length > 0 && !userIgomIds.includes(igomId)) {
        throw new ForbiddenException('You do not have access to this Igom');
      }
      const finalIgomIds = igomId ? [igomId] : userIgomIds;
      // const hlcIds = user.userHlcs?.map((h) => h.hlc.id) || [];
      if (!finalIgomIds.length) {
        qb.andWhere('1 = 0');
      } else {
        qb.andWhere('recommendation.igom_id IN (:...igomIds)', {
          igomIds: finalIgomIds,
        });
      }
    } else if (!all && user.role?.roleName == RoleEnum.NITI_VIEWER) {
      const userIgomIds = user.userIgoms?.map((h) => h.igom.id) || [];

      const finalIgomIds = igomId ? [igomId] : userIgomIds;

      if (finalIgomIds.length > 0) {
        qb.andWhere('recommendation.igom_id IN (:...igomIds)', {
          igomIds: finalIgomIds,
        });
      }
      // else {
      //   qb.andWhere('1 = 1');
      // }
    } else {
      if (igomId) qb.andWhere('recommendation.igom_id = :igomId', { igomId });
    }

    // if (reportNumber)
    //   qb.andWhere('recommendation.report_number = :reportNumber', {
    //     reportNumber,
    //   });

    if (reportNumber?.length) {
      qb.andWhere('recommendation.report_number IN (:...reportNumber)', {
        reportNumber,
      });
    }

    if (pending) qb.andWhere('recommendation.stage = :stage', { stage });

    if (status) {
      if (status === StatusEnum.NO_ACTION) {
        qb.andWhere(
          "(recommendation.current_status IS NULL OR recommendation.current_status = '')",
        );
      } else if (
        status.toLowerCase() === ClosureStatusEnum.CLOSED.toLowerCase()
      ) {
        qb.andWhere('recommendation.closure_status = :status', {
          status: ClosureStatusEnum.CLOSED,
        });
      } else {
        qb.andWhere('recommendation.current_status = :status', { status });
      }
    }

    if (search) {
      const searchValue = `%${search.toLowerCase()}%`;

      qb.andWhere(
        `
        (
          LOWER(recommendation.name) LIKE :search
          OR LOWER(recommendation.recommendation_slug) LIKE :search
          OR LOWER(recommendation.description) LIKE :search
        )
        `,
        { search: searchValue },
      );
    }

    if (date) {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate.getTime())) {
        throw new BadRequestException('Invalid date format');
      }

      const month = parsedDate.getMonth() + 1;
      const year = parsedDate.getFullYear();

      qb.andWhere(
        `EXTRACT(MONTH FROM recommendation."meeting_date") = :month AND EXTRACT(YEAR FROM recommendation."meeting_date") = :year`,
        { month, year },
      );
    }

    if (recommendations && recommendations.length > 0) {
      qb.andWhere('recommendation.id IN (:...recs)', {
        recs: recommendations,
      });
    }

    qb.orderBy('recommendation.recommendationSlug', 'ASC');

    if (!noPagination) {
      qb.skip((page - 1) * limit).take(limit);
    }

    let [data, total] = await qb.getManyAndCount();

    data = data.map((item: any) => {
      const isClosed =
        item.closureStatus === ClosureStatusEnum.CLOSED ||
        item.currentStage === StageEnum.CLOSED_BY_HLC;

      const isTimelineCrossed =
        item.timeline && new Date(item.timeline).getTime() < Date.now();

      const isNitiApprover = user.role?.roleName === RoleEnum.NITI_APPROVER;

      const showCloseButton = isNitiApprover && !isClosed && isTimelineCrossed;

      if (item.recommendationUpdates) {
        item.recommendationUpdates.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
      }
      let action = '';
      if (
        item.closureStatus === ClosureStatusEnum.CLOSED &&
        item.currentStage === StageEnum.CLOSED_BY_HLC
      ) {
        action = RecommendationActionEnum.CLOSED;
      } else {
        switch (user.role?.roleName) {
          case RoleEnum.MINISTRY_DIRECTOR:
            if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER &&
              item.nitiApproved
            )
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            else if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;

          case RoleEnum.MINISTRY_APPROVER:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER &&
              item.nitiApproved
            )
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;

          case RoleEnum.NITI_APPROVER:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (
              item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR &&
              !item.currentStatus
            )
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER ||
              item.stage === RecommendationStageEnum.NITI_DIRECTOR
            )
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
            break;

          case RoleEnum.MINISTRY_SECRETARY:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (item.stage === RecommendationStageEnum.NITI_DIRECTOR)
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.NITI_APPROVER)
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;
        }
      }
      return {
        ...item,
        action,
        closureRemark: item.closureRemark ?? null,
        closureStatus: item.closureStatus ?? null,
        showCloseButton,
      };
    });

    return noPagination
      ? data
      : { pendingCount, total, page, limit, results: data };
  }
 */
  /*   async findAll(
    query: GetRecommendationQueryDto,
    userId: number,
    noPagination = false,
    all = false,
  ) {
    const {
      departmentId,
      ministryId,
      igomId,
      status,
      search,
      meetingDate: date,
      reportNumber,
      recommendations,
      implementation,
      budgetaryCategory,
      proposalNature,
      implementingAgency,
      pending,
      page = 1,
      limit = 10,
    } = query;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: [
        'ministry',
        'department',
        'role',
        'userIgoms',
        'userIgoms.igom',
      ],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    // 🔷 Pending Count (same as your original)
    let pendingCount = 0;

    if (user.ministry?.id) {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          ministry: user.ministry,
        },
      });
    } else if (
      !all &&
      (user.role?.roleName === RoleEnum.DEA_APPROVER ||
        user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
        user.role?.roleName === RoleEnum.NFRR_VIEWER)
    ) {
      const userIgomIds = user?.userIgoms?.map((h) => h.igom.id) || [];
      if (igomId && userIgomIds.length > 0 && !userIgomIds.includes(igomId)) {
        throw new ForbiddenException('You do not have access to this Igom');
      }
      const finalIgomIds = igomId ? [igomId] : userIgomIds;
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
          igom: {
            id: In(finalIgomIds),
          },
        },
      });
    } else {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        },
      });
    }

    let where = `WHERE 1=1`;

    if (departmentId) {
      where += ` AND r.department_id = ${departmentId}`;
    }
    if (budgetaryCategory) {
      where += ` AND r.budgetary_category = '${budgetaryCategory}'`;
    }
    // if (proposalNature) {
    //   where += ` AND r.proposal_nature = '${proposalNature}'`;
    // }
    if (proposalNature) {
      const proposalNatureArray = proposalNature
        ? proposalNature
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      if (proposalNatureArray.length) {
        const proposalWhereClauses = proposalNatureArray.map(
          (proposal) =>
            `(',' || r.proposal_nature || ',') LIKE '%,${proposal},%'`,
        );
        where += ' AND (' + proposalWhereClauses.join(' OR ') + ')';
      }
    }
    if (implementingAgency) {
      const implementingAgencyArray = implementingAgency
        ? implementingAgency
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      if (implementingAgencyArray.length) {
        const agencyWhereClauses = implementingAgencyArray.map(
          (agency) =>
            `(',' || r.implementing_agency || ',') LIKE '%,${agency},%'`,
        );
        where += ' AND (' + agencyWhereClauses.join(' OR ') + ')';
      }
    }

    if (reportNumber?.length) {
      where += ` AND r.report_number IN (${reportNumber.map((v) => `'${v}'`).join(',')})`;
    }

    if (status) {
      if (status === StatusEnum.NO_ACTION) {
        where += ` AND (r.current_status IS NULL OR r.current_status = '')`;
      } else {
        where += ` AND r.current_status = '${status}'`;
      }
    }

    if (recommendations && recommendations.length > 0) {
      where += ` AND r.id IN (${recommendations.join(',')})`;
    }

    if (search) {
      where += ` AND (
      LOWER(r.name) LIKE '%${search.toLowerCase()}%'
      OR LOWER(r.description) LIKE '%${search.toLowerCase()}%'
      OR LOWER(r.recommendation_slug) LIKE '%${search.toLowerCase()}%'
    )`;
    }

    if (date) {
      const parsedDate = new Date(date);
      const day = parsedDate.getDate();
      const month = parsedDate.getMonth() + 1;
      const year = parsedDate.getFullYear();

      where += ` AND EXTRACT(DAY FROM r.meeting_date) = ${day}
             AND EXTRACT(MONTH FROM r.meeting_date) = ${month}
             AND EXTRACT(YEAR FROM r.meeting_date) = ${year}`;
    }
    let stage: string = RecommendationStageEnum.DEA_APPROVER;
    switch (user.role?.roleName) {
      case RoleEnum.MINISTRY_APPROVER:
        stage = RecommendationStageEnum.MINISTRY_APPROVER;
        break;
      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        break;
      case RoleEnum.DEA_DIRECTOR:
        stage = RecommendationStageEnum.DEA_DIRECTOR;
        break;
      case RoleEnum.DEA_APPROVER:
        stage = RecommendationStageEnum.DEA_APPROVER;
        break;
      default:
        stage = '';
        break;
    }

    if (pending) where += ` AND r.stage =  '${stage}'`;

    if (
      !all &&
      (user.role?.roleName == RoleEnum.DEA_APPROVER ||
        user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
        user.role?.roleName === RoleEnum.NFRR_VIEWER)
    ) {
      const userIgomIds = user.userIgoms?.map((h) => h.igom.id) || [];
      if (igomId && userIgomIds.length > 0 && !userIgomIds.includes(igomId)) {
        throw new ForbiddenException('You do not have access to this Igom');
      }
      const finalIgomIds = igomId ? [igomId] : userIgomIds;
      if (!finalIgomIds.length) {
        where += ` AND 1=0`;
      } else {
        where += ` AND r.igom_id IN (${finalIgomIds.join(',')})`;
      }
    } else {
      if (igomId) where += ` AND r.igom_id = ${igomId}`;
    }

    let effectiveMinistryId: number | undefined;

    if (
      user.role?.roleName === RoleEnum.DEA_APPROVER ||
      user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
      user.role?.roleName === RoleEnum.NFRR_VIEWER
    ) {
      effectiveMinistryId = ministryId;
    } else {
      effectiveMinistryId = user.ministry?.id;
    }

    if (effectiveMinistryId) {
      if (
        !(
          user.role?.roleName === RoleEnum.DEA_APPROVER ||
          user.role?.roleName === RoleEnum.DEA_DIRECTOR
        )
      ) {
        where += ` AND r.niti_approved = true`;
      }

      if (implementation === ImplementationEnum.MY) {
        where += ` AND r.ministry_id = ${effectiveMinistryId}`;
      } else if (implementation === ImplementationEnum.OTHER) {
        where += ` AND r.primary_ministry_id = ${effectiveMinistryId}
               AND r.ministry_id IS NOT NULL
               AND r.ministry_id != ${effectiveMinistryId}`;
      } else if (implementation === ImplementationEnum.TOTAL) {
        where += ` AND (
      r.primary_ministry_id = ${effectiveMinistryId}
      OR r.ministry_id = ${effectiveMinistryId}
    )`;
      } else {
        // ✅ default case (IMPORTANT - was missing earlier)
        where += ` AND r.ministry_id = ${effectiveMinistryId}`;
      }
    }

    const sql = `SELECT DISTINCT ON (r.recommendation_slug)
      r.recommendation_slug AS "recommendationSlug",
      r.name,
      r.description,
      r.timeline,
      r.niti_approved AS "DEA Approved",
      r.niti_remark AS "nitiRemarks",
      r.meeting_date AS "meetingDate",
      r.proposal_nature AS "proposalNature",
      r.report_number AS "reportNumber",
      r.implementing_agency AS "implAgency",
      r.budgetary_category AS "budgetaryCategory",

      jsonb_build_object(
        'id', igm.id,
        'name', igm.name,
        'slug', igm.slug
      ) AS "igom",

      jsonb_build_object(
        'id', pm.id,
        'name', pm.name
      ) AS "primaryMinistry",

      jsonb_build_object(
        'id', pd.id,
        'name', pd.name
      ) AS "primaryDepartment",

      (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', m.id,
            'name', m.name,
            'departments', (
              SELECT CASE 
                WHEN COUNT(d.id) FILTER (WHERE d.id IS NOT NULL) = 0 THEN NULL
                ELSE jsonb_agg(
                  DISTINCT jsonb_build_object(
                    'id', d.id,
                    'name', d.name,
                    'recommendationDetails', (
                      SELECT jsonb_build_object(
                        'id', r2.id,
                        'reasonNotImplemented', r2.reason_not_implemented,
                        'deaApproved', r2.niti_approved,
                        'updatedTimeline', r2.updated_timeline,
                        'currentStatus', r2.current_status,
                        'closureStatus', r2.closure_status,
                        'closureRemark', r2.closure_remark,
                        'stage', r2.stage,
                        'currentStage', r2.current_stage,
                        'actionTaken', r2.action_taken_by_ministry,
                        'recRemarks', r2.remark,
                        'isActive',r2.is_active,
                        'isReassigned',r2.is_reassigned,
                        'reassignStatus',r2.reassign_status,
                        'reassignComments',r2.reassign_comments,            
                        'otherMinistriesConsulted', r2.other_ministries_consulted,
                        'actsRulesProvisionsModified', r2.acts_rules_provisions_modified,
                          'showCloseButton',
                        (
                          CASE
                            WHEN '${user.role?.roleName}' = 'Dea Approver'
                              AND (r2.closure_status IS DISTINCT FROM 'closed'
                              AND r2.current_stage IS DISTINCT FROM 'Closed by HLC')
                              AND r2.timeline IS NOT NULL
                              AND r2.timeline < NOW()
                            THEN TRUE
                            ELSE FALSE
                          END
                        ),
                        'action',
                        CASE
                          WHEN r2.closure_status = 'CLOSED'
                            AND r2.current_stage = 'CLOSED_BY_HLC'
                            THEN 'CLOSED'

                          WHEN '${user.role?.roleName}' = 'MINISTRY_DIRECTOR' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage = 'DEA_APPROVER' AND r2.niti_approved = true
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          WHEN '${user.role?.roleName}' = 'MINISTRY_APPROVER' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'DEA_APPROVER' AND r2.niti_approved = true
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          WHEN '${user.role?.roleName}' = 'DEA_APPROVER' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage IN ('DEA_APPROVER', 'DEA_DIRECTOR')
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_DIRECTOR'
                            END

                          WHEN '${user.role?.roleName}' = 'MINISTRY_SECRETARY' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage = 'DEA_DIRECTOR'
                                THEN 'CURRENTLY_WITH_DEA_DIRECTOR'
                              WHEN r2.stage = 'DEA_APPROVER'
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          ELSE ''
                        END
                      )
                      FROM t_igom_recommendation r2
                      WHERE r2.recommendation_slug = r.recommendation_slug
                        AND r2.ministry_id = m.id
                        AND r2.department_id = d.id
                      ORDER BY r2.created_at DESC
                      LIMIT 1
                    ),

                    'recommendationUpdates', (
                      SELECT COALESCE(
                        jsonb_agg(
                          jsonb_build_object(
                            'id', ru.id,
                            'status', ru.status,
                            'createdAt', ru.created_at,
                            'reasonNotImplemented', ru.reason_not_implemented,
                            'ministryApprover_status',ru.ministry_approver_status,
                            'actionTakenByMinistry',ru.action_taken_by_ministry,
                            'relatedToHlc',ru.related_to_hlc,
                            'hlcRefId',ru.hlc_ref_id
    )
                          ORDER BY ru.created_at DESC
                        ),
                        '[]'::jsonb
                      )
                      FROM t_igom_recommendation_updates ru
                      WHERE ru.igom_recommendation_id IN (
                        SELECT r3.id
                        FROM t_igom_recommendation r3
                        WHERE r3.recommendation_slug = r.recommendation_slug
                          AND r3.ministry_id = m.id
                          AND r3.department_id = d.id
                      ) ${
                        ![
                          RoleEnum.MINISTRY_APPROVER,
                          RoleEnum.MINISTRY_DIRECTOR,
                        ].includes(user.role?.roleName as RoleEnum)
                          ? "AND ru.ministry_approver_status = 'approved'"
                          : ''
                      }
                    )
                  )
                )
              END
              FROM t_igom_recommendation r2
              LEFT JOIN t_departments d ON d.id = r2.department_id
              WHERE r2.recommendation_slug = r.recommendation_slug
                AND r2.ministry_id = m.id
            ),

            'recommendationDetails', (
              SELECT jsonb_build_object(
                'id', r2.id,
                'reasonNotImplemented', r2.reason_not_implemented,
                'deaApproved', r2.niti_approved,
                'updatedTimeline', r2.updated_timeline,
                'currentStatus', r2.current_status,
                'closureStatus', r2.closure_status,
                'closureRemark', r2.closure_remark,
                'stage', r2.stage,
                'currentStage', r2.current_stage,
                'actionTaken', r2.action_taken_by_ministry,
                'recRemarks', r2.remark,
                'isActive',r2.is_active,
                'isReassigned',r2.is_reassigned,
                'reassignComments',r2.reassign_comments,
                'reassignStatus',r2.reassign_status,
                'otherMinistriesConsulted', r2.other_ministries_consulted,
                'actsRulesProvisionsModified', r2.acts_rules_provisions_modified,
                  'showCloseButton',
                (
                  CASE
                    WHEN '${user.role?.roleName}' = 'Dea Approver'
                      AND (r2.closure_status IS DISTINCT FROM 'closed'
                      AND r2.current_stage IS DISTINCT FROM 'Closed by HLC')
                      AND r2.timeline IS NOT NULL
                      AND r2.timeline < NOW()
                    THEN TRUE
                    ELSE FALSE
                  END
                ),
                'action',
                CASE
                  WHEN r2.closure_status = 'closed'
                    AND r2.current_stage = 'Closed by HLC'
                    THEN 'CLOSED'

                  WHEN '${user.role?.roleName}' = 'Ministry Director' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage = 'DEA Approver' AND r2.niti_approved = true
                        THEN 'CURRENTLY WITH DEA APPROVER'
                      WHEN r2.stage = 'Ministry Director'
                        THEN ''
                      ELSE 'CURRENTLY WITH DEA APPROVER'
                    END

                  WHEN '${user.role?.roleName}' = 'Dea Director' THEN
                    CASE
                      WHEN r2.stage = 'Reassign Pending' AND r.current_stage= 'Pending with DEA Approver for Reassign Pending'
                        THEN 'Currently with DEA Approver for Reassign Pending'
                      ELSE ''
                    END


                  WHEN '${user.role?.roleName}' = 'Ministry Approver' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'DEA Approver' AND r2.niti_approved = true
                        THEN 'CURRENTLY WITH DEA APPROVER'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN ''
                      ELSE 'CURRENTLY WITH DEA APPROVER'
                    END

                  WHEN '${user.role?.roleName}' = 'Dea Approver' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage IN ('DEA Approver', 'DEA Director')
                        THEN ''
                      WHEN r2.stage = 'Reassign Pending' AND r.current_stage= 'Pending with DEA Approver for Reassign Pending'
                        THEN 'Currently with DEA Approver for Reassign Pending'
                      ELSE 'CURRENTLY WITH DEA DIRECTOR'
                    END

                  WHEN '${user.role?.roleName}' = 'Ministry Secretary' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage = 'DEA Director'
                        THEN 'CURRENTLY WITH DEA DIRECTOR'
                      WHEN r2.stage = 'DEA Approver'
                        THEN 'CURRENTLY WITH DEA APPROVER'
                    END

                  ELSE ''
                END
              )
              FROM t_igom_recommendation r2
              WHERE r2.recommendation_slug = r.recommendation_slug
                AND r2.ministry_id = m.id
                AND r2.department_id IS NULL
              ORDER BY r2.created_at DESC
              LIMIT 1
            ),

            'recommendationUpdates', (
              SELECT COALESCE(
                jsonb_agg(
                  jsonb_build_object(
                    'id', ru.id,
                    'status', ru.status,
                    'createdAt', ru.created_at,
                    'reasonNotImplemented', ru.reason_not_implemented,
                    'ministryApprover_status',ru.ministry_approver_status,
                    'actionTakenByMinistry',ru.action_taken_by_ministry,
                    'relatedToHlc',ru.related_to_hlc,
                    'hlcRefId',ru.hlc_ref_id

                  )
                  ORDER BY ru.created_at DESC
                ),
                '[]'::jsonb
              )
              FROM t_igom_recommendation_updates ru
              WHERE ru.igom_recommendation_id IN (
                SELECT r3.id
                FROM t_igom_recommendation r3
                WHERE r3.recommendation_slug = r.recommendation_slug
                  AND r3.ministry_id = m.id
                  AND r3.department_id IS NULL
              ) ${
                ![
                  RoleEnum.MINISTRY_APPROVER,
                  RoleEnum.MINISTRY_DIRECTOR,
                ].includes(user.role?.roleName as RoleEnum)
                  ? "AND ru.ministry_approver_status = 'approved'"
                  : ''
              }
            )

          )
        )
        FROM t_ministry m
        WHERE m.id IN (
          SELECT DISTINCT r4.ministry_id
          FROM t_igom_recommendation r4
          WHERE r4.recommendation_slug = r.recommendation_slug
            AND r4.ministry_id IS NOT NULL
        )
      ) AS "implementingMinistries"
      FROM t_igom_recommendation r
      LEFT JOIN t_ministry pm ON pm.id = r.primary_ministry_id
      LEFT JOIN t_departments pd ON pd.id = r.primary_department_id
      LEFT JOIN t_igom igm ON igm.id = r.igom_id
      ${where}
      ORDER BY r.recommendation_slug, r.created_at DESC`;

    const pagination = !noPagination
      ? ` LIMIT ${limit} OFFSET ${(page - 1) * limit}`
      : '';

    const finalQuery = sql + pagination;

    const [recData, totalIgom] = await Promise.all([
      this.igomRecommendationRepository.query(finalQuery),
      this.igomRecommendationRepository.query(sql),
    ]);

    const data = recData.map((item) => {
      if (item.recommendationSlug === 'IGoM/A/IV/444444') {
        console.log('item', item);
      }
      const isClosed =
        item.closureStatus === ClosureStatusEnum.CLOSED ||
        item.currentStage === StageEnum.CLOSED_BY_HLC;
      const isTimelineCrossed =
        item.timeline && new Date(item.timeline).getTime() < Date.now();

      const isNitiApprover = user.role?.roleName === RoleEnum.DEA_APPROVER;

      const showCloseButton = isNitiApprover && !isClosed && isTimelineCrossed;

      return {
        ...item,
        closureRemark: item.closureRemark ?? null,
        closureStatus: item.closureStatus ?? null,
        showCloseButton,
      };
    });

    return noPagination
      ? data
      : {
          pendingCount,
          total: totalIgom.length,
          page,
          limit,
          results: data,
        };
  }
 */

  async findAll(
    query: GetRecommendationQueryDto,
    userId: number,
    noPagination = false,
    all = false,
  ) {
    const {
      departmentId,
      ministryId,
      igomId,
      status,
      search,
      meetingDate: date,
      reportNumber,
      recommendations,
      implementation,
      budgetaryCategory,
      proposalNature,
      implementingAgency,
      pending,
      page = 1,
      limit = 10,
    } = query;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: [
        'ministry',
        'department',
        'role',
        'userIgoms',
        'userIgoms.igom',
      ],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    let pendingCount = 0;

    if (user.ministry?.id) {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          ministry: user.ministry,
        },
      });
    } else if (
      !all &&
      (user.role?.roleName === RoleEnum.DEA_APPROVER ||
        user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
        user.role?.roleName === RoleEnum.NFRR_VIEWER)
    ) {
      const userIgomIds = user?.userIgoms?.map((h) => h.igom.id) || [];
      const requestedIgomId = igomId ? Number(igomId) : undefined;

      if (
        requestedIgomId &&
        userIgomIds.length > 0 &&
        !userIgomIds.includes(requestedIgomId)
      ) {
        throw new ForbiddenException('You do not have access to this Igom');
      }

      const finalIgomIds = requestedIgomId ? [requestedIgomId] : userIgomIds;

      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
          igom: {
            id: In(finalIgomIds),
          },
        },
      });
    } else {
      pendingCount = await this.igomRecommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        },
      });
    }

    const params: any[] = [];

    const addParam = (value: any) => {
      params.push(value);
      return `$${params.length}`;
    };

    const whereParts: string[] = [`1=1`];

    if (departmentId) {
      whereParts.push(`r.department_id = ${addParam(Number(departmentId))}`);
    }

    if (budgetaryCategory) {
      whereParts.push(`r.budgetary_category = ${addParam(budgetaryCategory)}`);
    }

    if (proposalNature) {
      const proposalNatureArray = proposalNature
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      if (proposalNatureArray.length) {
        const proposalWhereClauses = proposalNatureArray.map((proposal) => {
          return `(',' || COALESCE(r.proposal_nature, '') || ',') LIKE ${addParam(
            `%,${proposal},%`,
          )}`;
        });

        whereParts.push(`(${proposalWhereClauses.join(' OR ')})`);
      }
    }

    if (implementingAgency) {
      const implementingAgencyArray = implementingAgency
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      if (implementingAgencyArray.length) {
        const agencyWhereClauses = implementingAgencyArray.map((agency) => {
          return `(',' || COALESCE(r.implementing_agency, '') || ',') LIKE ${addParam(
            `%,${agency},%`,
          )}`;
        });

        whereParts.push(`(${agencyWhereClauses.join(' OR ')})`);
      }
    }

    if (reportNumber?.length) {
      whereParts.push(
        `r.report_number = ANY(${addParam(reportNumber)}::text[])`,
      );
    }

    if (status) {
      if (status === StatusEnum.NO_ACTION) {
        whereParts.push(`(r.current_status IS NULL OR r.current_status = '')`);
      } else {
        whereParts.push(`r.current_status = ${addParam(status)}`);
      }
    }

    if (recommendations && recommendations.length > 0) {
      whereParts.push(
        `r.id = ANY(${addParam(recommendations.map(Number))}::int[])`,
      );
    }

    if (search) {
      const searchParam = addParam(`%${search}%`);

      whereParts.push(`(
      r.name ILIKE ${searchParam}
      OR r.description ILIKE ${searchParam}
      OR r.recommendation_slug ILIKE ${searchParam}
    )`);
    }

    if (date) {
      whereParts.push(`r.meeting_date::date = ${addParam(date)}::date`);
    }

    let stage: string = RecommendationStageEnum.DEA_APPROVER;

    switch (user.role?.roleName) {
      case RoleEnum.MINISTRY_APPROVER:
        stage = RecommendationStageEnum.MINISTRY_APPROVER;
        break;

      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        break;

      case RoleEnum.DEA_DIRECTOR:
        stage = RecommendationStageEnum.DEA_DIRECTOR;
        break;

      case RoleEnum.DEA_APPROVER:
        stage = RecommendationStageEnum.DEA_APPROVER;
        break;

      default:
        stage = '';
        break;
    }

    if (pending) {
      whereParts.push(`r.stage = ${addParam(stage)}`);
    }

    if (
      !all &&
      (user.role?.roleName === RoleEnum.DEA_APPROVER ||
        user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
        user.role?.roleName === RoleEnum.NFRR_VIEWER)
    ) {
      const userIgomIds = user.userIgoms?.map((h) => h.igom.id) || [];
      const requestedIgomId = igomId ? Number(igomId) : undefined;

      if (
        requestedIgomId &&
        userIgomIds.length > 0 &&
        !userIgomIds.includes(requestedIgomId)
      ) {
        throw new ForbiddenException('You do not have access to this Igom');
      }

      const finalIgomIds = requestedIgomId ? [requestedIgomId] : userIgomIds;

      if (!finalIgomIds.length) {
        whereParts.push(`1=0`);
      } else {
        whereParts.push(
          `r.igom_id = ANY(${addParam(finalIgomIds.map(Number))}::int[])`,
        );
      }
    } else {
      if (igomId) {
        whereParts.push(`r.igom_id = ${addParam(Number(igomId))}`);
      }
    }

    let effectiveMinistryId: number | undefined;

    if (
      user.role?.roleName === RoleEnum.DEA_APPROVER ||
      user.role?.roleName === RoleEnum.DEA_DIRECTOR ||
      user.role?.roleName === RoleEnum.NFRR_VIEWER
    ) {
      effectiveMinistryId = ministryId ? Number(ministryId) : undefined;
    } else {
      effectiveMinistryId = user.ministry?.id;
    }

    if (effectiveMinistryId) {
      if (
        !(
          user.role?.roleName === RoleEnum.DEA_APPROVER ||
          user.role?.roleName === RoleEnum.DEA_DIRECTOR
        )
      ) {
        whereParts.push(`r.niti_approved = true`);
      }

      if (implementation === ImplementationEnum.MY) {
        whereParts.push(
          `r.ministry_id = ${addParam(Number(effectiveMinistryId))}`,
        );
      } else if (implementation === ImplementationEnum.OTHER) {
        const ministryParam = addParam(Number(effectiveMinistryId));

        whereParts.push(`
        r.primary_ministry_id = ${ministryParam}
        AND r.ministry_id IS NOT NULL
        AND r.ministry_id != ${ministryParam}
      `);
      } else if (implementation === ImplementationEnum.TOTAL) {
        const ministryParam = addParam(Number(effectiveMinistryId));

        whereParts.push(`(
        r.primary_ministry_id = ${ministryParam}
        OR r.ministry_id = ${ministryParam}
      )`);
      } else {
        whereParts.push(
          `r.ministry_id = ${addParam(Number(effectiveMinistryId))}`,
        );
      }
    }

    const roleNameParam = addParam(user.role?.roleName || '');

    const where = `WHERE ${whereParts.join(' AND ')}`;

    const updateStatusFilter = ![
      RoleEnum.MINISTRY_APPROVER,
      RoleEnum.MINISTRY_DIRECTOR,
    ].includes(user.role?.roleName as RoleEnum)
      ? "AND ru.ministry_approver_status = 'approved'"
      : '';

    const sql = `
    SELECT DISTINCT ON (r.recommendation_slug)
      r.recommendation_slug AS "recommendationSlug",
      r.name,
      r.description,
      r.timeline,
      r.niti_approved AS "DEA Approved",
      r.niti_remark AS "nitiRemarks",
      r.meeting_date AS "meetingDate",
      r.proposal_nature AS "proposalNature",
      r.report_number AS "reportNumber",
      r.implementing_agency AS "implAgency",
      r.budgetary_category AS "budgetaryCategory",

      jsonb_build_object(
        'id', igm.id,
        'name', igm.name,
        'slug', igm.slug
      ) AS "igom",

      jsonb_build_object(
        'id', pm.id,
        'name', pm.name
      ) AS "primaryMinistry",

      jsonb_build_object(
        'id', pd.id,
        'name', pd.name
      ) AS "primaryDepartment",

      (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', m.id,
            'name', m.name,
            'departments', (
              SELECT CASE
                WHEN COUNT(d.id) FILTER (WHERE d.id IS NOT NULL) = 0 THEN NULL
                ELSE jsonb_agg(
                  DISTINCT jsonb_build_object(
                    'id', d.id,
                    'name', d.name,
                    'recommendationDetails', (
                      SELECT jsonb_build_object(
                        'id', r2.id,
                        'reasonNotImplemented', r2.reason_not_implemented,
                        'deaApproved', r2.niti_approved,
                        'updatedTimeline', r2.updated_timeline,
                        'currentStatus', r2.current_status,
                        'closureStatus', r2.closure_status,
                        'closureRemark', r2.closure_remark,
                        'stage', r2.stage,
                        'currentStage', r2.current_stage,
                        'actionTaken', r2.action_taken_by_ministry,
                        'recRemarks', r2.remark,
                        'isActive', r2.is_active,
                        'isReassigned', r2.is_reassigned,
                        'reassignStatus', r2.reassign_status,
                        'reassignComments', r2.reassign_comments,
                        'otherMinistriesConsulted', r2.other_ministries_consulted,
                        'actsRulesProvisionsModified', r2.acts_rules_provisions_modified,

                        'showCloseButton',
                        (
                          CASE
                            WHEN ${roleNameParam} = 'Dea Approver'
                              AND (
                                r2.closure_status IS DISTINCT FROM 'closed'
                                AND r2.current_stage IS DISTINCT FROM 'Closed by HLC'
                              )
                              AND r2.timeline IS NOT NULL
                              AND r2.timeline < NOW()
                            THEN TRUE
                            ELSE FALSE
                          END
                        ),

                        'action',
                        CASE
                          WHEN r2.closure_status = 'CLOSED'
                            AND r2.current_stage = 'CLOSED_BY_HLC'
                            THEN 'CLOSED'

                          WHEN ${roleNameParam} = 'MINISTRY_DIRECTOR' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage = 'DEA_APPROVER' AND r2.niti_approved = true
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          WHEN ${roleNameParam} = 'MINISTRY_APPROVER' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'DEA_APPROVER' AND r2.niti_approved = true
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          WHEN ${roleNameParam} = 'DEA_APPROVER' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage IN ('DEA_APPROVER', 'DEA_DIRECTOR')
                                THEN ''
                              ELSE 'CURRENTLY_WITH_DEA_DIRECTOR'
                            END

                          WHEN ${roleNameParam} = 'MINISTRY_SECRETARY' THEN
                            CASE
                              WHEN r2.stage = 'MINISTRY_DIRECTOR'
                                THEN 'CURRENTLY_WITH_MINISTRY_DIRECTOR'
                              WHEN r2.stage = 'MINISTRY_APPROVER'
                                THEN 'CURRENTLY_WITH_MINISTRY_APPROVER'
                              WHEN r2.stage = 'DEA_DIRECTOR'
                                THEN 'CURRENTLY_WITH_DEA_DIRECTOR'
                              WHEN r2.stage = 'DEA_APPROVER'
                                THEN 'CURRENTLY_WITH_DEA_APPROVER'
                            END

                          ELSE ''
                        END
                      )
                      FROM t_igom_recommendation r2
                      WHERE r2.recommendation_slug = r.recommendation_slug
                        AND r2.ministry_id = m.id
                        AND r2.department_id = d.id
                      ORDER BY r2.created_at DESC
                      LIMIT 1
                    ),

                    'recommendationUpdates', (
                      SELECT COALESCE(
                        jsonb_agg(
                          jsonb_build_object(
                            'id', ru.id,
                            'status', ru.status,
                            'createdAt', ru.created_at,
                            'reasonNotImplemented', ru.reason_not_implemented,
                            'ministryApprover_status', ru.ministry_approver_status,
                            'actionTakenByMinistry', ru.action_taken_by_ministry,
                            'relatedToHlc', ru.related_to_hlc,
                            'hlcRefId', ru.hlc_ref_id
                          )
                          ORDER BY ru.created_at DESC
                        ),
                        '[]'::jsonb
                      )
                      FROM t_igom_recommendation_updates ru
                      WHERE ru.igom_recommendation_id IN (
                        SELECT r3.id
                        FROM t_igom_recommendation r3
                        WHERE r3.recommendation_slug = r.recommendation_slug
                          AND r3.ministry_id = m.id
                          AND r3.department_id = d.id
                      )
                      ${updateStatusFilter}
                    )
                  )
                )
              END
              FROM t_igom_recommendation r2
              LEFT JOIN t_departments d ON d.id = r2.department_id
              WHERE r2.recommendation_slug = r.recommendation_slug
                AND r2.ministry_id = m.id
            ),

            'recommendationDetails', (
              SELECT jsonb_build_object(
                'id', r2.id,
                'reasonNotImplemented', r2.reason_not_implemented,
                'deaApproved', r2.niti_approved,
                'updatedTimeline', r2.updated_timeline,
                'currentStatus', r2.current_status,
                'closureStatus', r2.closure_status,
                'closureRemark', r2.closure_remark,
                'stage', r2.stage,
                'currentStage', r2.current_stage,
                'actionTaken', r2.action_taken_by_ministry,
                'recRemarks', r2.remark,
                'isActive', r2.is_active,
                'isReassigned', r2.is_reassigned,
                'reassignComments', r2.reassign_comments,
                'reassignStatus', r2.reassign_status,
                'otherMinistriesConsulted', r2.other_ministries_consulted,
                'actsRulesProvisionsModified', r2.acts_rules_provisions_modified,

                'showCloseButton',
                (
                  CASE
                    WHEN ${roleNameParam} = 'Dea Approver'
                      AND (
                        r2.closure_status IS DISTINCT FROM 'closed'
                        AND r2.current_stage IS DISTINCT FROM 'Closed by HLC'
                      )
                      AND r2.timeline IS NOT NULL
                      AND r2.timeline < NOW()
                    THEN TRUE
                    ELSE FALSE
                  END
                ),

                'action',
                CASE
                  WHEN r2.closure_status = 'closed'
                    AND r2.current_stage = 'Closed by HLC'
                    THEN 'CLOSED'

                  WHEN ${roleNameParam} = 'Ministry Director' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage = 'DEA Approver' AND r2.niti_approved = true
                        THEN 'CURRENTLY WITH DEA APPROVER'
                      WHEN r2.stage = 'Ministry Director'
                        THEN ''
                      ELSE 'CURRENTLY WITH DEA APPROVER'
                    END

                  WHEN ${roleNameParam} = 'Dea Director' THEN
                    CASE
                      WHEN r2.stage = 'Reassign Pending'
                        AND r.current_stage = 'Pending with DEA Approver for Reassign Pending'
                        THEN 'Currently with DEA Approver for Reassign Pending'
                      ELSE ''
                    END

                  WHEN ${roleNameParam} = 'Ministry Approver' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'DEA Approver' AND r2.niti_approved = true
                        THEN 'CURRENTLY WITH DEA APPROVER'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN ''
                      ELSE 'CURRENTLY WITH DEA APPROVER'
                    END

                  WHEN ${roleNameParam} = 'Dea Approver' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage IN ('DEA Approver', 'DEA Director')
                        THEN ''
                      WHEN r2.stage = 'Reassign Pending'
                        AND r.current_stage = 'Pending with DEA Approver for Reassign Pending'
                        THEN 'Currently with DEA Approver for Reassign Pending'
                      ELSE 'CURRENTLY WITH DEA DIRECTOR'
                    END

                  WHEN ${roleNameParam} = 'Ministry Secretary' THEN
                    CASE
                      WHEN r2.stage = 'Ministry Director'
                        THEN 'CURRENTLY WITH MINISTRY DIRECTOR'
                      WHEN r2.stage = 'Ministry Approver'
                        THEN 'CURRENTLY WITH MINISTRY APPROVER'
                      WHEN r2.stage = 'DEA Director'
                        THEN 'CURRENTLY WITH DEA DIRECTOR'
                      WHEN r2.stage = 'DEA Approver'
                        THEN 'CURRENTLY WITH DEA APPROVER'
                    END

                  ELSE ''
                END
              )
              FROM t_igom_recommendation r2
              WHERE r2.recommendation_slug = r.recommendation_slug
                AND r2.ministry_id = m.id
                AND r2.department_id IS NULL
              ORDER BY r2.created_at DESC
              LIMIT 1
            ),

            'recommendationUpdates', (
              SELECT COALESCE(
                jsonb_agg(
                  jsonb_build_object(
                    'id', ru.id,
                    'status', ru.status,
                    'createdAt', ru.created_at,
                    'reasonNotImplemented', ru.reason_not_implemented,
                    'ministryApprover_status', ru.ministry_approver_status,
                    'actionTakenByMinistry', ru.action_taken_by_ministry,
                    'relatedToHlc', ru.related_to_hlc,
                    'hlcRefId', ru.hlc_ref_id
                  )
                  ORDER BY ru.created_at DESC
                ),
                '[]'::jsonb
              )
              FROM t_igom_recommendation_updates ru
              WHERE ru.igom_recommendation_id IN (
                SELECT r3.id
                FROM t_igom_recommendation r3
                WHERE r3.recommendation_slug = r.recommendation_slug
                  AND r3.ministry_id = m.id
                  AND r3.department_id IS NULL
              )
              ${updateStatusFilter}
            )
          )
        )
        FROM t_ministry m
        WHERE m.id IN (
          SELECT DISTINCT r4.ministry_id
          FROM t_igom_recommendation r4
          WHERE r4.recommendation_slug = r.recommendation_slug
            AND r4.ministry_id IS NOT NULL
        )
      ) AS "implementingMinistries"

    FROM t_igom_recommendation r
    LEFT JOIN t_ministry pm ON pm.id = r.primary_ministry_id
    LEFT JOIN t_departments pd ON pd.id = r.primary_department_id
    LEFT JOIN t_igom igm ON igm.id = r.igom_id
    ${where}
    ORDER BY r.recommendation_slug, r.created_at DESC
  `;

    const baseParams = [...params];

    let finalQuery = sql;
    let finalParams = [...baseParams];

    if (!noPagination) {
      finalParams.push(Number(limit));
      const limitParam = `$${finalParams.length}`;

      finalParams.push((Number(page) - 1) * Number(limit));
      const offsetParam = `$${finalParams.length}`;

      finalQuery += ` LIMIT ${limitParam} OFFSET ${offsetParam}`;
    }

    const [recData, totalIgom] = await Promise.all([
      this.igomRecommendationRepository.query(finalQuery, finalParams),
      this.igomRecommendationRepository.query(sql, baseParams),
    ]);

    const data = recData.map((item) => {
      if (item.recommendationSlug === 'IGoM/A/IV/444444') {
        console.log('item', item);
      }

      const isClosed =
        item.closureStatus === ClosureStatusEnum.CLOSED ||
        item.currentStage === StageEnum.CLOSED_BY_HLC;

      const isTimelineCrossed =
        item.timeline && new Date(item.timeline).getTime() < Date.now();

      const isNitiApprover =
        user.role?.roleName === RoleEnum.DEA_APPROVER ||
        user.role?.roleName === 'Dea Approver';

      const showCloseButton = isNitiApprover && !isClosed && isTimelineCrossed;

      return {
        ...item,
        closureRemark: item.closureRemark ?? null,
        closureStatus: item.closureStatus ?? null,
        showCloseButton,
      };
    });

    return noPagination
      ? data
      : {
          pendingCount,
          total: totalIgom.length,
          page,
          limit,
          results: data,
        };
  }

  flattenRecommendations(data: any[]) {
    const result: any = [];

    for (const rec of data) {
      const base = {
        recommendationSlug: rec.recommendationSlug,
        name: rec.name,
        description: rec.description,
        timeline: rec.timeline,
        meetingDate: rec.meetingDate,
        proposalNature: rec.proposalNature,
        reportNumber: rec.reportNumber,
        implAgency: rec.implAgency,
        budgetaryCategory: rec.budgetaryCategory,
        igom: rec.igom,
        primaryMinistry: rec.primaryMinistry,
        primaryDepartment: rec.primaryDepartment,
        nitiRemarks: rec.nitiRemarks,
        deaApproved: rec['DEA Approved'],
      };

      for (const ministry of rec.implementingMinistries || []) {
        // CASE 1: Department exists
        if (ministry.departments && ministry.departments.length) {
          for (const dept of ministry.departments) {
            const details = dept.recommendationDetails || {};

            result.push({
              ...base,
              ministry: {
                id: ministry.id,
                name: ministry.name,
              },
              department: {
                id: dept.id,
                name: dept.name,
              },
              currentStatus: details.currentStatus,
              actionTaken: details.actionTaken,
              stage: details.stage,
              currentStage: details.currentStage,
              deaApproved: details.deaApproved ?? base.deaApproved,
              recommendationUpdates: dept.recommendationUpdates || [],
            });
          }
        } else {
          const details = ministry.recommendationDetails || {};
          result.push({
            ...base,
            ministry: {
              id: ministry.id,
              name: ministry.name,
            },
            department: null,
            currentStatus: details.currentStatus,
            actionTaken: details.actionTaken,
            stage: details.stage,
            currentStage: details.currentStage,
            deaApproved: details.deaApproved ?? base.deaApproved,
            recommendationUpdates: ministry.recommendationUpdates || [],
          });
        }
      }
    }

    return result;
  }

  async exportIgomRecommendations(
    query: ExportRecommendationDto,
    userId: number,
    noPagination = false,
    all = false,
  ) {
    const { format } = query;
    let recommendations: any = await this.findAll(query, userId, true, all);
    const data: any[] = [];
    recommendations = this.flattenRecommendations(recommendations);

    recommendations.forEach((r) => {
      const baseRow = {
        'Serial No. of IGoM Recommendation': r.recommendationSlug,
        Description: r?.description ?? '-',
        Recommendations: r?.name ?? '-',
        Timeline: r.timeline
          ? new Date(r.timeline).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
          : '-',
        'Primary Ministry/Department': r.primaryDepartment?.name
          ? `${r.primaryMinistry?.name} / ${r.primaryDepartment?.name}`
          : r.primaryMinistry?.name || '-',
        'Implementing Ministry/Department': r.department?.name
          ? `${r.ministry?.name} / ${r.department?.name}`
          : r.ministry?.name || '-',
        'Nature of Proposal': r?.proposalNature ?? '-',
        'Agency Level': r?.implAgency ?? '-',
        'Budgetary Category': r?.budgetaryCategory ?? '-',
        'Meeting Date': r.meetingDate
          ? new Date(r.meetingDate).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
          : '-',
        'Implementation Status':
          r.recommendationUpdates?.length > 0
            ? r.recommendationUpdates[0].status
            : r.currentStatus || '-',
        'Details of Action Taken(To be entered by the Ministry)':
          r.recommendationUpdates?.length > 0
            ? `${new Date(r.recommendationUpdates[0].createdAt).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', month: 'short', day: '2-digit', year: 'numeric' })}:\n${r.recommendationUpdates[0].actionTakenByMinistry || ''}`
            : r.actionTakenByMinistry || '-',
        'Reason If Not Implemented':
          r.recommendationUpdates?.[0]?.reasonNotImplemented || '',
      };
      data.push(baseRow);
      if (r?.recommendationUpdates?.length > 1) {
        const updates = r.recommendationUpdates.slice(1);
        updates.forEach((item) => {
          data.push({
            'Serial No. of IGoM Recommendation': '',
            Description: '',
            Recommendations: '',
            Timeline: '',
            'Primary Ministry/Department': '',
            'Implementing Ministry/Department': '',
            'Nature of Proposal': '',
            'Agency Level': '',
            'Budgetary Category': '',
            'Meeting Date': '',
            'Implementation Status': item.status || '',
            'Details of Action Taken(To be entered by the Ministry)': `${item.createdAt ? new Date(item.createdAt).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', month: 'short', day: '2-digit', year: 'numeric' }) : ''}:\n${item.actionTakenByMinistry || ''}`,
            'Reason If Not Implemented': item.reasonNotImplemented || '',
          });
        });
      }
    });
    switch (format) {
      case FormatEnum.EXCEL:
        return this.generateExcel(data);
      case FormatEnum.CSV:
        return this.generateCSV(data);
      case FormatEnum.PDF:
        return this.generatePdf(data);
      case FormatEnum.WORD:
        return this.generateWord(data);
      case FormatEnum.PPT:
        return this.generatePpt(data);
      default:
        throw new Error('Unsupported export format');
    }
  }

  private generateExcel(data: any[]) {
    const worksheet = XLSX.utils.json_to_sheet(data);
    worksheet['!cols'] = Object.keys(data[0]).map(() => ({ wch: 30 }));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Recommendations');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  private generateCSV(data: any[]) {
    const parser = new Parser();
    const csv = parser.parse(data);
    return Buffer.from(csv);
  }

  private async generateWord(data: any[]): Promise<Buffer> {
    const headers = Object.keys(data[0]);

    const tableRows = [
      new TableRow({
        children: headers.map(
          (header) =>
            new TableCell({
              children: [new Paragraph({ text: header })],
            }),
        ),
      }),
      ...data.map(
        (row) =>
          new TableRow({
            children: headers.map(
              (header) =>
                new TableCell({
                  children: [new Paragraph(String(row[header] ?? ''))],
                }),
            ),
          }),
      ),
    ];

    const doc = new Document({
      sections: [
        {
          properties: {
            page: {
              size: {
                orientation: PageOrientation.LANDSCAPE,
                // width: 16838,
                // height: 11906
              },
              margin: {
                top: 720,
                bottom: 720,
                left: 720,
                right: 720,
              },
            },
          },
          children: [
            new Paragraph({
              text: 'IGoM Recommendations',
              heading: 'Heading1',
            }),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: tableRows,
            }),
          ],
        },
      ],
    });

    return await Packer.toBuffer(doc);
  }

  private async generatePpt(data: any[]): Promise<any> {
    const pptx = new PptxGenJS();
    pptx.layout = 'LAYOUT_WIDE';
    const SLIDE_W = 13.33;
    const SLIDE_H = 7.5;
    const MARGIN = 0.2;
    const TABLE_W = SLIDE_W - MARGIN * 2;
    const TITLE_H = 0.4;
    const FOOTER_H = 0.2;
    const HEADER_ROW_H = 0.4;
    const DATA_ROW_H = 0.5;
    const FONT_SIZE = 7.5;
    const HEADER_FONT_SIZE = 8;
    const AVAIL_H_SLIDE1 =
      SLIDE_H - MARGIN - TITLE_H - 0.05 - HEADER_ROW_H - FOOTER_H - MARGIN;
    const AVAIL_H_REST = SLIDE_H - MARGIN - HEADER_ROW_H - FOOTER_H - MARGIN;
    const ROWS_SLIDE1 = Math.floor(AVAIL_H_SLIDE1 / DATA_ROW_H);
    const ROWS_REST = Math.floor(AVAIL_H_REST / DATA_ROW_H);
    if (!data || data.length === 0) {
      return await pptx.write({ outputType: 'nodebuffer' });
    }
    const headers = Object.keys(data[0]);

    const weightMap: Record<string, number> = {
      'serial no. of hlc recommendation': 1.2,
      description: 2,
      recommendations: 2,
      timeline: 0.8,
      'primary ministry/department': 1.8,
      'implementing ministry/department': 1.8,
      'nature of proposal': 1,
      'agency level': 0.9,
      'budgetary category': 1,
      'meeting date': 0.9,
      'implementation status': 1,
      'details of action taken(to be entered by the ministry)': 2,
      'reason if not implemented': 1.5,
    };
    const getW = (h: string) => weightMap[h.toLowerCase()] ?? 1;
    const totalW = headers.reduce((s, h) => s + getW(h), 0);
    const colW = headers.map((h) =>
      parseFloat(((getW(h) / totalW) * TABLE_W).toFixed(3)),
    );

    const sumColW = colW.reduce((a, b) => a + b, 0);
    colW[colW.length - 1] += parseFloat((TABLE_W - sumColW).toFixed(3));
    const maxChars = (w: number) => Math.max(15, Math.round(w * 18));
    const truncate = (val: any, max: number) => {
      const s = val != null ? String(val).trim() : '';
      return s.length > max ? s.slice(0, max - 1) + '…' : s;
    };

    const allRows = data.map((row) => ({
      display: headers.map((h, i) => truncate(row[h], maxChars(colW[i]))),
      full: headers.map((h) => (row[h] != null ? String(row[h]).trim() : '')),
    }));
    const chunks: (typeof allRows)[] = [];
    let pos = 0;
    while (pos < allRows.length) {
      const limit = chunks.length === 0 ? ROWS_SLIDE1 : ROWS_REST;
      chunks.push(allRows.slice(pos, pos + limit));
      pos += limit;
    }
    const totalSlides = chunks.length;
    const HEADER_BG = '1F3864';
    chunks.forEach((chunk, si) => {
      const isFirst = si === 0;
      const slide = pptx.addSlide();
      slide.background = { color: 'FFFFFF' };

      let tableY = MARGIN;
      if (isFirst) {
        slide.addText('IGoM Recommendations', {
          x: MARGIN,
          y: MARGIN,
          w: TABLE_W,
          h: TITLE_H,
          fontSize: 14,
          bold: true,
          color: HEADER_BG,
          fontFace: 'Calibri',
          valign: 'middle',
        });
        tableY = MARGIN + TITLE_H + 0.05;
      }

      const headerRow = headers.map((h) => ({
        text: h,
        options: {
          bold: true,
          color: 'FFFFFF',
          fill: { color: HEADER_BG },
          fontSize: HEADER_FONT_SIZE,
          valign: 'middle' as const,
          align: 'center' as const,
          fontFace: 'Calibri',
          margin: [2, 2, 2, 2] as [number, number, number, number],
        },
      }));
      const dataRows = chunk.map((row, ri) =>
        row.display.map((cell) => ({
          text: cell,
          options: {
            fontSize: FONT_SIZE,
            valign: 'middle' as const,
            align: 'left' as const,
            fill: { color: ri % 2 === 0 ? 'FFFFFF' : 'DCE6F1' },
            color: '1A1A1A',
            fontFace: 'Calibri',
            margin: [2, 2, 2, 2] as [number, number, number, number],
          },
        })),
      );

      const rowHeights = [HEADER_ROW_H, ...chunk.map(() => DATA_ROW_H)];
      const tableH = rowHeights.reduce((a, b) => a + b, 0);
      slide.addTable([headerRow, ...dataRows], {
        x: MARGIN,
        y: tableY,
        w: TABLE_W,
        h: tableH,
        colW,
        rowH: rowHeights,
        border: { pt: 0.3, color: 'B8CCE4' },
        autoPage: false,
      });

      chunk.forEach((row, ri) => {
        let xCursor = MARGIN;
        const rowY = tableY + HEADER_ROW_H + ri * DATA_ROW_H;
        headers.forEach((_, ci) => {
          const fullText = row.full[ci];
          const cellW = colW[ci];
          // if (fullText && fullText !== row.display[ci]) {
          slide.addText(fullText, {
            x: xCursor,
            y: rowY,
            w: cellW,
            h: DATA_ROW_H,
            fontSize: FONT_SIZE,
            fontFace: 'Calibri',
            color: '1A1A1A',
            valign: 'top',
            align: 'left',
            margin: [2, 2, 2, 2] as [number, number, number, number],
            fill: { color: ri % 2 === 0 ? 'FFFFFF' : 'DCE6F1' },
            line: { color: 'FFFFFF', pt: 0 },
            wrap: true,
          });
          // }
          xCursor += cellW;
        });
      });

      const notes = chunk
        .map((row, ri) => {
          const label = `Row ${si * ROWS_REST + ri + 1}`;
          return (
            label +
            ':\n' +
            headers.map((h, i) => ` ${h}: ${row.full[i]}`).join('\n')
          );
        })
        .join('\n\n');
      slide.addNotes(notes);

      slide.addText(`Slide ${si + 1} of ${totalSlides}`, {
        x: MARGIN,
        y: SLIDE_H - FOOTER_H - 0.05,
        w: TABLE_W,
        h: FOOTER_H,
        fontSize: 8,
        color: '888888',
        align: 'right',
        fontFace: 'Calibri',
      });
    });
    return await pptx.write({ outputType: 'nodebuffer' });
  }

  async generatePdf(data: any[]) {
    const fonts = {
      Helvetica: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique',
      },
    };
    var printer = new PdfPrinter(fonts);

    const headers = Object.keys(data[0]);
    const body = [
      headers.map((h) => ({ text: h, bold: true })),
      ...data.map((row) => headers.map((h) => row[h] || '')),
    ];
    const docDefinition: any = {
      pageOrientation: 'landscape',
      defaultStyle: {
        font: 'Helvetica',
        fontSize: 8,
      },
      content: [
        { text: 'IGOM Recommendation Report', style: 'header' },
        {
          table: {
            headerRows: 1,
            // widths: Array(headers.length).fill('*'),
            widths: [50, 80, 80, 40, 60, 60, 40, 40, 40, 30, 50, 40, 40],
            body: body,
          },
        },
      ],
      footer: (currentPage, pageCount) => {
        return {
          text: `Page ${currentPage} of ${pageCount}`,
          alignment: 'center',
        };
      },
      styles: {
        header: {
          fontSize: 16,
          bold: true,
          alignment: 'center',
          margin: [0, 0, 0, 20],
        },
      },
    };
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks: any[] = [];
    return new Promise((resolve) => {
      pdfDoc.on('data', (chunk: any) => chunks.push(chunk));
      pdfDoc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });
      pdfDoc.end();
    });
  }

  async deaApproverRequest(
    body: DeaApproverRequestDto,
    recommendationName: string,
    userId: number,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: [
        'ministry',
        'department',
        'role',
        'userIgoms',
        'userIgoms.igom',
      ],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const { status, remarks, updatedTimeline } = body;
    let responseMessage = '';
    let trailDescription: string = '';
    const recommendations: IgomRecommendation[] | null =
      await this.igomRecommendationRepository.find({
        where: { recommendationSlug: recommendationName },
        relations: ['igomRecommendationUpdates'],
      });
    if (!recommendations || recommendations.length === 0) {
      throw new BadRequestException('Recommendations for id do not exist');
    }
    console.log('recommendationName', recommendationName);
    console.log('recommendations', recommendations);
    let currentStatus;
    let newStage;
    let currentStage;
    for (const recommendation of recommendations) {
      currentStatus = recommendation.currentStatus;
      currentStage = recommendation.currentStage;

      newStage = recommendation.currentStatus;
      trailDescription = TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;

      //updates present
      if (currentStatus) {
        if (currentStage === StageEnum.PENDING_WITH_DEA_APPROVER) {
          if (
            ![
              RequestStatusEnum.APPROVE,
              RequestStatusEnum.REJECT,
              RequestStatusEnum.FORWARDED,
            ].includes(status)
          ) {
            throw new BadRequestException('Request cannnot be fulfilled');
          }
          if (status === RequestStatusEnum.APPROVE) {
            if (
              currentStatus != StatusEnum.FULLY_IMPLEMENTED &&
              recommendation.timeline &&
              new Date(recommendation.timeline) < new Date()
            ) {
              newStage =
                StageEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE;
              trailDescription =
                TrailDescriptionEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE;
              responseMessage = 'Request approved successfully';
            }
            // Accept[ check needed for all rec updates]
            else {
              const hasNotFullyImplemented = recommendations?.some((rec) => {
                console.log('rec', rec);

                const updates = rec.igomRecommendationUpdates;
                console.log('updates', updates);
                if (!updates || updates.length === 0) return true;

                const latestUpdate = [...updates].sort(
                  (a, b) =>
                    new Date(b.createdAt).getTime() -
                    new Date(a.createdAt).getTime(),
                )[0];

                return latestUpdate.status !== StatusEnum.FULLY_IMPLEMENTED;
              });
              if (hasNotFullyImplemented) {
                throw new BadRequestException(
                  'All igom recommedations are not marked as fully implemented.',
                );
              }
              newStage = StageEnum.ACCEPTED_BY_DEA_APPROVER;
              trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
              responseMessage = 'Recommendation accepted successfully';
            }
            recommendation.stage = RecommendationStageEnum.DEA_APPROVER;

            // foreward
          } else if (status === RequestStatusEnum.FORWARDED) {
            newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
            trailDescription =
              TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
            recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
            responseMessage = 'Recommendation forwaded to ministry director';
          }
          //reject
          else {
            newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
            trailDescription = TrailDescriptionEnum.MARK_NOT_COMPLETED;
            recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
            responseMessage =
              'Recommendation rejected. Forwaded to ministry director';
          }
        } else if (currentStage === StageEnum.ACCEPTED_BY_DEA_APPROVER) {
          if (status !== RequestStatusEnum.FORWARDED) {
            throw new BadRequestException('Request cannnot be fulfilled');
          }
          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription =
            TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage = 'Recommendation forwaded to ministry director';
        } else if (
          updatedTimeline &&
          currentStage ===
            StageEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE
        ) {
          recommendation.updatedTimeline = updatedTimeline;
          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription = TrailDescriptionEnum.TIMELINE_UPDATED;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage = 'Timeline updated successfully';
        }
      }
      //simple flow
      else {
        if (status === RequestStatusEnum.APPROVE) {
          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription = TrailDescriptionEnum.APPROVED_BY_DEA_APPROVER;
          recommendation.nitiApproved = true;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage = 'Request approved successfully';
        } else {
          console.log('inside simple flow');
          newStage = StageEnum.PENDING_WITH_DEA_DIRECTOR;
          trailDescription = TrailDescriptionEnum.REJECTED_BY_DEA_APPROVER;
          recommendation.stage = RecommendationStageEnum.DEA_DIRECTOR;
          responseMessage = 'Request rejected';
        }
      }

      recommendation.currentStage = newStage;
      // if (remarks) recommendation.nitiRemark = remarks.trim();
      if (status !== RequestStatusEnum.APPROVE && remarks) {
        console.log('Remarks', 'status', remarks, status);
        recommendation.remark = remarks.trim();
      } else recommendation.remark = '';

      await this.igomRecommendationRepository.save(recommendation);
    }
    const trail: IgomRecommendationTrail =
      this.igomRecommendationTrailRepository.create({
        currentStatus: currentStage,
        nextStatus: newStage,

        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',

        route: 'DEA APPROVER REQUEST',
        user: user,

        description: `${trailDescription} for recommendation slug: ${recommendationName}`,

        otherDetails: {
          body,
        },
      });

    await this.igomRecommendationTrailRepository.save(trail);
    return responseMessage;
  }

  async directorReassign(
    body: ReassignRecommendationDto,
    recommendationId: number,
    userId: number,
  ) {
    const { departmentId, ministryId, reason } = body;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userIgoms', 'userIgoms.igom'],
    });

    if (!user) throw new NotFoundException('User not found');

    if (user.role?.roleName !== RoleEnum.DEA_DIRECTOR) {
      throw new ForbiddenException(
        `You cannot reassign recommendation due to user role permissions.`,
      );
    }

    const existingRec = await this.igomRecommendationRepository.findOne({
      where: { id: recommendationId },
      relations: [
        'igom',
        'primaryMinistry',
        'primaryDepartment',
        'department', // ✅ FIXED
        'ministry', // ✅ FIXED
      ],
    });

    if (!existingRec) {
      throw new NotFoundException(
        `Recommendation for id ${recommendationId} not found`,
      );
    }

    // ✅ IGOM check
    const igomIds = user?.userIgoms?.map((i) => i.igom.id) || [];
    if (!existingRec.igom?.id || !igomIds.includes(existingRec.igom.id)) {
      throw new ForbiddenException(
        `You cannot reassign recommendation for this IGOM.`,
      );
    }

    let department: Departments | null = null;
    let ministry: Ministry | null = null;

    if (departmentId) {
      department = await this.departmentRepository.findOne({
        where: { id: departmentId },
        relations: ['ministry'],
      });
      if (!department)
        throw new NotFoundException(`Department ${departmentId} not found`);
    }

    if (ministryId) {
      ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });
      if (!ministry)
        throw new NotFoundException(`Ministry ${ministryId} not found`);
    }

    // ✅ Validate mapping
    if (
      department &&
      department.ministry &&
      ministryId &&
      department.ministry.id !== ministryId
    ) {
      throw new BadRequestException(
        `Department does not belong to given ministry`,
      );
    }

    // ✅ ✅ BLOCK duplicate PENDING target
    const alreadyPending = await this.igonRecReassignRepository.findOne({
      where: {
        prevIgomRecommendation: {
          recommendationSlug: existingRec.recommendationSlug,
        },
        currentDepartment: department ? { id: department.id } : IsNull(),
        currentMinistry: ministry ? { id: ministry.id } : IsNull(),
        status: ReassignRecStatusEnum.PENDING,
      },
      relations: ['prevIgomRecommendation'],
    });

    if (alreadyPending) {
      throw new BadRequestException(
        `A reassign request is already pending for this recommendation & target.`,
      );
    }

    // ✅ CHECK EXISTING TARGET REC (reuse)
    const existingTarget = await this.igomRecommendationRepository.findOne({
      where: {
        recommendationSlug: existingRec.recommendationSlug,
        department: department ? { id: department.id } : IsNull(),
        ministry: ministry ? { id: ministry.id } : IsNull(),
      },
    });

    let newRecommendation: IgomRecommendation;

    if (existingTarget) {
      if (existingTarget.isActive) {
        throw new BadRequestException(
          `Recommendation already active for this target.`,
        );
      }

      // ✅ RESET ALL STATE (CRITICAL)
      existingTarget.stage = RecommendationStageEnum.REASSIGN_PENDING;
      existingTarget.currentStage =
        StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN;

      existingTarget.isReassigned = true;

      // ✅ FIX: reset reassign state
      existingTarget.reassignStatus = null;
      existingTarget.reassignComments = null;

      // ✅ optional cleanup (recommended)
      existingTarget.nitiApproved = false;

      existingTarget.primaryDepartment = existingRec.primaryDepartment;
      existingTarget.primaryMinistry = existingRec.primaryMinistry;

      newRecommendation =
        await this.igomRecommendationRepository.save(existingTarget);
    } else {
      // ✅ CREATE NEW
      newRecommendation = await this.igomRecommendationRepository.save(
        this.igomRecommendationRepository.create({
          recommendationSlug: existingRec.recommendationSlug,
          name: existingRec.name,
          description: existingRec.description,
          timeline: existingRec.timeline,
          budgetaryCategory: existingRec.budgetaryCategory,
          proposalNature: existingRec.proposalNature,
          meetingDate: existingRec.meetingDate,
          implementingAgency: existingRec.implementingAgency,
          reportNumber: existingRec.reportNumber,
          igom: existingRec.igom,
          primaryDepartment: existingRec.primaryDepartment,
          primaryMinistry: existingRec.primaryMinistry,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
          stage: RecommendationStageEnum.REASSIGN_PENDING,
          ministry: ministry || null,
          department: department || null,
          isReassigned: true,
          isActive: false,
        }),
      );
    }

    // ✅ SAVE REASSIGN RECORD
    const recReassign = this.igonRecReassignRepository.create({
      igom: existingRec.igom,
      reassignedBy: user,
      prevDepartment: existingRec.department || null,
      prevMinistry: existingRec.ministry || null,
      currentDepartment: department || null,
      currentMinistry: ministry || null,
      prevIgomRecommendation: existingRec,
      status: ReassignRecStatusEnum.PENDING,
      reason,
    });

    await this.igonRecReassignRepository.save(recReassign);

    // ✅ UPDATE OLD REC
    await this.igomRecommendationRepository.update(existingRec.id, {
      reassignStatus: ReassignRecommStatusEnum.PENDING,
    });

    // ✅ TRAIL
    await this.igomRecommendationTrailRepository.save(
      this.igomRecommendationTrailRepository.create({
        igomRecommendation: existingRec,
        currentStatus: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
        nextStatus: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',
        route: 'DIRECTOR REASSIGN REQUEST',
        user,
        description: `Reassign from ${existingRec.id} to ${newRecommendation.id}`,
        otherDetails: { body },
      }),
    );

    return { message: 'Reassign request created successfully' };
  }

  async approveOrRejectRecReassign(
    recId: number,
    userId: number,
    dto: ApproveReassignDto,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });

    if (!user) throw new NotFoundException('User not found');

    if (user.role?.roleName !== RoleEnum.DEA_APPROVER) {
      throw new ForbiddenException(
        'Not authorized to approve/reject reassign.',
      );
    }

    const existingRec = await this.igomRecommendationRepository.findOne({
      where: { id: recId },
      relations: ['department', 'ministry'],
    });

    if (!existingRec)
      throw new NotFoundException('Recommendation entry not found');

    const recReassign = await this.igonRecReassignRepository.findOne({
      where: {
        prevIgomRecommendation: {
          recommendationSlug: existingRec.recommendationSlug,
        },
        currentDepartment: existingRec.department
          ? { id: existingRec.department.id }
          : IsNull(),
        currentMinistry: existingRec.ministry
          ? { id: existingRec.ministry.id }
          : IsNull(),
        status: ReassignRecStatusEnum.PENDING,
      },
      relations: ['prevIgomRecommendation'],
    });

    if (!recReassign) throw new NotFoundException('Reassign entry not found');

    const isApproved = dto.status === ReassignStatusEnum.APPROVED;

    await this.igomRecommendationRepository.update(existingRec.id, {
      isActive: isApproved ? true : existingRec.isActive,
      stage: isApproved
        ? RecommendationStageEnum.MINISTRY_DIRECTOR
        : RecommendationStageEnum.REASSIGN_REJECTED,
      currentStage: isApproved
        ? StageEnum.PENDING_WITH_MINISTRY_DIRECTOR
        : StageEnum.REASSIGN_REJECTED,
      nitiApproved: isApproved ? true : existingRec.nitiApproved,
      reassignStatus: isApproved
        ? ReassignRecommStatusEnum.APPROVED_TO
        : ReassignRecommStatusEnum.REJECTED,
      reassignComments: dto.comment,
    });

    if (isApproved) {
      await this.igomRecommendationRepository.update(
        recReassign.prevIgomRecommendation.id,
        {
          isActive: false,
          reassignStatus: ReassignRecommStatusEnum.APPROVED_FROM,
        },
      );
    }

    await this.igonRecReassignRepository.update(recReassign.id, {
      status: isApproved
        ? ReassignRecStatusEnum.APPROVED
        : ReassignRecStatusEnum.REJECTED,
      reviewdBy: user,
      reviewedAt: new Date(),
      remarks: dto.comment || null,
    });

    const trail = this.igomRecommendationTrailRepository.create({
      igomRecommendation: existingRec,
      currentStatus: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
      nextStatus: isApproved
        ? StageEnum.PENDING_WITH_MINISTRY_DIRECTOR
        : StageEnum.REASSIGN_REJECTED,
      userName: user.name ?? 'Unknown',
      userEmail: user.email ?? 'Unknown',
      userRole: user.role?.roleName ?? 'Unknown',
      route: 'APPROVER REASSIGN REQUEST',
      user,
      description: `Reassign ${dto.status} for Rec ${existingRec.id}`,
      otherDetails: { dto },
    });

    await this.igomRecommendationTrailRepository.save(trail);

    return {
      message: `Reassign ${dto.status.toLowerCase()} successfully.`,
    };
  }

  async ministryDirectorRequest(
    body: MinistryDirectorRequestDto,
    recommendationId: number,
    userId: number,
    recDraft: boolean = false,
  ) {
    try {
      const recommendation = await this.igomRecommendationRepository.findOne({
        where: { id: recommendationId },
        relations: ['ministry', 'department'],
      });

      if (!recommendation) {
        throw new BadRequestException('Igom Recommendation does not exist');
      }

      if (!recDraft) {
        const recDraft = await this.igomRecommendationDraftRepository.findOne({
          where: {
            igomRecommendation: { id: recommendationId },
            draftStatus: DraftStatusEnum.PENDING,
          },
        });
        if (recDraft) {
          throw new BadRequestException(
            'Igom Recommendation draft already exists for this recommendation. Please complete the draft before sending a new request.',
          );
        }
      }
      const user = await this.userRepository.findOne({
        where: { id: userId },
        relations: ['role', 'ministry', 'department'],
      });
      if (!user) throw new BadRequestException('User not found');
      else {
        if (
          (recommendation.ministry &&
            (!user.ministry ||
              user.ministry.id !== recommendation.ministry.id)) ||
          (recommendation.department &&
            (!user.department ||
              user.department.id !== recommendation.department.id))
        ) {
          throw new BadRequestException(
            'User not allowed to process request for ministry/department',
          );
        }
      }
      const {
        actionTakenByMinistry,
        status,
        reasonIfNotImplemented,
        actsRulesProvisionsModified,
        otherMinistriesConsulted,
        isHlcRelated,
        hlcRefId,
      } = body;
      // const newStatus = status;
      const newStage = StageEnum.PENDING_WITH_MINISTRY_APPROVER;

      console.log('recommendation', recommendation);
      let lastStatus = recommendation.currentStatus;
      recommendation.currentStage = newStage;

      recommendation.stage = RecommendationStageEnum.MINISTRY_APPROVER;
      recommendation.remark = '';

      recommendation.actsRulesProvisionsModified =
        actsRulesProvisionsModified?.trim() || null;

      recommendation.otherMinistriesConsulted =
        otherMinistriesConsulted?.trim() || null;

      await this.igomRecommendationRepository.save(recommendation);

      let recommendationUpdate;

      if (user.role?.roleName === RoleEnum.MINISTRY_DIRECTOR) {
        recommendationUpdate = this.igomRecommendationUpdatesRepository.create({
          igomRecommendation: recommendation,
          reasonNotImplemented:
            status === StatusEnum.FULLY_IMPLEMENTED
              ? null
              : reasonIfNotImplemented?.trim(),
          status,
          actionTakenByMinistry: actionTakenByMinistry?.trim(),
          ministryApproverStatus: ImplementationStatusEnum.PENDING,
          relatedToHlc: isHlcRelated,
          hlcRefId: hlcRefId,
          user: { id: userId },
        });
      } else {
        recommendationUpdate =
          await this.igomRecommendationUpdatesRepository.findOne({
            where: {
              igomRecommendation: { id: recommendation.id },
              ministryApproverStatus: ImplementationStatusEnum.PENDING,
            },
            order: { createdAt: 'DESC' },
          });

        if (!recommendationUpdate) {
          // create a NEW pending update
          recommendationUpdate =
            this.igomRecommendationUpdatesRepository.create({
              igomRecommendation: recommendation,
              status,
              actionTakenByMinistry: actionTakenByMinistry?.trim(),
              reasonNotImplemented:
                status === StatusEnum.FULLY_IMPLEMENTED
                  ? null
                  : reasonIfNotImplemented?.trim(),
              ministryApproverStatus: ImplementationStatusEnum.PENDING,
              relatedToHlc: isHlcRelated,
              hlcRefId: hlcRefId,
              user: { id: userId },
            });
        } else {
          recommendationUpdate.actionTakenByMinistry =
            actionTakenByMinistry?.trim();
          recommendationUpdate.status = status;
          recommendationUpdate.reasonNotImplemented =
            status === StatusEnum.FULLY_IMPLEMENTED
              ? null
              : reasonIfNotImplemented?.trim();
        }
      }

      await this.igomRecommendationUpdatesRepository.save(recommendationUpdate);

      const trail: IgomRecommendationTrail =
        this.igomRecommendationTrailRepository.create({
          igomRecommendation: recommendation,
          currentStatus: recommendation.currentStage,
          nextStatus: status,

          userName: user.name ?? 'Unknown',
          userEmail: user.email ?? 'Unknown',
          userRole: user.role?.roleName ?? 'Unknown',

          route: 'IGOM MINISTRY DIRECTOR REQUEST',
          user: user,

          description: `${TrailDescriptionEnum.MINISTRY_DIRECTOR_UPDATE} for recommendation id: ${recommendation.id}`,

          otherDetails: {
            body,
          },
        });
      await this.igomRecommendationTrailRepository.save(trail);
      return 'Request updated successfully';
    } catch (error) {
      console.error('Error updating recommendation:', error);
      throw error;
    }
  }

  async ministryApproverRequest(
    body: MinistryApproverRequestDto,
    recommendationId: number,
    userId: number,
  ) {
    const { status, remarks } = body;
    try {
      const recommendation = await this.igomRecommendationRepository.findOne({
        where: { id: recommendationId },
        relations: ['ministry', 'department'],
      });

      if (!recommendation) {
        throw new BadRequestException('Igom Recommendation does not exist');
      }

      const user = await this.userRepository.findOne({
        where: { id: userId },
        relations: ['role', 'ministry', 'department'],
      });
      if (!user) throw new BadRequestException('User not found');
      else {
        if (
          (recommendation.ministry &&
            (!user.ministry ||
              user.ministry.id !== recommendation.ministry.id)) ||
          (recommendation.department &&
            (!user.department ||
              user.department.id !== recommendation.department.id))
        ) {
          throw new BadRequestException(
            'User not allowed to process request for ministry/department',
          );
        }
      }

      const lastStage = recommendation.currentStage;

      const timeline: any =
        recommendation?.updatedTimeline || recommendation?.timeline;
      let isTenDaysAway = false;
      if (timeline) {
        isTenDaysAway = this.isMoreThanTenDaysAway(timeline);
      }
      const latestUpdate =
        await this.igomRecommendationUpdatesRepository.findOne({
          where: {
            igomRecommendation: recommendation,
            // ministryApproverStatus: ImplementationStatusEnum.PENDING,
          },
          order: { createdAt: 'DESC' },
        });

      // if (!latestUpdate) {
      //   throw new BadRequestException('No Update found');
      // }
      console.log('isTenDaysAway', isTenDaysAway);
      console.log('latestUpdate', latestUpdate);
      let trailDescription = '';
      let stage = '';
      if (!timeline) {
        recommendation.currentStatus = latestUpdate?.status;

        if (latestUpdate?.hlcRefId) {
          const recomUpdate =
            await this.recommendationUpdatesRepository.findOne({
              where: {
                recommendation: { recommendationSlug: latestUpdate.hlcRefId },
              },
              order: { createdAt: 'DESC' },
            });

          recommendation.hlcRefId = latestUpdate.hlcRefId;
          recommendation.currentStatus =
            recomUpdate?.status ?? 'No HLC updates present';
        }
        recommendation.actionTakenByMinistry =
          latestUpdate?.actionTakenByMinistry;
        recommendation.reasonNotImplemented =
          latestUpdate?.reasonNotImplemented;
        if (status === RequestStatusEnum.APPROVE) {
          recommendation.currentStage = StageEnum.PENDING_WITH_DEA_APPROVER;
          stage = RecommendationStageEnum.DEA_APPROVER;
          trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
          if (
            !recommendation?.hlcRefId &&
            recommendation?.currentStatus !== StatusEnum.FULLY_IMPLEMENTED
          ) {
            recommendation.currentStage =
              StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
            stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
            trailDescription =
              TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
          }
        } else if (status === RequestStatusEnum.REJECT) {
          recommendation.hlcRefId = '';
          recommendation.currentStage =
            StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          trailDescription = TrailDescriptionEnum.REJECTED_BY_MINISTRY_APPROVER;
        }
      } else if (
        isTenDaysAway &&
        status === RequestStatusEnum.APPROVE &&
        [
          StatusEnum.FULLY_IMPLEMENTED,
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ].includes(latestUpdate?.status as StatusEnum)
      ) {
        recommendation.currentStatus = latestUpdate?.status;
        recommendation.currentStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      } else if (status === RequestStatusEnum.REJECT) {
        recommendation.currentStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.REJECTED_BY_MINISTRY_APPROVER;
      } else if (
        !isTenDaysAway &&
        status === RequestStatusEnum.APPROVE &&
        [StatusEnum.FULLY_IMPLEMENTED].includes(
          latestUpdate?.status as StatusEnum,
        )
      ) {
        recommendation.actionTakenByMinistry =
          latestUpdate?.actionTakenByMinistry;
        recommendation.reasonNotImplemented =
          latestUpdate?.reasonNotImplemented;
        recommendation.currentStatus = latestUpdate?.status;
        recommendation.currentStage = StageEnum.PENDING_WITH_DEA_APPROVER;
        stage = RecommendationStageEnum.DEA_APPROVER;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      }
      //not fully implemented
      else {
        if (status === RequestStatusEnum.APPROVE && latestUpdate?.hlcRefId) {
          const recomUpdate =
            await this.recommendationUpdatesRepository.findOne({
              where: {
                recommendation: { recommendationSlug: latestUpdate.hlcRefId },
              },
              order: { createdAt: 'DESC' },
            });

          recommendation.hlcRefId = latestUpdate.hlcRefId;
          recommendation.currentStatus =
            recomUpdate?.status ?? 'No HLC updates present';
          recommendation.currentStage = StageEnum.PENDING_WITH_DEA_APPROVER;
          stage = RecommendationStageEnum.DEA_APPROVER;
        } else {
          recommendation.currentStage =
            StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        }

        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      }
      if (stage) recommendation.stage = stage;
      if (remarks) recommendation.remark = remarks.trim();
      else recommendation.remark = '';

      if (latestUpdate) {
        let ministryApproverStatus = ImplementationStatusEnum.PENDING;
        if (status === RequestStatusEnum.APPROVE) {
          ministryApproverStatus = ImplementationStatusEnum.APPROVED;
        } else if (status === RequestStatusEnum.REJECT) {
          ministryApproverStatus = ImplementationStatusEnum.REJECTED;
        }

        await this.igomRecommendationUpdatesRepository.update(
          {
            id: latestUpdate?.id,
            ministryApproverStatus: ImplementationStatusEnum.PENDING,
          },
          {
            remark: remarks?.trim(),
            ministryApproverStatus: ministryApproverStatus,
          },
        );
      }

      await this.igomRecommendationRepository.save(recommendation);

      const trail: IgomRecommendationTrail =
        this.igomRecommendationTrailRepository.create({
          igomRecommendation: recommendation,
          currentStatus: recommendation.currentStage,
          nextStatus: stage,

          userName: user.name ?? 'Unknown',
          userEmail: user.email ?? 'Unknown',
          userRole: user.role?.roleName ?? 'Unknown',

          route: 'IGOM MINISTRY APPROVER REQUEST',
          user: user,

          description: `${trailDescription} for recommendation id: ${recommendation.id}`,

          otherDetails: {
            body,
          },
        });
      await this.igomRecommendationTrailRepository.save(trail);
      return status === RequestStatusEnum.APPROVE
        ? 'Request approved successfully'
        : 'Request rejected successfully';
    } catch (error) {
      console.error('Error updating recommendation:', error);
      throw new BadRequestException(
        error.message || 'Failed to process ministry approver request',
      );
    }
  }

  isMoreThanTenDaysAway(target: any, from: Date = new Date()): boolean {
    const t = new Date(target);
    const f = new Date(from);

    // normalize time
    f.setHours(0, 0, 0, 0);
    t.setHours(0, 0, 0, 0);

    const diffInMs = t.getTime() - f.getTime();
    const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

    return diffInDays > 10;
  }

  async closeRecommendation(
    recommendationId: number,
    body: CloseRecommendationDto,
    userId: number,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role', 'ministry', 'department'],
    });
    if (!user) throw new BadRequestException('User not found');
    const { closureRemark } = body;

    const recommendation = await this.igomRecommendationRepository.findOne({
      where: { id: recommendationId },
    });

    if (!recommendation) {
      throw new BadRequestException('Recommendation does not exist');
    }
    const lastStage = recommendation.currentStage;

    if (recommendation.closureStatus === ClosureStatusEnum.CLOSED) {
      throw new BadRequestException('Recommendation is already closed');
    }

    recommendation.currentStage = StageEnum.CLOSED_BY_IGOM;
    recommendation.closureStatus = ClosureStatusEnum.CLOSED;
    recommendation.closedAt = new Date();
    recommendation.closedBy = { id: userId } as User;
    recommendation.closureRemark = closureRemark?.trim() || '';

    await this.igomRecommendationRepository.save(recommendation);
    const trail: IgomRecommendationTrail =
      this.igomRecommendationTrailRepository.create({
        igomRecommendation: recommendation,
        currentStatus: lastStage,
        nextStatus: StageEnum.CLOSED_BY_HLC,

        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',

        route: 'IGOM RECOMMENDATION CLOSE REQUEST',
        user: user,

        description: `${TrailDescriptionEnum.CLOSED_BY_IGOM} for recommendation id: ${recommendation.id}`,

        otherDetails: {
          body,
        },
      });
    await this.igomRecommendationTrailRepository.save(trail);
    return { message: 'Recommendation closed successfully' };
  }

  async bulkApproveDea(data: BulkApproveDto, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userIgoms', 'userIgoms.igom'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (!user.userIgoms) {
      throw new NotFoundException('User Igoms not found');
    }
    let ids = data.recommendations;

    let recommendations: any[];
    const igomIds: any = user?.userIgoms?.map((h) => h.igom.id) || [];

    if (!ids || ids.length === 0) {
      recommendations = await this.igomRecommendationRepository.find({
        where: {
          nitiApproved: false,
          igom: In(igomIds),
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        },
      });
    } else {
      recommendations = await this.igomRecommendationRepository.find({
        where: {
          id: In(ids),
          igom: In(igomIds),
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
        },
      });
    }
    ids = recommendations.map((r) => r.id);

    if (recommendations.length === 0) {
      return {
        message: 'No igom recommendations available for approval',
        total: 0,
      };
    }

    await this.igomRecommendationRepository.update(
      { id: In(ids) },
      {
        nitiApproved: true,
        currentStage: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
        stage: RecommendationStageEnum.MINISTRY_DIRECTOR,
        updatedAt: new Date(),
      },
    );

    for (const rec of recommendations) {
      const trail: IgomRecommendationTrail =
        this.igomRecommendationTrailRepository.create({
          igomRecommendation: rec,
          currentStatus: StageEnum.PENDING_WITH_DEA_APPROVER,
          nextStatus: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
          description: `${TrailDescriptionEnum.APPROVED_BY_DEA_APPROVER} for recommendation id: ${rec.id}`,

          userName: user.name ?? 'Unknown',
          userEmail: user.email ?? 'Unknown',
          userRole: user.role?.roleName ?? 'Unknown',

          route: 'BULK APPROVE DEA APPROVER REQUEST',
          user: user,
          otherDetails: {
            data,
          },
        });
      await this.igomRecommendationTrailRepository.save(trail);
    }

    return {
      message: 'Bulk approval By Dea Approver completed successfully',
      total: ids.length,
    };
  }

  async bulkApproveMinistry(data: BulkApproveDto, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (!user.ministry) {
      throw new NotFoundException('User ministry not found');
    }

    let ids = data.recommendations;
    let recommendations: any[] = [];

    // Helper: for user.ministry primary key
    const ministryId = user.ministry.id;

    // Build the correct SQL query with placeholders
    function buildRecommendationsSql(ids?: number[]) {
      let whereId = '';
      if (ids && ids.length > 0) {
        const idsParams = ids.map((_, idx) => `$${idx + 3}`).join(',');
        whereId = `AND rec.id IN (${idsParams})`;
      }
      return `
      SELECT
        rec.*,
        latestupdate.id AS latest_update_id,
        latestupdate.igom_recommendation_id,
        latestupdate.created_at AS latest_update_created_at,
        latestupdate.action_taken_by_ministry,
        latestupdate.reason_not_implemented,
        latestupdate.status AS latest_update_status,
        latestupdate.remark AS latest_update_remark,
        latestupdate.ministry_approver_status,
        latestupdate.user_id AS latest_update_user_id,
        latestupdate.updated_at AS latest_update_updated_at,
        latestupdate.related_to_hlc,
        latestupdate.hlc_ref_id
      FROM
        t_igom_recommendation rec
      LEFT JOIN LATERAL (
        SELECT
          updates.*
        FROM
          t_igom_recommendation_updates updates
        WHERE
          updates.igom_recommendation_id = rec.id
        ORDER BY
          updates.created_at DESC
        LIMIT 1
      ) latestupdate ON TRUE
      WHERE
        rec.ministry_id = $1
        AND rec.niti_approved = true
        AND rec.current_stage = $2
        ${whereId}
    `;
    }

    if (!ids || ids.length === 0) {
      // Query all eligible recommendations for this ministry
      const rawQuery = buildRecommendationsSql();
      recommendations = await this.igomRecommendationRepository.query(
        rawQuery,
        [ministryId, StageEnum.PENDING_WITH_MINISTRY_APPROVER],
      );
      if (recommendations.length === 0) {
        return {
          message: 'No recommendations available for approval',
          total: 0,
        };
      }
      ids = recommendations.map((r) => r.id);
    } else {
      // Query only given IDs (and validate existence, status)
      const rawQuery = buildRecommendationsSql(ids);
      recommendations = await this.igomRecommendationRepository.query(
        rawQuery,
        [ministryId, StageEnum.PENDING_WITH_MINISTRY_APPROVER, ...ids],
      );
      if (recommendations.length !== ids.length) {
        throw new BadRequestException(
          'Some recommendations do not exist, are already approved, or are not in the correct stage',
        );
      }
    }

    // Your update loop and status-check logic
    for (const rec of recommendations) {
      // For SQL result, the latestUpdate fields are like latest_update_status, etc.
      const timeline = rec.updated_timeline || rec.timeline;
      let isTenDaysAway;
      if (timeline) {
        const isTenDaysAway = this.isMoreThanTenDaysAway(timeline);
      }
      if (isTenDaysAway) {
        await this.igomRecommendationRepository.update(
          { id: rec.id },
          {
            currentStage: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
            stage: RecommendationStageEnum.MINISTRY_DIRECTOR,
            updatedAt: new Date(),
          },
        );
      } else {
        if (
          !timeline ||
          rec.latest_update_status === StatusEnum.FULLY_IMPLEMENTED
        ) {
          await this.igomRecommendationRepository.update(
            { id: rec.id },
            {
              currentStage: StageEnum.PENDING_WITH_DEA_APPROVER,
              stage: RecommendationStageEnum.DEA_APPROVER,
              updatedAt: new Date(),
            },
          );
        }
      }
    }

    for (const rec of recommendations) {
      const trail: IgomRecommendationTrail =
        this.igomRecommendationTrailRepository.create({
          igomRecommendation: rec,
          currentStatus: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          nextStatus: StageEnum.PENDING_WITH_DEA_APPROVER,
          description: `${TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER} for recommendation id: ${rec.id}`,

          userName: user.name ?? 'Unknown',
          userEmail: user.email ?? 'Unknown',
          userRole: user.role?.roleName ?? 'Unknown',

          route: 'BULK APPROVE MINISTRY APPROVER REQUEST',
          user: user,
          otherDetails: {
            data,
          },
        });
      await this.igomRecommendationTrailRepository.save(trail);
    }

    return {
      message: 'Bulk approval by ministry completed successfully',
      total: ids.length,
    };
  }

  async deaApproverReq(
    body: DeaApproverRequestDto,
    recommendationId: number,
    userId: number,
  ) {
    const { status, remarks, updatedTimeline } = body;
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role', 'ministry', 'department'],
    });
    if (!user) throw new BadRequestException('User not found');

    console.log('single rec');
    let responseMessage = '';
    let trailDescription: string;
    const recommendation: IgomRecommendation | null =
      await this.igomRecommendationRepository.findOne({
        where: { id: recommendationId },
        relations: ['igomRecommendationUpdates'],
      });
    if (!recommendation) {
      throw new BadRequestException('Recommendations for id do not exist');
    }
    console.log('recommendationId', recommendationId);
    console.log('recommendation', recommendation);
    const currentStatus = recommendation.currentStatus;
    const currentStage = recommendation.currentStage;

    let newStage = recommendation.currentStage;
    trailDescription = TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
    console.log('currentStatus', currentStatus);
    // console.log(
    //   'check',
    //   currentStatus != StatusEnum.FULLY_IMPLEMENTED &&
    //     recommendation.timeline &&
    //     new Date(recommendation.timeline) < new Date(),
    // );
    //updates present
    if (currentStatus) {
      if (currentStage === StageEnum.PENDING_WITH_DEA_APPROVER) {
        if (
          ![
            RequestStatusEnum.APPROVE,
            RequestStatusEnum.REJECT,
            RequestStatusEnum.FORWARDED,
          ].includes(status)
        ) {
          throw new BadRequestException('Request cannnot be fulfilled');
        }
        if (status === RequestStatusEnum.APPROVE) {
          if (recommendation?.hlcRefId) {
            newStage = StageEnum.ACCEPTED_BY_DEA_APPROVER_FOR_HLC_REFERENCE;
            trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
            responseMessage = 'Recommendation accepted successfully';
          } else if (!recommendation.timeline) {
            newStage = StageEnum.ACCEPTED_BY_DEA_APPROVER;
            trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
            responseMessage = 'Recommendation accepted successfully';
          } else if (
            currentStatus != StatusEnum.FULLY_IMPLEMENTED &&
            recommendation.timeline &&
            new Date(recommendation.timeline) < new Date()
          ) {
            console.log('timeline update by DEA APPROVER');

            newStage = StageEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE;
            trailDescription =
              TrailDescriptionEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE;
            responseMessage = 'Request approved successfully';
          }
          // Accept[ check needed for all rec updates]
          else {
            console.log('accepted by DEA APPROVER');
            newStage = StageEnum.ACCEPTED_BY_DEA_APPROVER;
            trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
            responseMessage = 'Recommendation accepted successfully';
          }
          recommendation.stage = RecommendationStageEnum.DEA_APPROVER;

          // foreward
        } else if (status === RequestStatusEnum.FORWARDED) {
          console.log('forewarded by DEA APPROVER');

          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription =
            TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage = 'Recommendation forwaded to ministry director';
        }
        //reject
        else {
          console.log('reject by DEA APPROVER');

          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription = TrailDescriptionEnum.MARK_NOT_COMPLETED;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage =
            'Recommendation rejected. Forwaded to ministry director';
          recommendation.hlcRefId = '';
        }
      } else if (currentStage === StageEnum.ACCEPTED_BY_DEA_APPROVER) {
        console.log('forewarded by DEA APPROVER', status);

        if (status !== RequestStatusEnum.FORWARDED) {
          throw new BadRequestException('Request cannnot be fulfilled');
        }
        newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
        recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        responseMessage = 'Recommendation forwaded to ministry director';
      } else if (
        updatedTimeline &&
        currentStage ===
          StageEnum.PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE
      ) {
        console.log('update timeline by DEA APPROVER');

        recommendation.updatedTimeline = updatedTimeline;
        newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.TIMELINE_UPDATED;
        recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        responseMessage = 'Timeline updated successfully';
      }
    }

    recommendation.currentStage = newStage;
    if (status !== RequestStatusEnum.APPROVE && remarks)
      recommendation.remark = remarks.trim();
    else recommendation.remark = '';

    await this.igomRecommendationRepository.save(recommendation);
    const trail: IgomRecommendationTrail =
      this.igomRecommendationTrailRepository.create({
        igomRecommendation: recommendation,
        currentStatus: recommendation.currentStage,
        nextStatus: newStage,

        userName: user.name ?? 'Unknown',
        userEmail: user.email ?? 'Unknown',
        userRole: user.role?.roleName ?? 'Unknown',

        route: 'DEA APPROVER REQ',
        user: user,

        description: `${trailDescription} for recommendation id: ${recommendation.id}`,

        otherDetails: {
          body,
        },
      });

    await this.igomRecommendationTrailRepository.save(trail);

    return responseMessage;
  }

  async RecEditReassign(recId: number, userId: number, dto: ReassignEditDto) {
    const { departmentId, ministryId, comment, status } = dto;

    if (status !== ReassignStatusEnum.REASSIGNEDIT) {
      throw new BadRequestException('status should be reassign edit.');
    }

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });
    if (!user) throw new NotFoundException('User not found');

    if (user.role?.roleName !== RoleEnum.DEA_APPROVER) {
      throw new ForbiddenException(
        'User not authorized to approve/reject/reassign-edit.',
      );
    }

    const existingRec = await this.igomRecommendationRepository.findOne({
      where: { id: recId },
      relations: ['department', 'ministry', 'igom'],
    });
    if (!existingRec)
      throw new NotFoundException('Recommendation entry not found');

    let department: Departments | null = null;
    let ministry: Ministry | null = null;

    if (departmentId) {
      department = await this.departmentRepository.findOne({
        where: { id: departmentId },
        relations: ['ministry'],
      });
      if (!department)
        throw new NotFoundException(`Department ${departmentId} not found`);
    }

    if (ministryId) {
      ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });
      if (!ministry)
        throw new NotFoundException(`Ministry ${ministryId} not found`);
    }

    if (
      department &&
      department.ministry &&
      ministryId &&
      department.ministry.id !== ministryId
    ) {
      throw new BadRequestException('Department does not belong to ministry');
    }

    // ✅ FIND OR REUSE TARGET
    let targetRecommendation: IgomRecommendation;

    const existing = await this.igomRecommendationRepository.findOne({
      where: {
        recommendationSlug: existingRec.recommendationSlug,
        department: department ? { id: department.id } : IsNull(),
        ministry: ministry ? { id: ministry.id } : IsNull(),
      },
    });

    if (existing) {
      if (existing.isActive) {
        throw new BadRequestException(
          `Recommendation already active for this target.`,
        );
      }

      existing.stage = RecommendationStageEnum.REASSIGN_PENDING;
      existing.currentStage = StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN;
      existing.isReassigned = true;
      existing.reassignStatus = ReassignRecommStatusEnum.PENDING;
      existing.reassignComments = null;
      existing.nitiApproved = false;

      targetRecommendation =
        await this.igomRecommendationRepository.save(existing);
    } else {
      targetRecommendation = await this.igomRecommendationRepository.save(
        this.igomRecommendationRepository.create({
          recommendationSlug: existingRec.recommendationSlug,
          igom: existingRec.igom,
          primaryDepartment: existingRec.primaryDepartment,
          primaryMinistry: existingRec.primaryMinistry,
          ministry: ministry || null,
          department: department || null,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
          stage: RecommendationStageEnum.REASSIGN_PENDING,
          isReassigned: true,
          isActive: false,
        }),
      );
    }

    const recReassign = await this.igonRecReassignRepository.findOne({
      where: {
        prevIgomRecommendation: {
          recommendationSlug: existingRec.recommendationSlug,
        },
        currentDepartment: existingRec.department ?? IsNull(),
        currentMinistry: existingRec.ministry ?? IsNull(),
      },
      relations: ['prevIgomRecommendation'],
    });

    if (!recReassign) throw new NotFoundException('Reassign entry not found');

    await this.igonRecReassignRepository.update(recReassign.id, {
      status: ReassignRecStatusEnum.REJECTREASSIGNED,
      reviewdBy: user,
      reviewedAt: new Date(),
      remarks: comment || null,
    });

    await this.igomRecommendationRepository.update(targetRecommendation.id, {
      isActive: true,
      stage: RecommendationStageEnum.MINISTRY_DIRECTOR,
      currentStage: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
      nitiApproved: true,
      reassignStatus: ReassignRecommStatusEnum.APPROVED_TO,
      reassignComments: comment,
    });

    await this.igomRecommendationRepository.update(
      recReassign.prevIgomRecommendation.id,
      {
        isActive: false,
        reassignStatus: ReassignRecommStatusEnum.APPROVED_FROM,
      },
    );

    await this.igonRecReassignRepository.save(
      this.igonRecReassignRepository.create({
        igom: existingRec.igom,
        reassignedBy: user,
        prevDepartment: existingRec.department,
        prevMinistry: existingRec.ministry,
        currentDepartment: department || null,
        currentMinistry: ministry || null,
        prevIgomRecommendation: recReassign.prevIgomRecommendation,
        status: ReassignRecStatusEnum.APPROVEDREASSIGNED,
        reason: comment,
        reviewdBy: user,
        reviewedAt: new Date(),
      }),
    );

    await this.igomRecommendationTrailRepository.save({
      igomRecommendation: recReassign.prevIgomRecommendation,
      route: 'DEA APPROVER REASSIGN-EDIT REQUEST',
      user,
      description: `Reassign-edit for ${existingRec.id}`,
    });

    return {
      message: `DEA Approver ${dto.status.toLowerCase()} successfully.`,
    };
  }

  async RecEditReassignDirector(
    recId: number,
    userId: number,
    dto: ReassignEditDto,
  ) {
    const { departmentId, ministryId, comment, status } = dto;

    if (status !== ReassignStatusEnum.REASSIGNEDIT) {
      throw new BadRequestException('status should be reassign edit.');
    }

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });

    if (!user) throw new NotFoundException('User not found');

    if (user.role?.roleName !== RoleEnum.DEA_DIRECTOR) {
      throw new ForbiddenException(
        'User not authorized to request reassign-edit.',
      );
    }

    const existingRec = await this.igomRecommendationRepository.findOne({
      where: { id: recId },
      relations: ['department', 'ministry', 'igom'],
    });

    if (!existingRec)
      throw new NotFoundException('Recommendation entry not found');

    let department: Departments | null = null;
    let ministry: Ministry | null = null;

    if (departmentId) {
      department = await this.departmentRepository.findOne({
        where: { id: departmentId },
        relations: ['ministry'],
      });
    }

    if (ministryId) {
      ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });
    }

    // ✅ FIND OR REUSE TARGET
    let targetRecommendation: IgomRecommendation;

    const existing = await this.igomRecommendationRepository.findOne({
      where: {
        recommendationSlug: existingRec.recommendationSlug,
        department: department ? { id: department.id } : IsNull(),
        ministry: ministry ? { id: ministry.id } : IsNull(),
      },
    });

    if (existing) {
      if (existing.isActive) {
        throw new BadRequestException('Already active target');
      }

      existing.stage = RecommendationStageEnum.REASSIGN_PENDING;
      existing.currentStage = StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN;
      existing.isReassigned = true;
      existing.reassignStatus = ReassignRecommStatusEnum.PENDING;
      existing.reassignComments = null;
      existing.nitiApproved = false;

      targetRecommendation =
        await this.igomRecommendationRepository.save(existing);
    } else {
      targetRecommendation = await this.igomRecommendationRepository.save(
        this.igomRecommendationRepository.create({
          recommendationSlug: existingRec.recommendationSlug,
          igom: existingRec.igom,
          ministry: ministry || null,
          department: department || null,
          stage: RecommendationStageEnum.REASSIGN_PENDING,
          currentStage: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
          isReassigned: true,
          isActive: false,
        }),
      );
    }

    // ✅ FIND EXISTING REASSIGN
    const recReassign = await this.igonRecReassignRepository.findOne({
      where: {
        prevIgomRecommendation: {
          recommendationSlug: existingRec.recommendationSlug,
        },
        currentDepartment: existingRec.department ?? IsNull(),
        currentMinistry: existingRec.ministry ?? IsNull(),
      },
      relations: ['prevIgomRecommendation'],
    });

    if (!recReassign) throw new NotFoundException('Reassign entry not found');

    // ✅ UPDATE CURRENT REC
    await this.igomRecommendationRepository.update(targetRecommendation.id, {
      stage: RecommendationStageEnum.REASSIGN_EDIT,
      currentStage: StageEnum.PENDING_WITH_DEA_APPROVER_FOR_REASSIGN,
      reassignStatus: ReassignRecommStatusEnum.PENDING,
    });

    // ✅ UPDATE OLD REASSIGN
    await this.igonRecReassignRepository.update(recReassign.id, {
      status: ReassignRecStatusEnum.REJECTED,
    });

    // ✅ NEW REASSIGN ENTRY
    await this.igonRecReassignRepository.save({
      igom: existingRec.igom,
      reassignedBy: user,
      prevDepartment: existingRec.department,
      prevMinistry: existingRec.ministry,
      currentDepartment: department || null,
      currentMinistry: ministry || null,
      prevIgomRecommendation: recReassign.prevIgomRecommendation,
      status: ReassignRecStatusEnum.PENDING,
      reason: comment,
    });

    // ✅ TRAIL
    await this.igomRecommendationTrailRepository.save({
      igomRecommendation: recReassign.prevIgomRecommendation,
      route: 'DEA DIRECTOR REASSIGN-EDIT REQUEST',
      user,
      description: `Director reassign-edit for ${existingRec.id}`,
    });

    return {
      message: `DEA Director ${dto.status.toLowerCase()} successfully.`,
    };
  }
}

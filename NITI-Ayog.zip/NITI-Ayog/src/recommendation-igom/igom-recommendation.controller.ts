import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { IgomRecommendationService } from './igom-recommendation.service';
import {
  ApproveReassignDto,
  BulkApproveDto,
  CloseRecommendationDto,
  CreateIgomRecommendationDto,
  DeaApproverRequestDto,
  ExportRecommendationDto,
  GetRecommendationQueryDto,
  MinistryApproverRequestDto,
  MinistryDirectorRequestDto,
  PresignFileDto,
  ReassignEditDto,
  ReassignRecommendationDto,
  SaveFilesDto,
} from './dto/igom-recommendation.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { FormatEnum, PermissionsEnum } from 'src/constants/enums';
@ApiTags('Igom Recommendation')
@Controller({
  path: 'igom-recommendation',
  version: '1',
})
export class IgomRecommendationController {
  constructor(
    private readonly recommendationService: IgomRecommendationService,
  ) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_RECOMMENDATION)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Create a new igom recommendation' })
  async createRecommendation(
    @Req() req,
    @Body() dto: CreateIgomRecommendationDto,
  ) {
    const userId = req?.user?.id;
    const recommendation =
      await this.recommendationService.createRecommendation(dto, userId);
    return {
      message: 'Recommendation created successfully',
      data: recommendation,
    };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get()
  @ApiOperation({ summary: 'Get list of recommendations' })
  async getRecommendations(
    @Req() req,
    @Query() query: GetRecommendationQueryDto,
  ) {
    const userId = req.user?.id;
    return this.recommendationService.findAll(query, userId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('export')
  @ApiOperation({ summary: 'Get list of recommendations' })
  async exportIgomRecommendations(
    @Req() req,
    @Body() query: ExportRecommendationDto,
    @Res() res,
  ) {
    const userId = req.user?.id;
    const buffer = await this.recommendationService.exportIgomRecommendations(
      query,
      userId,
      false,
      true,
    );
    let filename: string = '',
      contentType: string = '';
    switch (query.format) {
      case FormatEnum.CSV:
        filename = 'recommendations.csv';
        contentType = 'text/csv';
        break;

      case FormatEnum.EXCEL:
        filename = 'recommendations.xlsx';
        contentType =
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;

      case FormatEnum.PDF:
        filename = 'recommendations.pdf';
        contentType = 'application/pdf';
        break;

      case FormatEnum.PPT:
        filename = 'recommendations.pptx';
        contentType =
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        break;

      case FormatEnum.WORD:
        filename = 'recommendations.docx';
        contentType =
          'application/vnd.openxmlformats-officedocument.presentationml.presentation';
        break;

      default:
        break;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    return res.send(buffer);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('list')
  @ApiOperation({ summary: 'Get list of recommendations' })
  async getRecommendationList(
    @Req() req,
    @Query() query: GetRecommendationQueryDto,
  ) {
    if (!req.user?.viewingAccess) {
      throw new ForbiddenException('You are not allowed to access this.');
    }
    const userId = req.user?.id;
    return this.recommendationService.findAll(query, userId, false, false);
  }

  /*   @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('list/export')
  @ApiOperation({ summary: 'Export recommendations (Excel, CSV, PDF)' })
  async exportRecommendationList(
    @Req() req,
    @Body() query: ExportRecommendationDto,
    @Res() res,
  ) {
    if (!req.user?.viewingAccess) {
      throw new ForbiddenException('You are not allowed to access this.');
    }
    const userId = req.user?.id;
    const buffer = await this.recommendationService.export(query, userId, true);

    let filename: string = '',
      contentType: string = '';
    switch (query.format) {
      case 'csv':
        filename = 'recommendations.csv';
        contentType = 'text/csv';
        break;

      case 'excel':
        filename = 'recommendations.xlsx';
        contentType =
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;

      case 'pdf':
        filename = 'recommendations.pdf';
        contentType = 'application/pdf';
        break;

      default:
        break;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    return res.send(buffer);
  }
 */

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_RECOMMENDATION)
  @ApiBearerAuth()
  @Put(':name')
  @ApiOperation({ summary: 'Update an existing recommendation' })
  @ApiParam({ name: 'name', type: String, description: 'Recommendation Slug' })
  async updateRecommendation(
    @Req() req,
    @Param('name') name: string,
    @Body() dto: CreateIgomRecommendationDto,
  ) {
    const userId = req?.user?.id;
    await this.recommendationService.updateRecommendation(name, dto, userId);
    return { message: 'Recommendation updated successfully' };
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DEA_APPROVER_REQUEST)
  @ApiBearerAuth()
  @Put('dea-approver-request/:name')
  @ApiParam({ name: 'name', type: String, description: 'Recommendation Slug' })
  @ApiOperation({
    summary: 'Approve or reject a recommendation by DEA Approver',
  })
  async deaApproverRequest(
    @Req() req,
    @Param('name') name: string,
    @Body() body: DeaApproverRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.deaApproverRequest(
      body,
      name, // Pass name instead of id
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.DEA_DIRECTOR_REQUEST)
  @Put('dea-director-reassign/:id')
  @ApiParam({ name: 'id', type: Number, description: 'Recommendation id' })
  @ApiOperation({
    summary: 'Reassign a recommendation by DEA Director',
  })
  async directorReassign(
    @Req() req,
    @Param('id') id: number,
    @Body() body: ReassignRecommendationDto,
  ) {
    const userId = req.user?.id;
    await this.recommendationService.directorReassign(
      body,
      id, // Pass name instead of id
      userId,
    );
    return { message: 'Recommendation updated successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.MINISTRY_DIRECTOR_REQUEST)
  @Put('dea-ministry-director-request/:id')
  @ApiOperation({
    summary: 'Submit Ministry Director’s response for a igom recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async ministryDirectorRequest(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: MinistryDirectorRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.ministryDirectorRequest(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.MINISTRY_APPROVER_REQUEST)
  @Put('dea-ministry-approver-request/:id')
  @ApiOperation({
    summary:
      'Submit Ministry Approver’s review/decision on a igom recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async ministryApproverRequest(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: MinistryApproverRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.ministryApproverRequest(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.DEA_APPROVER_REQUEST)
  @Put('dea-approver-reassign/:id/decision')
  @ApiParam({ name: 'id', type: Number, description: 'Rec reassign id' })
  @ApiOperation({ summary: 'Approve or reject a rec reassign by DEA Approver' })
  async approveOrRejectRecReassign(
    @Req() req,
    @Param('id') id: number,
    @Body() approveReassignDto: ApproveReassignDto,
  ) {
    const userId = req.user?.id;
    return await this.recommendationService.approveOrRejectRecReassign(
      id,
      userId,
      approveReassignDto,
    );
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.DEA_APPROVER_REQUEST)
  @Put('close-recommendation/:id')
  @ApiOperation({
    summary: 'Submit Ministry Approver’s review/decision on a recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async closeRecommendation(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() bodyData: CloseRecommendationDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.closeRecommendation(
      id,
      bodyData,
      userId,
    );
    return message;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('dea-bulk-approve/approver')
  async bulkApproveDea(@Req() req, @Body() body: BulkApproveDto) {
    const userId = req?.user?.id;
    return await this.recommendationService.bulkApproveDea(body, userId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('dea-bulk-approve/ministry')
  async bulkApproveMinistry(@Req() req, @Body() body: BulkApproveDto) {
    const userId = req?.user?.id;
    return await this.recommendationService.bulkApproveMinistry(body, userId);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DEA_APPROVER_REQUEST)
  @ApiBearerAuth()
  @Put('dea-approver-req/:id')
  @ApiParam({ name: 'id', type: Number, description: 'Recommendation Id' })
  @ApiOperation({
    summary: 'Approve or reject a recommendation by DEA Approver',
  })
  async deaApproverReq(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: DeaApproverRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.deaApproverReq(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.DEA_APPROVER_REQUEST)
  @Put('dea-approver-reassign-edit/:id')
  @ApiParam({ name: 'id', type: Number, description: 'Rec reassign id' })
  @ApiOperation({ summary: 'Approve or reject a rec reassign by DEA Approver' })
  async RecEditReassign(
    @Req() req,
    @Param('id') id: number,
    @Body() reassignEditDto: ReassignEditDto,
  ) {
    const userId = req.user?.id;
    return await this.recommendationService.RecEditReassign(
      id,
      userId,
      reassignEditDto,
    );
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.DEA_DIRECTOR_REQUEST)
  @Put('dea-director-reassign-edit/:id')
  @ApiParam({ name: 'id', type: Number, description: 'Rec reassign id' })
  @ApiOperation({ summary: 'Approve or reject a rec reassign by DEA Approver' })
  async RecEditReassignDirector(
    @Req() req,
    @Param('id') id: number,
    @Body() reassignEditDto: ReassignEditDto,
  ) {
    const userId = req.user?.id;
    return await this.recommendationService.RecEditReassignDirector(
      id,
      userId,
      reassignEditDto,
    );
  }
}

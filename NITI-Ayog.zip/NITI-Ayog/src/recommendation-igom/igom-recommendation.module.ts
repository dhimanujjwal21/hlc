import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Ministry } from 'src/entities/ministry.entity';
import { JwtService } from '@nestjs/jwt';
import { Recommendation } from 'src/entities/recommendation.entity';
import { IgomRecommendationController } from './igom-recommendation.controller';
import { IgomRecommendationService } from './igom-recommendation.service';
import { Departments } from 'src/entities/departments.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import { AuditLogs } from 'src/entities/audit.entity';
import { RecommendationFile } from 'src/entities/recommendation-file.entity';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';
import { IgomRecommendation } from 'src/entities/igom-recommendation.entity';
import { IgomRecommendationUpdates } from 'src/entities/igom-recommendation-updates.entity';
import { Igom } from 'src/entities/igom.entity';
import { IgomRecReassign } from 'src/entities/igom-rec-reassign.entity';
import { IgomRecommendationTrail } from 'src/entities/igom-recommendation-trail.entity';
import { IgomRecommendationDraftDto } from 'src/recommendationDraftIgom/dto/igom-recommendation-draft.dto';
import { IgomRecommendationDraft } from 'src/entities/igom-recommendation-draft.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      User,
      IgomRecommendation,
      Departments,
      Ministry,
      Igom,
      RecommendationTrail,
      IgomRecommendationTrail,
      IgomRecommendationDraft,
      AuditLogs,
      RecommendationFile,
      IgomRecommendationUpdates,
      IgomRecReassign,
      RecommendationUpdates,
    ]),
  ],
  controllers: [IgomRecommendationController],
  providers: [IgomRecommendationService, JwtService],
  exports: [],
})
export class IgomRecommendationModule {}

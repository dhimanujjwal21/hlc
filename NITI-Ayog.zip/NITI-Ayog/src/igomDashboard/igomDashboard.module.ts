import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from "src/entities/users.entity";
import { Hlc } from "src/entities/hlc.entity";
import { Ministry } from "src/entities/ministry.entity";
import { Departments } from "src/entities/departments.entity";
import { JwtService } from "@nestjs/jwt";
import { IgomRecommendation } from "src/entities/igom-recommendation.entity";
import { IgomDashboardV2Controller } from "./igomDashboard.controller";
import { IgomDashboardService } from "./igomDashboard.service";

@Module({
    imports: [
        TypeOrmModule.forFeature([User, IgomRecommendation, Hlc, Ministry, Departments])
    ],
    controllers: [IgomDashboardV2Controller],
    providers: [JwtService, IgomDashboardService],
    exports: [],
})
export class IgomDashboardModule { }
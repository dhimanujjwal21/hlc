import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { AllStatusEnum, FormatEnum, ImplementationStatusEnum } from "src/constants/enums";
import { Departments } from "src/entities/departments.entity";
import { Hlc } from "src/entities/hlc.entity";
import { IgomRecommendation } from "src/entities/igom-recommendation.entity";
import { Ministry } from "src/entities/ministry.entity";
import { Repository } from "typeorm";
import { IgomGetRecommendationSummaryDto, IgomGetReportStatusSummaryDto, IgomMinistryWiseReportDto, IgomSummaryDto } from "./dto/dashboard.dto";
import * as XLSX from 'xlsx';
import { Parser } from 'json2csv';
import PptxGenJS from 'pptxgenjs';
import {
    Document,
    Packer,
    PageOrientation,
    Paragraph,
    Table,
    TableCell,
    TableRow,
    WidthType,
} from 'docx';
var PdfPrinter = require('pdfmake');

@Injectable()
export class IgomDashboardService {
  constructor(
    @InjectRepository(IgomRecommendation)
    private readonly igomRecommendationRepository: Repository<IgomRecommendation>,
  ) {}

  async getSummaryV2(query: IgomSummaryDto) {
    const { igomId, ministryId, departmentId, reportNumbers } = query;

    /**
     * Apply common filters to the summary query.
     */
    const applyBaseFilters = (qb: any) => {
      if (igomId) {
        qb.andWhere('r.igom_id = :igomId', { igomId });
      }

      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', {
          ministryId,
        });
      }

      if (departmentId) {
        qb.andWhere('r.department_id = :departmentId', {
          departmentId,
        });
      }

      if (reportNumbers?.length) {
        qb.andWhere('r.reportNumber IN (:...reportNumbers)', { reportNumbers });
      }
    };

    const qb = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .select('COUNT(DISTINCT r.recommendation_slug)', 'unique')
      .addSelect('COUNT(r.id)', 'total')
      .addSelect(
        `COUNT(
         CASE
          WHEN r.current_status = :fullyImplemented
          THEN r.recommendation_slug
        END
      )`,
        'fullyImplemented',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN r.current_status IN (
            :inProgress,
            :partiallyImplemented
          )
          THEN r.recommendation_slug
        END
      )`,
        'inProgressTotal',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN r.current_status IN (
            :inProgress,
            :partiallyImplemented
          )
          AND COALESCE(
            r.updated_timeline,
            r.timeline
          ) IS NOT NULL
          AND DATE(
            COALESCE(
              r.updated_timeline,
              r.timeline
            )
            AT TIME ZONE 'UTC'
            AT TIME ZONE 'Asia/Kolkata'
          ) >= CURRENT_DATE
          THEN r.recommendation_slug
        END
      )`,
        'inProgressOnTrack',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN r.current_status IN (
            :inProgress,
            :partiallyImplemented
          )
          AND COALESCE(
            r.updated_timeline,
            r.timeline
          ) IS NOT NULL
          AND DATE(
            COALESCE(
              r.updated_timeline,
              r.timeline
            )
            AT TIME ZONE 'UTC'
            AT TIME ZONE 'Asia/Kolkata'
          ) < CURRENT_DATE
          THEN r.recommendation_slug
        END
      )`,
        'inProgressOverdue',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN (
            r.current_status = :yetToInitiate
            OR r.current_status IS NULL
          )
          THEN r.recommendation_slug
        END
      )`,
        'yetToInitiateTotal',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN (
            r.current_status = :yetToInitiate
            OR r.current_status IS NULL
          )
          AND COALESCE(
            r.updated_timeline,
            r.timeline
          ) IS NOT NULL
          AND DATE(
            COALESCE(
              r.updated_timeline,
              r.timeline
            )
            AT TIME ZONE 'UTC'
            AT TIME ZONE 'Asia/Kolkata'
          ) >= CURRENT_DATE
          THEN r.recommendation_slug
        END
      )`,
        'yetToInitiateOnTrack',
      )
      .addSelect(
        `COUNT(
         CASE
          WHEN (
            r.current_status = :yetToInitiate
            OR r.current_status IS NULL
          )
          AND COALESCE(
            r.updated_timeline,
            r.timeline
          ) IS NOT NULL
          AND DATE(
            COALESCE(
              r.updated_timeline,
              r.timeline
            )
            AT TIME ZONE 'UTC'
            AT TIME ZONE 'Asia/Kolkata'
          ) < CURRENT_DATE
          THEN r.recommendation_slug
        END
      )`,
        'yetToInitiateOverdue',
      )
      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,

        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,

        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED,

        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
      });
    applyBaseFilters(qb);

    const raw = await qb.getRawOne();

    const unique = Number(raw?.unique) || 0;
    const total = Number(raw?.total) || 0;

    const fullyImplemented = Number(raw?.fullyImplemented) || 0;

    const inProgressTotal = Number(raw?.inProgressTotal) || 0;

    const inProgressOnTrack = Number(raw?.inProgressOnTrack) || 0;

    const inProgressOverdue = Number(raw?.inProgressOverdue) || 0;

    const yetToInitiateTotal = Number(raw?.yetToInitiateTotal) || 0;

    const yetToInitiateOnTrack = Number(raw?.yetToInitiateOnTrack) || 0;

    const yetToInitiateOverdue = Number(raw?.yetToInitiateOverdue) || 0;

    const calculatePercentage = (value: number) => {
      return total ? Math.round((value / total) * 100) : 0;
    };

    return {
      unique,

      total,

      fullyImplemented: {
        count: fullyImplemented,
        percentage: calculatePercentage(fullyImplemented),
      },

      inProgress: {
        total: inProgressTotal,
        onTrack: inProgressOnTrack,
        overdue: inProgressOverdue,
        percentage: calculatePercentage(inProgressTotal),
      },

      yetToInitiate: {
        total: yetToInitiateTotal,
        onTrack: yetToInitiateOnTrack,
        overdue: yetToInitiateOverdue,
        percentage: calculatePercentage(yetToInitiateTotal),
      },
    };
  }

  async getReportStatusSummary(dto: IgomGetReportStatusSummaryDto) {
    const { reportNumbers, igomId } = dto;

    const qb = this.igomRecommendationRepository
      .createQueryBuilder('r')

      .select('r.reportNumber', 'reportNumber')
      .addSelect('COUNT(r.id)', 'total')
      .addSelect(
        `SUM(CASE 
          WHEN r.current_status = :fullyImplemented 
          THEN 1 ELSE 0 
      END)`,
        'fullyImplemented',
      )
      .addSelect(
        `SUM(CASE 
          WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) 
          THEN 1 ELSE 0 
      END)`,
        'yetToInitiateTotal',
      )
      .addSelect(
        `SUM(CASE 
          WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL)
            AND DATE(
                  COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                ) >= CURRENT_DATE
          THEN 1 ELSE 0 
      END)`,
        'yetToInitiateOnTrack',
      )
      .addSelect(
        `SUM(CASE 
          WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL)
            AND DATE(
                  COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                ) < CURRENT_DATE
          THEN 1 ELSE 0 
      END)`,
        'yetToInitiateOverdue',
      )
      .addSelect(
        `SUM(CASE 
          WHEN r.current_status IN (:inProgress, :partiallyImplemented)
          THEN 1 ELSE 0 
      END)`,
        'inProgressTotal',
      )
      .addSelect(
        `SUM(CASE 
          WHEN r.current_status IN (:inProgress, :partiallyImplemented)
            AND DATE(
                  COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                ) >= CURRENT_DATE
          THEN 1 ELSE 0 
      END)`,
        'inProgressOnTrack',
      )
      .addSelect(
        `SUM(CASE 
          WHEN r.current_status IN (:inProgress, :partiallyImplemented)
            AND DATE(
                  COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                ) < CURRENT_DATE
          THEN 1 ELSE 0 
      END)`,
        'inProgressOverdue',
      )
      .where('r.reportNumber IS NOT NULL')
      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,
        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,
        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED,
      });

    qb.andWhere('COALESCE(r.updated_timeline, r.timeline) IS NOT NULL');

    if (igomId) {
      qb.andWhere('r.igom_id = :igomId', { igomId });
    }

    if (reportNumbers?.length) {
      qb.andWhere('r.reportNumber IN (:...reportNumbers)', { reportNumbers });
    } else {
      qb.andWhere('1=0');
    }

    qb.groupBy('r.reportNumber');

    const raw = await qb.getRawMany();

    return raw.map((row) => {
      const total = Number(row.total) || 0;

      const calculatePercentage = (value: number) =>
        total ? Math.round((value / total) * 100) : 0;

      return {
        reportNumber: row.reportNumber,
        total,

        fullyImplemented: {
          count: Number(row.fullyImplemented),
          percentage: calculatePercentage(Number(row.fullyImplemented)),
        },

        inProgress: {
          total: Number(row.inProgressTotal),
          onTrack: Number(row.inProgressOnTrack),
          overdue: Number(row.inProgressOverdue),
          percentage: calculatePercentage(Number(row.inProgressTotal)),
        },

        yetToInitiate: {
          total: Number(row.yetToInitiateTotal),
          onTrack: Number(row.yetToInitiateOnTrack),
          overdue: Number(row.yetToInitiateOverdue),
          percentage: calculatePercentage(Number(row.yetToInitiateTotal)),
        },
      };
    });
  }

  async ministryWiseProgress(dto: IgomMinistryWiseReportDto) {
    const { igomId } = dto;

    const qb = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.department', 'd')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('COUNT(r.id)', 'total')
      .addSelect(
        `SUM(CASE WHEN r.current_status = :fullyImplemented THEN 1 ELSE 0 END)`,
        'fullyImplemented',
      )
      .addSelect(
        `SUM(CASE 
        WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) 
        THEN 1 ELSE 0 END)`,
        'yetToInitiateTotal',
      )
      .addSelect(
        `SUM(CASE 
        WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL)
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline) 
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
        THEN 1 ELSE 0 END)`,
        'yetToInitiateOnTrack',
      )
      .addSelect(
        `SUM(CASE 
        WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL)
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline) 
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
        THEN 1 ELSE 0 END)`,
        'yetToInitiateOverdue',
      )
      .addSelect(
        `SUM(CASE 
        WHEN r.current_status IN (:inProgress, :partiallyImplemented) 
        THEN 1 ELSE 0 END)`,
        'inProgressTotal',
      )
      .addSelect(
        `SUM(CASE 
        WHEN r.current_status IN (:inProgress, :partiallyImplemented)
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline) 
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
        THEN 1 ELSE 0 END)`,
        'inProgressOnTrack',
      )
      .addSelect(
        `SUM(CASE 
        WHEN r.current_status IN (:inProgress, :partiallyImplemented)
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline) 
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
        THEN 1 ELSE 0 END)`,
        'inProgressOverdue',
      )
      .groupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('d.id')
      .addGroupBy('d.name')

      .orderBy('COUNT(r.id)', 'DESC')

      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,
        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,
        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED,
      });
    qb.andWhere('COALESCE(r.updated_timeline, r.timeline) IS NOT NULL');

    if (igomId) {
      qb.andWhere('r.igom_id = :igomId', { igomId });
    }

    const raw = await qb.getRawMany();

    return raw.map((row) => {
      const total = Number(row.total) || 0;

      const calculatePercentage = (value: number) =>
        total ? Math.round((value / total) * 100) : 0;

      return {
        ministryId: row.ministryId,
        ministryName: row.ministryName,
        departmentId: row.departmentId || null,
        departmentName: row.departmentName || null,

        level: row.departmentId ? 'DEPARTMENT' : 'MINISTRY',

        total,

        fullyImplemented: {
          count: Number(row.fullyImplemented) || 0,
          percentage: calculatePercentage(Number(row.fullyImplemented) || 0),
        },

        inProgress: {
          total: Number(row.inProgressTotal) || 0,
          onTrack: Number(row.inProgressOnTrack) || 0,
          overdue: Number(row.inProgressOverdue) || 0,
          percentage: calculatePercentage(Number(row.inProgressTotal) || 0),
        },

        yetToInitiate: {
          total: Number(row.yetToInitiateTotal) || 0,
          onTrack: Number(row.yetToInitiateOnTrack) || 0,
          overdue: Number(row.yetToInitiateOverdue) || 0,
          percentage: calculatePercentage(Number(row.yetToInitiateTotal) || 0),
        },
      };
    });
  }

  // async getRecommendationSummary(dto: IgomGetRecommendationSummaryDto, noPagination = false) {
  //     const {
  //         igomId,
  //         ministryId,
  //         departmentId,
  //         reportNumbers,
  //         status,
  //         detail = false,
  //         recommendations,
  //         page = 1,
  //         limit = 10
  //     } = dto;
  //     const baseQuery = this.igomRecommendationRepository
  //         .createQueryBuilder('r')
  //         .where('r.igom_id = :igomId', { igomId });

  //     if (ministryId) {
  //         baseQuery.andWhere('r.ministry_id = :ministryId', { ministryId });
  //     }
  //     if (departmentId) {
  //         baseQuery.andWhere('r.department_id = :departmentId', { departmentId });
  //     }
  //     if (reportNumbers?.length) {
  //         baseQuery.andWhere('r.report_number IN (:...reportNumbers)', { reportNumbers, });
  //     }

  //     if (recommendations?.length) {
  //         baseQuery.andWhere('r.id IN (:...recs)', { recs: recommendations });
  //     }
  //     if (status) {
  //         baseQuery.andWhere(`
  //     CASE
  //       WHEN r.current_status = :fully THEN 'Fully Implemented'
  //       WHEN (r.current_status = :under OR r.current_status = :partial) AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Partially Implemented / Under Progress: Overdue'
  //       WHEN (r.current_status = :under OR r.current_status = :partial) THEN 'Partially Implemented / Under Progress: On Track'
  //       WHEN (r.current_status = :yet OR r.current_status IS NULL) AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Yet to Initiate: Overdue'
  //       WHEN (r.current_status = :yet OR r.current_status IS NULL) THEN 'Yet to Initiate: Not Due' END = :status
  //     `,
  //             {
  //                 status,
  //                 fully: AllStatusEnum.FULLY_IMPLEMENTED,
  //                 under: AllStatusEnum.UNDER_IMPLEMENTATION,
  //                 partial: AllStatusEnum.PARTIALLY_IMPLEMENTED,
  //                 yet: AllStatusEnum.YET_TO_INITIATE
  //             });
  //     }

  //     const total = await baseQuery.getCount();
  //     let ids: number[] = [];
  //     if (!noPagination) {
  //         const paginatedIds = await baseQuery.clone()
  //             .select('r.id', 'id')
  //             .orderBy('r.id', 'DESC')
  //             .skip((page - 1) * limit)
  //             .take(limit)
  //             .getRawMany();
  //         ids = paginatedIds.map((r) => r.id);
  //     } else {
  //         const allIds = await baseQuery.clone().select('r.id', 'id').getRawMany();
  //         ids = allIds.map((r) => r.id);
  //     }

  //     if (!ids.length) {
  //         return noPagination ? [] : { total, page, limit, result: [] }
  //     }

  //     const query = this.igomRecommendationRepository
  //         .createQueryBuilder('r')
  //         .leftJoin('r.igomRecommendationUpdates', 'updates')
  //         .leftJoin('r.department', 'department')
  //         .leftJoin('r.ministry', 'ministry')
  //         .leftJoin(
  //             'r.primaryDepartment',
  //             'primaryDepartment',
  //         )
  //         .leftJoin('r.primaryMinistry', 'primaryMinistry')
  //         .where('r.id IN (:...ids)', { ids })
  //         .select([
  //             'r.id AS id',
  //             'r.description AS description',
  //             'r.name AS name',
  //             'r.recommendation_slug AS slug',
  //             'r.current_status AS rawstatus',
  //             `CASE
  //       WHEN r.current_status = '${AllStatusEnum.FULLY_IMPLEMENTED}' THEN 'Fully Implemented'
  //       WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Partially Implemented / Under Progress: Overdue'
  //       WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') THEN 'Partially Implemented / Under Progress: On Track'
  //       WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' OR r.current_status IS NULL) AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Yet to Initiate: Overdue'
  //       WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' OR r.current_status IS NULL) THEN 'Yet to Initiate: Not Due'
  //     END
  //       AS currentstatus
  //     `,
  //             'updates.id AS updaterecommendationid',
  //             'updates.status AS updatestatus',
  //             'updates.created_at AS updatecreatedat',
  //             'updates.action_taken_by_ministry AS updateactiontakenbyministry',
  //             'updates.reason_not_implemented AS updatereasonnotimplemented',
  //             'ministry.name AS ministry',
  //             'department.name as department',
  //             'primaryMinistry.name AS primaryministry',
  //             'primaryDepartment.name as primarydepartment'
  //         ])
  //         .where('updates.ministry_approver_status = :status', { status: ImplementationStatusEnum.APPROVED })
  //         .orderBy('updates.created_at', 'DESC');
  //     const raw = await query.getRawMany();
  //     const grouped: any = {};
  //     raw.forEach((row: any) => {
  //         if (!grouped[row.id]) {
  //             grouped[row.id] = {
  //                 id: row.id,
  //                 recommendationSlug: row.slug,
  //                 name: row.name,
  //                 description: row.description,
  //                 status: row.currentstatus,
  //                 currentStatus: row.rawstatus,
  //                 primaryMinistry: { name: row.primaryministry },
  //                 primaryDepartment: { name: row.primarydepartment },
  //                 ministry: { name: row.ministry },
  //                 department: { name: row.department },
  //                 updates: []
  //             }
  //         }

  //         if (row.updaterecommendationid) {
  //             grouped[row.id].updates.push({
  //                 updateId: row.updaterecommendationid,
  //                 status: row.updatestatus,
  //                 createdAt: row.updatecreatedat,
  //                 actionTakenByMinistry: row.updateactiontakenbyministry,
  //                 reasonNotImplemented: row.updatereasonnotimplemented
  //             });
  //         }
  //     });
  //     const result = Object.values(grouped);
  //     return noPagination
  //         ? result
  //         : {
  //             total,
  //             page,
  //             limit,
  //             result
  //         };
  // }

  async getRecommendationSummary(
    dto: IgomGetRecommendationSummaryDto,
    noPagination = false,
  ) {
    const {
      igomId,
      ministryId,
      departmentId,
      reportNumbers,
      status,
      detail = false,
      recommendations,
      page = 1,
      limit = 10,
    } = dto;

    const baseQuery = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .where('r.igom_id = :igomId', { igomId });

    if (ministryId) {
      baseQuery.andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    if (departmentId) {
      baseQuery.andWhere('r.department_id = :departmentId', { departmentId });
    }

    if (reportNumbers?.length) {
      baseQuery.andWhere('r.report_number IN (:...reportNumbers)', {
        reportNumbers,
      });
    }

    if (recommendations?.length) {
      baseQuery.andWhere('r.id IN (:...recs)', { recs: recommendations });
    }

    //    baseQuery.andWhere('COALESCE(r.updated_timeline, r.timeline) IS NOT NULL');

    if (status) {
      baseQuery.andWhere(
        `CASE
      WHEN r.current_status = :fully
        THEN 'Fully Implemented'

      WHEN (
              r.current_status = :under
              OR r.current_status = :partial
           )
           AND DATE(
                COALESCE(r.updated_timeline, r.timeline)
                AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
           ) < CURRENT_DATE
        THEN 'Partially Implemented / Under Progress: Overdue'

      WHEN (
              r.current_status = :under
              OR r.current_status = :partial
           )
           AND (
                COALESCE(r.updated_timeline, r.timeline) IS NULL
                OR DATE(
                      COALESCE(r.updated_timeline, r.timeline)
                      AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                   ) >= CURRENT_DATE
           )
        THEN 'Partially Implemented / Under Progress: On Track'

      WHEN (
              r.current_status = :yet
              OR r.current_status IS NULL
           )
           AND DATE(
                COALESCE(r.updated_timeline, r.timeline)
                AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
           ) < CURRENT_DATE
        THEN 'Yet to Initiate: Overdue'

      WHEN (
              r.current_status = :yet
              OR r.current_status IS NULL
           )
           AND (
                COALESCE(r.updated_timeline, r.timeline) IS NULL
                OR DATE(
                      COALESCE(r.updated_timeline, r.timeline)
                      AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
                   ) >= CURRENT_DATE
           )
        THEN 'Yet to Initiate: Not Due'
    END = :status`,
        {
          status,
          fully: AllStatusEnum.FULLY_IMPLEMENTED,
          under: AllStatusEnum.UNDER_IMPLEMENTATION,
          partial: AllStatusEnum.PARTIALLY_IMPLEMENTED,
          yet: AllStatusEnum.YET_TO_INITIATE,
        },
      );
    }

    const total = await baseQuery.getCount();

    let ids: number[] = [];

    if (!noPagination) {
      const paginatedIds = await baseQuery
        .clone()
        .select('r.id', 'id')
        .orderBy('r.id', 'DESC')
        .skip((page - 1) * limit)
        .take(limit)
        .getRawMany();

      ids = paginatedIds.map((r) => r.id);
    } else {
      const allIds = await baseQuery.clone().select('r.id', 'id').getRawMany();

      ids = allIds.map((r) => r.id);
    }

    if (!ids.length) {
      return noPagination ? [] : { total, page, limit, result: [] };
    }

    const query = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .leftJoin(
        'r.igomRecommendationUpdates',
        'updates',
        'updates.ministry_approver_status = :approvedStatus',
        { approvedStatus: ImplementationStatusEnum.APPROVED },
      )
      .leftJoin('r.department', 'department')
      .leftJoin('r.ministry', 'ministry')
      .leftJoin('r.primaryMinistry', 'primaryMinistry')
      .leftJoin('r.primaryDepartment', 'primaryDepartment')

      .select([
        'r.id AS id',
        'r.description AS description',
        'r.name AS name',
        'r.recommendation_slug AS slug',
        'r.current_status AS rawstatus',
        `CASE
          WHEN r.current_status = '${AllStatusEnum.FULLY_IMPLEMENTED}' 
              THEN 'Fully Implemented'

          WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' 
                OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') 
              AND DATE(COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE
              THEN 'Partially Implemented / Under Progress: Overdue'

          WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' 
                OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') 
              AND DATE(COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE
              THEN 'Partially Implemented / Under Progress: On Track'

          WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' 
                OR r.current_status IS NULL) 
              AND DATE(COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE
              THEN 'Yet to Initiate: Overdue'

          WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' 
                OR r.current_status IS NULL) 
              AND DATE(COALESCE(r.updated_timeline, r.timeline) 
                  AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE
              THEN 'Yet to Initiate: Not Due'
      END AS currentstatus`,

        'updates.id AS updaterecommendationid',
        'updates.status AS updatestatus',
        'updates.created_at AS updatecreatedat',
        'updates.action_taken_by_ministry AS updateactiontakenbyministry',
        'updates.reason_not_implemented AS updatereasonnotimplemented',

        'ministry.name AS ministry',
        'department.name AS department',
        'primaryMinistry.name AS primaryministry',
        'primaryDepartment.name AS primarydepartment',
      ])

      .where('r.id IN (:...ids)', { ids })
      .orderBy('updates.created_at', 'DESC');

    const raw = await query.getRawMany();

    const grouped: any = {};

    ids.forEach((id) => {
      grouped[id] = null;
    });

    raw.forEach((row: any) => {
      if (!grouped[row.id]) {
        grouped[row.id] = {
          id: row.id,
          recommendationSlug: row.slug,
          name: row.name,
          description: row.description,
          status: row.currentstatus,
          currentStatus: row.rawstatus,

          primaryMinistry: { name: row.primaryministry },
          primaryDepartment: { name: row.primarydepartment },

          ministry: { name: row.ministry },
          department: { name: row.department },

          updates: [],
        };
      }

      if (row.updaterecommendationid) {
        grouped[row.id].updates.push({
          updateId: row.updaterecommendationid,
          status: row.updatestatus,
          createdAt: row.updatecreatedat,
          actionTakenByMinistry: row.updateactiontakenbyministry,
          reasonNotImplemented: row.updatereasonnotimplemented,
        });
      }
    });

    const result = Object.values(grouped).filter(Boolean);

    return noPagination ? result : { total, page, limit, result };
  }

  async getIgomAndHlcRecommendationSummary(
    dto: IgomGetRecommendationSummaryDto,
    noPagination = false,
  ) {
    const {
      igomId,
      ministryId,
      departmentId,
      reportNumbers,
      status,
      recommendations,
      page = 1,
      limit = 10,
    } = dto;

    const baseQuery = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .where('r.igom_id = :igomId', { igomId });

    if (ministryId) {
      baseQuery.andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    if (departmentId) {
      baseQuery.andWhere('r.department_id = :departmentId', { departmentId });
    }

    if (reportNumbers?.length) {
      baseQuery.andWhere('r.report_number IN (:...reportNumbers)', {
        reportNumbers,
      });
    }

    if (recommendations?.length) {
      baseQuery.andWhere('r.id IN (:...recs)', { recs: recommendations });
    }

    if (status) {
      baseQuery.andWhere(
        `CASE
        WHEN r.current_status = :fully
          THEN 'Fully Implemented'

        WHEN COALESCE(r.updated_timeline, r.timeline) IS NULL
          THEN 'Timeline Not Available'

        WHEN (
          r.current_status = :under
          OR r.current_status = :partial
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
          THEN 'Partially Implemented / Under Progress: Overdue'

        WHEN (
          r.current_status = :under
          OR r.current_status = :partial
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
          THEN 'Partially Implemented / Under Progress: On Track'

        WHEN (
          r.current_status = :yet
          OR r.current_status IS NULL
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
          THEN 'Yet to Initiate: Overdue'

        WHEN (
          r.current_status = :yet
          OR r.current_status IS NULL
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
          THEN 'Yet to Initiate: Not Due'
      END = :status`,
        {
          status,
          fully: AllStatusEnum.FULLY_IMPLEMENTED,
          under: AllStatusEnum.UNDER_IMPLEMENTATION,
          partial: AllStatusEnum.PARTIALLY_IMPLEMENTED,
          yet: AllStatusEnum.YET_TO_INITIATE,
        },
      );
    }

    const total = await baseQuery.getCount();

    let ids: number[] = [];

    if (!noPagination) {
      const paginatedIds = await baseQuery
        .clone()
        .select('r.id', 'id')
        .orderBy('r.id', 'DESC')
        .skip((page - 1) * limit)
        .take(limit)
        .getRawMany();

      ids = paginatedIds.map((r) => r.id);
    } else {
      const allIds = await baseQuery.clone().select('r.id', 'id').getRawMany();

      ids = allIds.map((r) => r.id);
    }

    if (!ids.length) {
      return noPagination ? [] : { total, page, limit, result: [] };
    }

    const query = this.igomRecommendationRepository
      .createQueryBuilder('r')
      .leftJoin(
        'r.igomRecommendationUpdates',
        'updates',
        'updates.ministry_approver_status = :igomApprovedStatus',
        {
          igomApprovedStatus: ImplementationStatusEnum.APPROVED,
        },
      )
      .leftJoin('r.department', 'department')
      .leftJoin('r.ministry', 'ministry')
      .leftJoin('r.primaryDepartment', 'primaryDepartment')
      .leftJoin('r.primaryMinistry', 'primaryMinistry')
      .leftJoin(
        't_recommendation',
        'rec',
        'rec.recommendation_slug = r.hlc_ref_id',
      )
      .leftJoin(
        't_recommendation_updates',
        'hlcupdates',
        `hlcupdates.recommendation_id = rec.id
       AND hlcupdates.ministry_approver_status = :hlcApprovedStatus`,
        {
          hlcApprovedStatus: ImplementationStatusEnum.APPROVED,
        },
      )
      .where('r.id IN (:...ids)', { ids })

      .select([
        'r.id AS id',
        'r.description AS description',
        'r.name AS name',
        'r.recommendation_slug AS slug',
        'r.current_status AS rawstatus',
        'r.hlc_ref_id AS hlcrefid',

        `CASE
        WHEN r.current_status = '${AllStatusEnum.FULLY_IMPLEMENTED}'
          THEN 'Fully Implemented'

        WHEN COALESCE(r.updated_timeline, r.timeline) IS NULL
          THEN 'Timeline Not Available'

        WHEN (
          r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}'
          OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}'
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
          THEN 'Partially Implemented / Under Progress: Overdue'

        WHEN (
          r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}'
          OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}'
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
          THEN 'Partially Implemented / Under Progress: On Track'

        WHEN (
          r.current_status = '${AllStatusEnum.YET_TO_INITIATE}'
          OR r.current_status IS NULL
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata'
        ) < CURRENT_DATE
          THEN 'Yet to Initiate: Overdue'

        WHEN (
          r.current_status = '${AllStatusEnum.YET_TO_INITIATE}'
          OR r.current_status IS NULL
        )
        AND DATE(
          COALESCE(r.updated_timeline, r.timeline)
          AT TIME ZONE 'UTC'
          AT TIME ZONE 'Asia/Kolkata'
        ) >= CURRENT_DATE
          THEN 'Yet to Initiate: Not Due'
      END AS currentstatus`,

        'updates.id AS updaterecommendationid',
        'updates.status AS updatestatus',
        'updates.created_at AS updatecreatedat',
        'updates.action_taken_by_ministry AS updateactiontakenbyministry',
        'updates.reason_not_implemented AS updatereasonnotimplemented',

        'ministry.name AS ministry',
        'department.name AS department',

        'primaryMinistry.name AS primaryministry',
        'primaryDepartment.name AS primarydepartment',

        'rec.id AS recid',
        'rec.recommendation_slug AS recslug',
        'rec.name AS recname',

        'hlcupdates.id AS recupdateid',
        'hlcupdates.status AS recupdatestatus',
        'hlcupdates.created_at AS recupdatecreatedat',
      ])

      .orderBy('updates.created_at', 'DESC')
      .addOrderBy('hlcupdates.created_at', 'DESC');

    const raw = await query.getRawMany();

    const grouped: Record<number, any> = {};

    ids.forEach((id) => {
      grouped[id] = null;
    });

    raw.forEach((row: any) => {
      if (!grouped[row.id]) {
        grouped[row.id] = {
          id: row.id,
          recommendationSlug: row.slug,
          name: row.name,
          description: row.description,
          status: row.currentstatus,
          currentStatus: row.rawstatus,
          ministry: {
            name: row.ministry,
          },
          department: {
            name: row.department,
          },
          primaryMinistry: {
            name: row.primaryministry,
          },
          primaryDepartment: {
            name: row.primarydepartment,
          },
          hlcRefId: row.hlcrefid,
          updates: [],
          hlcRecommendationUpdate: row.recid
            ? {
                id: row.recid,
                recommendationSlug: row.recslug,
                name: row.recname,
                updates: [],
              }
            : null,
        };
      }

      if (row.updaterecommendationid) {
        grouped[row.id].updates.push({
          updateId: row.updaterecommendationid,
          status: row.updatestatus,
          createdAt: row.updatecreatedat,
        });
      }

      if (row.recupdateid && grouped[row.id].hlcRecommendationUpdate) {
        grouped[row.id].hlcRecommendationUpdate.updates.push({
          id: row.recupdateid,
          status: row.recupdatestatus,
          createdAt: row.recupdatecreatedat,
        });
      }
    });

    const result = Object.values(grouped).filter(Boolean);

    return noPagination
      ? result
      : {
          total,
          page,
          limit,
          result,
        };
  }

  async export(query: IgomGetRecommendationSummaryDto) {
    const { format, detail = false } = query;
    const recommendations: any = await this.getIgomAndHlcRecommendationSummary(
      query,
      true,
    );
    const formatDate = (d: any) =>
      d
        ? new Date(d).toLocaleDateString('en-IN', {
            timeZone: 'Asia/Kolkata',
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          })
        : '-';
    const data: any[] = [];
    recommendations.forEach((r) => {
      if (detail) {
        data.push({
          'Serial No. of IGoM Recommendation': r.recommendationSlug,
          Description: r.description,
          Recommendations: r.name,
          Timeline: formatDate(r.timeline),
          'Primary Ministry/Department': r.primaryDepartment?.name
            ? `${r.primaryMinistry?.name} / ${r.primaryDepartment?.name}`
            : r.primaryMinistry?.name,
          'Implementing Ministry/Department': r.department?.name
            ? `${r.ministry?.name} / ${r.department?.name}`
            : r.ministry?.name,
          'Implementation Status':
            r.updates.length > 0 ? r.updates[0].status : r.currentStatus,
          'Details of Action Taken(To be entered by the Ministry)':
            r.updates.length > 0
              ? `${formatDate(r.updates[0].createdAt)}:\n${r.updates[0].actionTakenByMinistry}`
              : r.actionTakenByMinistry,
          'Reason If Not Implemented':
            r.updates.length > 0
              ? r.updates[0].reasonNotImplemented
              : r.reasonNotImplemented,
          'Updated Timeline': formatDate(r.updatedTimeline),
          'Closure Remarks': r.closureRemark || '-',
          'Available in Hlc': r.hlcRefId ? 'Yes' : 'No',
          'Hlc RefId': r.hlcRefId,
        });
        if (r.updates?.length > 1) {
          const remainingIgomUpdates = r.updates.slice(1);
          for (const item of remainingIgomUpdates) {
            data.push({
              'Serial No. of HLC Recommendation': '',
              Description: '',
              Recommendations: '',
              Timeline: '',
              'Primary Ministry/Department': '',
              'Implementing Ministry/Department': '',
              'Implementation Status': item.status,
              'Details of Action Taken(To be entered by the Ministry)': `${formatDate(item.createdAt)}:\n${item.actionTakenByMinistry}`,
              'Reason If Not Implemented': item.reasonNotImplemented,
              'Updated Timeline': '',
              'Closure Remarks': '',
              'Available in Hlc': '',
              'Hlc RefId': '',
            });
          }
        }
        const hlcUpdates = r.hlcRecommendationUpdate?.updates ?? [];
        for (const item of hlcUpdates) {
          data.push({
            'Serial No. of IGoM Recommendation': '',
            Description: 'HLC Updates',
            Recommendations: '',
            Timeline: '',
            'Primary Ministry/Department': '',
            'Implementing Ministry/Department': '',
            'Implementation Status': item.status,
            'Details of Action Taken(To be entered by the Ministry)': `${formatDate(item.createdAt)}:\n${item.actionTakenByMinistry}`,
            'Reason If Not Implemented': item.reasonNotImplemented,
            'Updated Timeline': '',
            'Closure Remarks': '',
            'Available in Hlc': '',
            'Hlc RefId': '',
          });
        }
      } else {
        data.push({
          'Recommendation Id': r.recommendationSlug,
          Description: r.description,
          Status: r.status,
          'Implementation Status': r.currentStatus,
          'Latest Update': formatDate(r.updates[0]?.createdAt),
          'Details of Action Taken(To be entered by the Ministry)':
            r.updates[0]?.actionTakenByMinistry || '-',
          'Available in Hlc': r.hlcRefId ? 'Yes' : 'No',
          'Hlc RefId': r.hlcRefId,
        });
        if (r.updates?.length > 1) {
          for (const item of r.updates.slice(1)) {
            data.push({
              'Recommendation Id': '',
              Description: '',
              Status: '',
              'Implementation Status': r.currentStatus,
              'Latest Update': formatDate(item.createdAt),
              'Details of Action Taken(To be entered by the Ministry)':
                item.actionTakenByMinistry,
              'Available in Hlc': '',
              'Hlc RefId': '',
            });
          }
        }
        const hlcUpdates = r.hlcRecommendationUpdate?.updates ?? [];
        for (const item of hlcUpdates) {
          data.push({
            'Recommendation Id': '',
            Description: 'HLC Update',
            Status: '',
            'Implementation Status': item.status,
            'Latest Update': formatDate(item.createdAt),
            'Details of Action Taken(To be entered by the Ministry)':
              item.actionTakenByMinistry,
            'Available in Hlc': '',
            'Hlc RefId': '',
          });
        }
      }
    });

    switch (format) {
      case FormatEnum.EXCEL:
        return this.generateExcel(data);
      case FormatEnum.CSV:
        return this.generateCSV(data);
      case FormatEnum.PDF:
        return this.generatePdf(data, detail);
      case FormatEnum.WORD:
        return this.generateWord(data);
      case FormatEnum.PPT:
        return this.generatePpt(data);
      default:
        throw new Error('Unsupported export format');
    }
  }

  private generateExcel(data: any[]) {
    const worksheet = XLSX.utils.json_to_sheet(data);
    worksheet['!cols'] = Object.keys(data[0]).map(() => ({ wch: 30 }));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Recommendations');

    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  }

  private generateCSV(data: any[]) {
    const parser = new Parser();
    const csv = parser.parse(data);
    return Buffer.from(csv);
  }

  private async generateWord(data: any[]): Promise<Buffer> {
    const headers = Object.keys(data[0]);

    const tableRows = [
      new TableRow({
        children: headers.map(
          (header) =>
            new TableCell({
              children: [new Paragraph({ text: header })],
            }),
        ),
      }),
      ...data.map(
        (row) =>
          new TableRow({
            children: headers.map(
              (header) =>
                new TableCell({
                  children: [new Paragraph(String(row[header] ?? ''))],
                }),
            ),
          }),
      ),
    ];

    const doc = new Document({
      sections: [
        {
          properties: {
            page: {
              size: {
                orientation: PageOrientation.LANDSCAPE,
                // width: 16838,
                // height: 11906
              },
              margin: {
                top: 720,
                bottom: 720,
                left: 720,
                right: 720,
              },
            },
          },
          children: [
            new Paragraph({
              text: 'IGoM Recommendations',
              heading: 'Heading1',
            }),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: tableRows,
            }),
          ],
        },
      ],
    });

    return await Packer.toBuffer(doc);
  }

  private async generatePpt(data: any[]): Promise<any> {
    const pptx = new PptxGenJS();

    const headers = Object.keys(data[0]);

    // Only data rows (NO header here)
    const dataRows = data.map((row) => headers.map((h) => row[h] ?? ''));

    const chunkSize = 12; // reduce to give footer space

    for (let i = 0; i < dataRows.length; i += chunkSize) {
      const slide = pptx.addSlide();

      // Title
      slide.addText('IGoM Recommendations', {
        x: 0.5,
        y: 0.3,
        fontSize: 18,
        bold: true,
      });

      // Combine header + chunked rows (IMPORTANT)
      const tableData = [headers, ...dataRows.slice(i, i + chunkSize)];

      slide.addTable(tableData, {
        x: 0.5,
        y: 0.8,
        w: 9,
        fontSize: 8,
        border: { pt: 0.5 },

        // Style header row
        fill: { color: 'F1F1F1' },
      });

      // Footer spacing + text
      slide.addText(`Slide ${Math.floor(i / chunkSize) + 1}`, {
        x: 0.5,
        y: 6.5, // bottom area
        fontSize: 10,
        color: '666666',
      });
    }

    return await pptx.write({ outputType: 'nodebuffer' });
  }

  async generatePdf(data: any[], detail = false) {
    const fonts = {
      Helvetica: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique',
      },
    };
    var printer = new PdfPrinter(fonts);

    const headers = Object.keys(data[0]);
    const body = [
      headers.map((h) => ({ text: h, bold: true })),
      ...data.map((row) => headers.map((h) => row[h] || '')),
    ];
    const docDefinition: any = {
      pageOrientation: 'landscape',
      defaultStyle: {
        font: 'Helvetica',
        fontSize: 8,
      },
      content: [
        { text: 'IGOM Recommendation Report', style: 'header' },
        {
          table: {
            headerRows: 1,
            // widths: Array(headers.length).fill('*'),
            widths: detail
              ? [50, 80, 80, 40, 60, 60, 50, 90, 40, 30, 30, 20, 20]
              : [
                  // 650 / 7
                  80, 125, 80, 80, 80, 130, 80, 30,
                ],
            body: body,
          },
        },
      ],
      footer: (currentPage, pageCount) => {
        return {
          text: `Page ${currentPage} of ${pageCount}`,
          alignment: 'center',
        };
      },
      styles: {
        header: {
          fontSize: 16,
          bold: true,
          alignment: 'center',
          margin: [0, 0, 0, 20],
        },
      },
    };
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks: any[] = [];
    return new Promise((resolve) => {
      pdfDoc.on('data', (chunk: any) => chunks.push(chunk));
      pdfDoc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });
      pdfDoc.end();
    });
  }
}
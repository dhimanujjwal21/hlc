import {
    Body,
    Controller,
    ForbiddenException,
    Get,
    Post,
    Query,
    Req,
    Res,
    UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from 'src/guards/auth.guard';
import {
    IgomGetRecommendationSummaryDto,
    IgomGetReportStatusSummaryDto,
    IgomMinistryWiseReportDto,
    IgomSummaryDto,
} from './dto/dashboard.dto';
import { IgomDashboardService } from './igomDashboard.service';
import { FormatEnum } from 'src/constants/enums';

@ApiTags('Igom Dashboard')
@Controller({
    path: 'igom/dashboard',
    version: '1',
})
export class IgomDashboardV2Controller {
    constructor(private readonly dashboardService: IgomDashboardService) { }

    private ensureDashboardAccess(user: any) {
        return true
        // if (!user?.dashboardView) {
        //     throw new ForbiddenException(
        //         'You are not allowed to access the dashboard',
        //     );
        // }
    }

    @UseGuards(AuthGuard)
    @ApiBearerAuth()
    @Get('summary')
    async summary(@Req() req, @Query() query: IgomSummaryDto) {
        this.ensureDashboardAccess(req.user);
        const summary = await this.dashboardService.getSummaryV2(
            query
        );
        return summary;
    }

    @UseGuards(AuthGuard)
    @ApiBearerAuth()
    @Get('report-status-summary')
    async getReportStatusSummary(
        @Req() req,
        @Query() dto: IgomGetReportStatusSummaryDto,
    ) {
        this.ensureDashboardAccess(req.user);
        return this.dashboardService.getReportStatusSummary(dto);
    }

    @UseGuards(AuthGuard)
    @ApiBearerAuth()
    @Get('ministry-wise-progress')
    async ministryWiseProgress(@Req() req, @Query() dto: IgomMinistryWiseReportDto) {
        this.ensureDashboardAccess(req.user);
        return this.dashboardService.ministryWiseProgress(dto);
    }

    @UseGuards(AuthGuard)
    @ApiBearerAuth()
    @Get('recommendation-summary-list')
    async getRecommendationSummary(
        @Req() req,
        @Query() dto: IgomGetRecommendationSummaryDto,
    ) {
        this.ensureDashboardAccess(req.user);
        return this.dashboardService.getIgomAndHlcRecommendationSummary(dto);
    }

    @UseGuards(AuthGuard)
    @ApiBearerAuth()
    @Post('export-recommendation-summary-list')
    async exportRecommendationSummary(
        @Req() req,
        @Body() query: IgomGetRecommendationSummaryDto,
        @Res() res
    ) {
        this.ensureDashboardAccess(req.user);
        const buffer = await this.dashboardService.export(query);

        let filename: string = '',
            contentType: string = '';

        switch (query.format) {
            case FormatEnum.CSV:
                filename = 'recommendations.csv';
                contentType = 'text/csv';
                break;

            case FormatEnum.EXCEL:
                filename = 'recommendations.xlsx';
                contentType =
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                break;

            case FormatEnum.PDF:
                filename = 'recommendations.pdf';
                contentType = 'application/pdf';
                break;

            case FormatEnum.PPT:
                filename = 'recommendations.pptx';
                contentType =
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
                break;

            case FormatEnum.WORD:
                filename = 'recommendations.docx';
                contentType =
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation';
                break;

            default:
                break;
        }

        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Type', contentType);

        return res.end(buffer);
    }
}

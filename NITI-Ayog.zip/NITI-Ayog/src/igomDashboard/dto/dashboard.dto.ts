import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { FormatEnum } from 'src/constants/enums';

export class IgomMinistryReportDto {
  @ApiPropertyOptional({
    example: 5,
    description: 'Updated Ministry ID (optional)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'Ministry ID must be an integer' })
  @Min(1, { message: 'Ministry ID must be greater than zero' })
  ministryId?: number;
}

export class IgomSummaryDto {
  @ApiPropertyOptional({ description: 'Filter by Igom ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  igomId?: number;

  @ApiPropertyOptional({ description: 'Filter by Ministry ID' })
  @IsOptional()
  @Type(() => Number)
  ministryId?: number;

  @ApiPropertyOptional({ description: 'Filter by Department ID' })
  @IsOptional()
  @Type(() => Number)
  departmentId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Transform(({ value }) => {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return [value];
  })
  reportNumbers?: string[];
}

export class IgomGetReportStatusSummaryDto {
  @ApiPropertyOptional({ description: 'Filter by Igom ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  igomId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Transform(({ value }) => {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return [value];
  })
  reportNumbers?: string[];
}

export class IgomMinistryWiseReportDto {
  @ApiPropertyOptional({ description: 'Filter by Igom ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  igomId?: number;
}

export class IgomGetRecommendationSummaryDto {
  @ApiPropertyOptional({
    description: 'Page number for pagination',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  page?: number = 1;

  @ApiPropertyOptional({ description: 'Number of items per page' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  limit?: number = 10;
  
  @ApiPropertyOptional({ description: 'Filter by HLC ID' })
  @Type(() => Number)
  @IsNumber()
  igomId?: number;

  @ApiPropertyOptional({ description: 'Filter by Ministry ID' })
  @IsOptional()
  @Type(() => Number)
  ministryId?: number;

  @ApiPropertyOptional({ description: 'Filter by Department ID' })
  @IsOptional()
  @Type(() => Number)
  departmentId?: number;

  @ApiPropertyOptional({ description: 'Filter by Report Numbers' })
  @IsOptional()
  @IsArray()
  @Transform(({ value }) => {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return [value];
  })
  reportNumbers?: string[];

  @ApiPropertyOptional({ description: 'Filter by Status' })
  @IsOptional()
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(FormatEnum, {
    message: 'Status must be either approve or reject',
  })
  format: FormatEnum;

  @ApiPropertyOptional()
  @IsOptional()
  detail: boolean;

  @ApiPropertyOptional({
    description: 'Filter by multiple recommendation IDs',
    type: [Number],
    example: [1, 2, 3],
  })
  @IsOptional()
  @IsArray()
  @Type(() => Number)
  @IsInt({ each: true })
  recommendations?: number[];
}

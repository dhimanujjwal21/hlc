import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';
import { DataSource } from 'typeorm';
import { Role } from '../entities/roles.entity';
import { PERMISSIONS_KEY } from 'src/decorators/permisions.decorator';
import { ConfigService } from '@nestjs/config';
import { AuditLogs } from 'src/entities/audit.entity';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    private readonly reflector: Reflector,
    private readonly dataSource: DataSource,
    private configService: ConfigService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();
    const isPublic = this.reflector.getAllAndOverride<boolean>('isPublic', [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const token = this.extractToken(request);

    if (!token) throw new UnauthorizedException('Missing authentication token');

    // ✅ 1. Verify JWT
    let payload: any;
    try {
      payload = await this.jwtService.verifyAsync(token, {
        secret: this.configService.get<string>('JWT_SECRET'),
        // publicKey
      });
    } catch (err) {
      console.log(err);
      throw new UnauthorizedException('Session expired. Please login again.');
    }

    // ✅ 2. Attach user to request
    request['user'] = payload;

    // ✅ 3. Check required permissions from metadata
    const requiredPermissions =
      this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, [
        context.getHandler(),
        context.getClass(),
      ]) || [];

    // If route doesn’t need permissions, allow access
    if (!requiredPermissions.length) return true;

    // ✅ 4. Fetch user role and permissions
    const role = await this.dataSource.getRepository(Role).findOne({
      where: { id: payload.roleId },
      relations: ['rolePermissions', 'rolePermissions.permission'],
    });

    if (!role) throw new ForbiddenException('User role not found');

    const userPermissions = role.rolePermissions.map(
      (rp) => rp.permission.permissionName,
    );

    if (requiredPermissions.length > 0) {
      // ✅ 5. Check if user has at least one required permission
      const hasPermission = requiredPermissions.some((perm) =>
        userPermissions.includes(perm),
      );

      if (!hasPermission) {
        throw new ForbiddenException(
          `You don't have permission to access this resource.`,
        );
      }
    }

    //    console.log('User id', payload);
    await this.logAudit(request, payload.id);

    return true;
  }

  private extractToken(request: Request): string | undefined {
    const authHeader = request.headers.authorization;
    if (!authHeader) return undefined;
    const [type, token] = authHeader.split(' ');
    return type === 'Bearer' ? token : undefined;
  }

  private sanitizeData(data: any): any {
    if (!data || typeof data !== 'object') {
      return data;
    }

    const sensitiveFields = [
      'password',
      'confirmPassword',
      'currentPassword',
      'newPassword',
      'token',
      'accessToken',
      'refreshToken',
      'authorization',
    ];

    const sanitized = { ...data };

    for (const field of sensitiveFields) {
      if (Object.prototype.hasOwnProperty.call(sanitized, field)) {
        sanitized[field] = '[REDACTED]';
      }
    }

    return sanitized;
  }

  private async logAudit(request: Request, userId: number) {
    try {
      const repo = this.dataSource.getRepository(AuditLogs);

      const audit = repo.create({
        userId,
        method: request.method,
        route: request.url,
        query: this.sanitizeData(request.query || {}),
        params: this.sanitizeData(request.params || {}),
        body: this.sanitizeData(request.body || {}),
      });

      await repo.save(audit);
    } catch (err) {
      console.error('❌ Failed to log audit entry:', err.message);
    }
  }
}

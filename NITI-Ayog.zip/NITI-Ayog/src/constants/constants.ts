export const CC_EMAILS = [
    'dhrijesh@gov.in',
    'ahmed.i@nic.in',
    'dgdmeo.niti@gov.in'
];

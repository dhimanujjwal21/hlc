export enum RoleEnum {
  SUPER_ADMIN = 'Super Admin',
  NITI_DIRECTOR = 'Niti Director',
  NITI_APPROVER = 'Niti Approver',
  DEA_APPROVER = 'Dea Approver',
  MINISTRY_DIRECTOR = 'Ministry Director',
  MINISTRY_APPROVER = 'Ministry Approver',
  MINISTRY_SECRETARY = 'Ministry Secretary',
  NITI_VIEWER = 'NITI Viewer',
  DEA_DIRECTOR = 'Dea Director',
  NFRR_VIEWER = 'NFRR Viewer',
}

export enum RecommendationStageEnum {
  NITI_DIRECTOR = 'Niti Director',
  DEA_DIRECTOR = 'DEA Director',
  DEA_APPROVER = 'DEA Approver',
  NITI_APPROVER = 'Niti Approver',
  MINISTRY_DIRECTOR = 'Ministry Director',
  MINISTRY_APPROVER = 'Ministry Approver',
  REASSIGN_PENDING = 'Reassign Pending',
  REASSIGN_REJECTED = 'Reassign Rejected',
  REASSIGN_EDIT = 'Reassign Edit',
}

export enum PermissionsEnum {
  ADD_DEPARTMENT = 'ADD_DEPARTMENT',
  EDIT_DEPARTMENT = 'EDIT_DEPARTMENT',
  DELETE_DEPARTMENT = 'DELETE_DEPARTMENT',
  ADD_MINISTRY = 'ADD_MINISTRY',
  EDIT_MINISTRY = 'EDIT_MINISTRY',
  DELETE_MINISTRY = 'DELETE_MINISTRY',
  ADD_PERMISSION = 'ADD_PERMISSION',
  EDIT_PERMISSION = 'EDIT_PERMISSION',
  DELETE_PERMISSION = 'DELETE_PERMISSION',
  ADD_ROLE = 'ADD_ROLE',
  EDIT_ROLE = 'EDIT_ROLE',
  DELETE_ROLE = 'DELETE_ROLE',
  ASSIGN_ROLE_PERMISSION = 'ASSIGN_ROLE_PERMISSION',
  CREATE_USER = 'CREATE_USER',
  USER_LIST = 'USER_LIST',
  EDIT_USER = 'EDIT_USER',
  ADD_HLC = 'ADD_HLC',
  EDIT_HLC = 'EDIT_HLC',
  DELETE_HLC = 'DELETE_HLC',
  ADD_RECOMMENDATION = 'ADD_RECOMMENDATION',
  EDIT_RECOMMENDATION = 'EDIT_RECOMMENDATION',
  DELETE_RECOMMENDATION = 'DELETE_RECOMMENDATION',
  CLOSE_RECOMMENDATION = 'CLOSE_RECOMMENDATION',
  NITI_APPROVER_REQUEST = 'NITI_APPROVER_REQUEST',
  DEA_APPROVER_REQUEST = 'DEA_APPROVER_REQUEST',
  DEA_DIRECTOR_REQUEST = 'DEA_DIRECTOR_REQUEST',
  MINISTRY_APPROVER_REQUEST = 'MINISTRY_APPROVER_REQUEST',
  MINISTRY_DIRECTOR_REQUEST = 'MINISTRY_DIRECTOR_REQUEST',
  GET_HLC = 'GET_HLC',
}

export enum PermissionsDescriptionEnum {
  ADD_DEPARTMENT = 'Add a new department',
  EDIT_DEPARTMENT = 'Edit an existing department',
  DELETE_DEPARTMENT = 'Delete a department',
  ADD_MINISTRY = 'Add a new ministry',
  EDIT_MINISTRY = 'Edit an existing ministry',
  DELETE_MINISTRY = 'Delete a ministry',
  ADD_PERMISSION = 'Add a new permission',
  EDIT_PERMISSION = 'Edit an existing permission',
  DELETE_PERMISSION = 'Delete a permission',
  ADD_ROLE = 'Add a new role',
  EDIT_ROLE = 'Edit an existing role',
  DELETE_ROLE = 'Delete a role',
  ASSIGN_ROLE_PERMISSION = 'Assign permissions to a role',
  CREATE_USER = 'Create a new user',
  ADD_HLC = 'Add a new High-Level Committee (HLC)',
  EDIT_HLC = 'Edit HLC details',
  DELETE_HLC = 'Delete an HLC',
  ADD_RECOMMENDATION = 'Add a new recommendation',
  EDIT_RECOMMENDATION = 'Edit an existing recommendation',
  NITI_APPROVER_REQUEST = 'Handle request by NITI Approver',
  MINISTRY_APPROVER_REQUEST = 'Handle request by Ministry Approver',
  MINISTRY_DIRECTOR_REQUEST = 'Handle request by Ministry Director',
}

export enum RequestStatusEnum {
  APPROVE = 'approve',
  REJECT = 'reject',
  COMPLETED = 'completed',
  NOT_COMPLETED = 'not completed',
  FORWARDED = 'forwarded',
}

export enum ImplementationEnum {
  OTHER = 'other',
  MY = 'my',
  TOTAL = 'total',
}

export enum FormatEnum {
  EXCEL = 'excel',
  CSV = 'csv',
  PDF = 'pdf',
  WORD = 'word',
  PPT = 'ppt',
}

export enum ImplementationStatusEnum {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

export enum StageEnum {
  //  Stage 1
  PENDING_WITH_NITI_DIRECTOR = 'Pending with NITI Director', // 2.1 Reject
  PENDING_WITH_DEA_DIRECTOR = 'Pending with DEA Director', // 2.1 Reject

  // Stage 2.1
  PENDING_WITH_NITI_APPROVER = 'Pending with NITI Approver',
  PENDING_WITH_DEA_APPROVER = 'Pending with DEA Approver',

  PENDING_WITH_DEA_APPROVER_FOR_REASSIGN = 'Pending with DEA Approver for Reassign Pending',
  REJECT_REASSIGN_BY_DEA_APPROVER_FOR_REASSIGN = 'Reject reassigned by DEA Approver',

  // Stage 3
  PENDING_WITH_MINISTRY_DIRECTOR = 'Pending with Ministry Director', // 2.2 Reject, Forward | 4 Reject | 2.3 timeline given

  // Stage 4
  PENDING_WITH_MINISTRY_APPROVER = 'Pending with Ministry Approver',

  // Stage 2.2
  ACCEPTED_BY_NITI_APPROVER = 'Accepted by NITI Approver',
  ACCEPTED_BY_DEA_APPROVER = 'Accepted by DEA Approver',
  ACCEPTED_BY_DEA_APPROVER_FOR_HLC_REFERENCE = 'Accepted by DEA Approver for hlc reference',

  // Stage 2.3
  PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE = 'Pending with NITI Approver for updated timeline',
  PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE = 'Pending with DEA Approver for updated timeline',

  // Stage 5
  COMPLETED = 'Completed',

  // Stage 6
  CLOSED_BY_HLC = 'Closed by HLC',
  CLOSED_BY_IGOM = 'Closed by IGOM',

  // 🔹 NITI Approver
  // APPROVED_BY_NITI_APPROVER = 'Approved by NITI Approver',
  // REJECTED_BY_NITI_APPROVER = 'Rejected by NITI Approver',
  NITI_DIRECTOR_RECOMMENDATION_CREATION = 'NITI Director created recommendation',
  DEA_DIRECTOR_RECOMMENDATION_CREATION = 'DEA Director created recommendation',

  REASSIGN_REJECTED = 'Reassign Rejected',
}

export enum StatusEnum {
  FULLY_IMPLEMENTED = 'Fully implemented',
  PARTIALLY_IMPLEMENTED = 'Partially implemented',
  UNDER_IMPLEMENTATION = 'Under progress',
  YET_TO_INITIATE = 'Yet to initiate',
  NO_ACTION = 'No Action',
  // NOT_FULLY_IMPLEMENTED = 'Not fully implemented'
}

export enum AllStatusEnum {
  FULLY_IMPLEMENTED = 'Fully implemented',
  PARTIALLY_IMPLEMENTED = 'Partially implemented',
  UNDER_IMPLEMENTATION = 'Under progress',
  YET_TO_INITIATE = 'Yet to initiate',
  NO_ACTION = 'No Action',
  CLOSED = 'Closed',
  // NOT_FULLY_IMPLEMENTED = 'Not fully implemented'
}

export enum TrailDescriptionEnum {
  CREATE_RECOMMENDATION = 'Recommendation created by NITI Director',
  UPDATE_RECOMMENDATION = 'Recommendation details updated by NITI Director',

  // NITI Director
  FORWARDED_TO_NITI_APPROVER = 'Recommendation forwarded to NITI Approver',
  APPROVED_BY_NITI_DIRECTOR = 'Recommendation approved by NITI Director',
  REJECTED_BY_NITI_DIRECTOR = 'Recommendation rejected by NITI Director',
  TIMELINE_UPDATED = 'Niti Approver assigned new timeline',
  MARK_COMPLETED = 'Niti Approver marked completed',
  MARK_NOT_COMPLETED = 'Niti Approver marked not completed',

  // NITI Approver
  FORWARDED_TO_MINISTRY_DIRECTOR = 'Recommendation forwarded to Ministry Director',
  APPROVED_BY_NITI_APPROVER = 'Recommendation approved by NITI Approver',
  APPROVED_BY_DEA_APPROVER = 'Recommendation approved by DEA Approver',
  REJECTED_BY_NITI_APPROVER = 'Recommendation rejected by NITI Approver',
  REJECTED_BY_DEA_APPROVER = 'Recommendation rejected by DEA Approver',
  PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE = 'Pending with NITI Approver for new timeline',
  PENDING_WITH_DEA_APPROVER_FOR_UPDATED_TIMELINE = 'Pending with DEA Approver for new timeline',

  // Ministry Director
  FORWARDED_TO_MINISTRY_APPROVER = 'Recommendation forwarded to Ministry Approver',
  ACTION_TAKEN_BY_MINISTRY = 'Action taken details submitted by Ministry Director',
  MINISTRY_DIRECTOR_UPDATE = 'Ministry director updated status of recommendation',

  // Ministry Approver
  APPROVED_BY_MINISTRY_APPROVER = 'Recommendation approved by Ministry Approver',
  REJECTED_BY_MINISTRY_APPROVER = 'Recommendation rejected by Ministry Approver',

  // Generic
  STATUS_UPDATED = 'Recommendation status updated',

  CLOSED_BY_HLC = 'Recommendation closed by Niti Approver',
  CLOSED_BY_IGOM = 'Recommendation closed by DEA Approver',
}

export enum DraftRoleEnum {
  NITI_DIRECTOR = 'Niti Director',
  MINISTRY_DIRECTOR = 'Ministry Director',
}

export enum DraftStatusEnum {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

export enum RecommendationActionEnum {
  FORWARDED_TO_MINISTRY_APPROVER = 'Forwarded to Ministry Approver',
  FORWARDED_TO_MINISTRY_DIRECTOR = 'Forwarded to Ministry Director',

  FORWARDED_TO_NITI_APPROVER = 'Forwarded to NITI Approver',

  PENDING_WITH_NITI_DIRECTOR = 'Pending with NITI Director',
  PENDING_WITH_NITI_APPROVER = 'Pending with NITI Approver',

  PENDING_WITH_MINISTRY_DIRECTOR = 'Pending with Ministry Director',
  PENDING_WITH_MINISTRY_APPROVER = 'Pending with Ministry Approver',

  CURRENTLY_WITH_MINISTRY_DIRECTOR = 'Currently with Ministry Director',
  CURRENTLY_WITH_MINISTRY_APPROVER = 'Currently with Ministry Approver',
  CURRENTLY_WITH_NITI_DIRECTOR = 'Currently with NITI Approver',
  CURRENTLY_WITH_DEA_DIRECTOR = 'Currently with DEA Director',
  CURRENTLY_WITH_NITI_APPROVER = 'Currently with NITI Approver',
  CURRENTLY_WITH_DEA_APPROVER = 'Currently with DEA Approver',

  CLOSED = 'Closed',
}

export enum ClosureStatusEnum {
  OPEN = 'open',
  CLOSED = 'closed',
}

export enum ReassignStatusEnum {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  REASSIGNEDIT = 'reassign edit',
}

export enum ReassignRecStatusEnum {
  PENDING = 'pending',
  REJECTREASSIGNED = 'reject-reassign-edit',
  APPROVED = 'approved',
  APPROVEDREASSIGNED = 'approve-reassign-edit',
  REJECTED = 'rejected',
  REASSIGNEDIT = 'reassignedit',
}

export enum ReassignRecommStatusEnum {
  PENDING = 'pending',
  REJECTREASSIGNED = 'reject-reassigned',
  APPROVED_FROM = 'reassign approved from',
  APPROVED_TO = 'reassign approved to',
  REJECTED = 'rejected',
}

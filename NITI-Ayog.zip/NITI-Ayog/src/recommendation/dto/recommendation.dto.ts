import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsString,
  IsInt,
  IsDateString,
  IsOptional,
  Min,
  Max,
  IsEnum,
  ValidateIf,
  IsDate,
  IsNotEmpty,
  IsArray,
  ArrayMinSize,
  IsBoolean,
  MaxLength,
} from 'class-validator';
import {
  FormatEnum,
  ImplementationEnum,
  RequestStatusEnum,
  RoleEnum,
  StatusEnum,
} from 'src/constants/enums';

export class CreateRecommendationDto {
  @ApiProperty({
    example: 'REC-001',
    description: 'Unique recommendation identifier',
  })
  @IsString()
  recommendationSlug: string;

  @ApiProperty({
    example: 'Improve Water Supply System',
    description: 'Recommendation title',
  })
  @IsString()
  name: string;

  @ApiProperty({
    example: 'Upgrade old infrastructure and pipelines',
    required: true,
  })
  @IsString()
  description: string;

  @ApiPropertyOptional({
    example: 1,
    required: true,
    description: 'Department ID (foreign key)',
  })
  @IsOptional()
  @IsInt()
  departmentId: number;

  @ApiProperty({
    example: 2,
    required: true,
    description: 'Ministry ID (foreign key)',
  })
  @IsInt()
  ministryId: number;

  @ApiPropertyOptional({
    example: 1,
    required: true,
    description: 'Primary Department ID (foreign key)',
  })
  @IsOptional()
  @IsInt()
  primaryDepartmentId: number;

  @ApiProperty({
    example: 2,
    required: true,
    description: 'Primary Ministry ID (foreign key)',
  })
  @IsInt()
  primaryMinistryId: number;

  @ApiProperty({
    example: 3,
    required: true,
    description: 'HLC ID (foreign key)',
  })
  @IsInt()
  hlcId: number;

  @ApiProperty({ example: '2025-12-31T00:00:00Z', required: true })
  @IsDateString()
  timeline: Date;

  @ApiProperty({ example: 'RPT-23', required: true })
  @IsString()
  reportNumber: string;
}

export class UpdateRecommendationDto extends PartialType(
  CreateRecommendationDto,
) {}

export class GetRecommendationQueryDto {
  @ApiPropertyOptional({ description: 'Filter by department ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  departmentId?: number;

  @ApiPropertyOptional({ description: 'Filter by ministry ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  ministryId?: number;

  @ApiPropertyOptional({ description: 'Filter by HLC ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  hlcId?: number;

  @ApiPropertyOptional({
    description: 'Filter by current status',
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({
    description: 'Page number for pagination',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  page?: number = 1;

  @ApiPropertyOptional({ description: 'Number of items per page' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  limit?: number = 10;

  // @ApiPropertyOptional({ description: 'Report Number' })
  // @IsOptional()
  // @IsString()
  // reportNumber?: string;

  // @ApiPropertyOptional({
  //   description: 'Report Numbers',
  //   type: [String],
  //   example: ['RPT-001', 'RPT-002']
  // })
  // @IsOptional()
  // @IsArray()
  // @IsString({ each: true })
  // @Type(() => String)
  // reportNumber?: string[];

  @ApiPropertyOptional({
    description: 'Report Numbers',
    type: [String],
    example: ['RPT-001', 'RPT-002'],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Transform(({ value }) => {
    // If single string → wrap in array
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
  })
  reportNumber?: string[];

  @ApiPropertyOptional({
    description: 'Search by name, slug, description, or report number',
  })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiPropertyOptional({
    description: 'Filter recommendations by month and year of this date',
  })
  @IsOptional()
  @IsDateString(
    {},
    { message: 'Date must be a valid ISO date string (e.g., 2025-11-01)' },
  )
  date?: string;

  @ApiPropertyOptional({
    description: 'Filter by multiple recommendation IDs',
    type: [Number],
    example: [1, 2, 3],
  })
  @IsOptional()
  @IsArray()
  @Type(() => Number)
  @IsInt({ each: true })
  recommendations?: number[];

  @ApiPropertyOptional({
    description: 'Enable flag to get pending at users end',
  })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  pending?: boolean = false;

  @ApiPropertyOptional({ description: 'Recommendation Implementation by' })
  @IsOptional()
  @IsEnum(ImplementationEnum, {
    message: 'Status must be either approve or reject',
  })
  implementation?: ImplementationEnum;

  @ApiPropertyOptional({
    description: 'Search by name, slug, description, or report number',
  })
  @IsOptional()
  @IsEnum(RoleEnum, {
    message: 'Role must be one of the defined roles',
  })
  roleType?: RoleEnum;
}

export class ExportRecommendationDto extends GetRecommendationQueryDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(FormatEnum, {
    message: 'Status must be either approve or reject',
  })
  format: FormatEnum;
}

export class NitiApproverRequestDto {
  @ApiProperty({
    description: 'Status of the approval request',
    enum: RequestStatusEnum,
    example: 'approve',
  })
  @IsEnum(RequestStatusEnum, {
    message: 'Status must be either approve or reject',
  })
  status: RequestStatusEnum;

  @ApiProperty({
    description: 'Remarks for rejection (required if status is reject)',
    example: 'Insufficient details provided',
    required: false,
  })
  @ValidateIf((o) => o.status === RequestStatusEnum.REJECT)
  @IsString({ message: 'Remarks must be a string' })
  remarks?: string;

  @ApiPropertyOptional({
    description: 'Updated implementation timeline',
    example: '2025-12-31T00:00:00.000Z',
  })
  @IsOptional()
  @IsDate()
  @Type(() => Date)
  updatedTimeline: Date;
}

export class MinistryDirectorRequestDto {
  @ApiProperty({
    description: 'Action taken by the ministry',
    example: 'Ministry has initiated the required actions.',
  })
  @IsString()
  @IsNotEmpty({ message: 'Action taken by ministry is required' })
  actionTakenByMinistry: string;

  @ApiProperty({
    description: 'Current status of the recommendation',
    enum: StatusEnum,
    example: StatusEnum['Under Implementation'],
  })
  @IsEnum(StatusEnum, {
    message: `Status must be one of: ${Object.values(StatusEnum).join(', ')}`,
  })
  status: StatusEnum;

  @ApiPropertyOptional({
    description:
      'Reason if the recommendation is not implemented (required if not fully implemented)',
    example: 'Pending due to resource constraints',
    required: false,
  })
  @IsOptional()
  @IsString()
  reasonIfNotImplemented?: string;

  @ApiPropertyOptional({
    description: 'Acts, rules, or provisions modified by the ministry',
    example: 'Amendment made to Section 4 of the Act.',
    maxLength: 1000,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000, {
    message: 'Acts/Rules/Provisions modified must not exceed 1000 characters',
  })
  actsRulesProvisionsModified?: string | null;

  @ApiPropertyOptional({
    description: 'Other ministries consulted during the process',
    example: 'Ministry of Finance and Ministry of Law were consulted.',
    maxLength: 1000,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000, {
    message: 'Other ministries consulted must not exceed 1000 characters',
  })
  otherMinistriesConsulted?: string | null;
}

export class MinistryApproverRequestDto {
  @ApiProperty({
    description: 'Status of the approval request',
    enum: RequestStatusEnum,
    example: 'approve',
  })
  @IsEnum(RequestStatusEnum, {
    message: 'Status must be either approve or reject',
  })
  status: RequestStatusEnum;

  @ApiProperty({
    description: 'Remarks for rejection (required if status is reject)',
    example: 'Insufficient details provided',
    required: false,
  })
  @ValidateIf((o) => o.status === RequestStatusEnum.REJECT)
  @IsString({ message: 'Remarks must be a string' })
  remarks?: string;
}

export class BulkApproveDto {
  @ApiProperty({
    description: 'recommendation IDs to approve',
    type: [Number],
    example: [1, 2, 3],
  })
  @IsArray()
  @ArrayMinSize(0)
  @Type(() => Number)
  @IsInt({ each: true })
  recommendations: number[];
}

export class CloseRecommendationDto {
  @IsOptional()
  @IsString()
  closureRemark?: string;
}
export class PresignFileDto {
  files: {
    fileName: string;
    mimeType: string;
    size: number;
  }[];
}

export class SaveFilesDto {
  files: {
    fileName: string;
    fileKey: string;
    fileSize: number;
  }[];
}

import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Recommendation } from 'src/entities/recommendation.entity';
import { In, IsNull, Repository } from 'typeorm';
import {
  BulkApproveDto,
  CloseRecommendationDto,
  CreateRecommendationDto,
  ExportRecommendationDto,
  GetRecommendationQueryDto,
  MinistryApproverRequestDto,
  MinistryDirectorRequestDto,
  NitiApproverRequestDto,
  UpdateRecommendationDto,
} from './dto/recommendation.dto';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import {
  ClosureStatusEnum,
  FormatEnum,
  ImplementationEnum,
  ImplementationStatusEnum,
  RecommendationActionEnum,
  RecommendationStageEnum,
  RequestStatusEnum,
  RoleEnum,
  StageEnum,
  StatusEnum,
  TrailDescriptionEnum,
} from 'src/constants/enums';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import * as XLSX from 'xlsx';
import { Parser } from 'json2csv';
import { AuditLogs } from 'src/entities/audit.entity';
import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { RecommendationFile } from '../entities/recommendation-file.entity';
import { v4 as uuid } from 'uuid';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
// import PDFDocument from 'pdfkit';
// import { PDFDocument as PDFLib } from 'pdf-lib';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';
var PdfPrinter = require('pdfmake');

@Injectable()
export class RecommendationService {
  private s3 = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY,
      secretAccessKey: process.env.AWS_SECRET_KEY,
    },
  } as any);

  private awsBucket = process.env.AWS_BUCKET;
  private awsRegion = process.env.AWS_REGION;

  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,

    @InjectRepository(RecommendationTrail)
    private readonly recommendationTrailRepository: Repository<RecommendationTrail>,

    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,

    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,

    @InjectRepository(RecommendationUpdates)
    private readonly recommendationUpdatesRepository: Repository<RecommendationUpdates>,

    @InjectRepository(RecommendationFile)
    private readonly recommendationFileRepository: Repository<RecommendationFile>,
  ) {}

  async createRecommendation(
    payload: CreateRecommendationDto,
    userId: number,
  ): Promise<Recommendation> {
    const {
      departmentId,
      ministryId,
      hlcId,
      primaryDepartmentId,
      primaryMinistryId,
    } = payload;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userHlcs', 'userHlcs.hlc'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }
    const hlcIds = user?.userHlcs?.map((h) => h.hlc.id) || [];
    if (!hlcIds.includes(hlcId)) {
      throw new BadRequestException(
        `You cannot add recommendation for this HLC.`,
      );
    }

    let department: Departments | null = null;
    let ministry: Ministry | null = null;
    let hlc: Hlc | null = null;
    let primaryMinistry: Ministry | null = null;
    let primaryDepartment: Departments | null = null;

    if (ministryId) {
      ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });
      if (!ministry)
        throw new NotFoundException(`Implementation Ministry not found`);
    }

    if (primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: primaryMinistryId },
      });
      if (!primaryMinistry)
        throw new NotFoundException(`Primary Ministry not found`);
    }

    if (departmentId) {
      department = await this.departmentRepository.findOne({
        where: { id: departmentId },
        relations: ['ministry'],
      });
      if (!department)
        throw new NotFoundException(`Implementation Department not found`);

      if (department && department.ministry?.id !== ministryId)
        throw new BadRequestException('Department is not of this ministry');
    }

    if (primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: primaryDepartmentId },
        relations: ['ministry'],
      });
      if (!primaryDepartment)
        throw new NotFoundException(`Primary Department not found`);
      if (
        primaryDepartment &&
        primaryDepartment.ministry?.id !== primaryMinistryId
      )
        throw new BadRequestException(
          'Primary Department is not of this ministry',
        );
    }

    if (hlcId) {
      hlc = await this.hlcRepository.findOne({ where: { id: hlcId } });
      if (!hlc) throw new NotFoundException(`HLC not found`);
    }

    const query: any = { recommendationSlug: payload.recommendationSlug };
    if (ministry) query.ministry = ministry;
    if (department) query.department = department;
    const existingCombination = await this.recommendationRepository.findOne({
      where: query,
    });

    if (existingCombination) {
      throw new ConflictException(
        `Recommendation "${payload.recommendationSlug}" already exists for this ministry/department combination.`,
      );
    }

    const recommendation = this.recommendationRepository.create({
      recommendationSlug: payload.recommendationSlug,
      name: (payload.name ?? '').trim(),
      description: (payload.description ?? '').trim(),
      timeline: payload.timeline,
      reportNumber: payload.reportNumber,
      department,
      ministry,
      hlc,
      primaryDepartment,
      primaryMinistry,
      currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
      stage: RecommendationStageEnum.NITI_APPROVER,
    });

    const data = await this.recommendationRepository.save(recommendation);
    this.addRecommendationTrail({
      currentStatus: StageEnum.NITI_DIRECTOR_RECOMMENDATION_CREATION,
      nextStatus: StageEnum.PENDING_WITH_NITI_APPROVER,
      recommendationId: data.id,
      userId,
      description: TrailDescriptionEnum.CREATE_RECOMMENDATION,
      otherDetails: { body: payload },
    });
    return data;
  }

  async updateRecommendation(
    id: number,
    dto: UpdateRecommendationDto,
    userId: number,
  ): Promise<Recommendation> {
    const {
      ministryId,
      departmentId,
      primaryDepartmentId,
      primaryMinistryId,
      hlcId,
      name,
      description,
      recommendationSlug,
      reportNumber,
      timeline,
    } = dto;

    const recommendation = await this.recommendationRepository.findOne({
      where: { id },
      relations: ['ministry', 'primaryMinistry'],
    });

    const existingMinistryId = recommendation?.ministry?.id;
    const existingPrimaryMinistryId = recommendation?.primaryMinistry?.id;

    if (!recommendation) {
      throw new NotFoundException('Recommendation not found');
    }

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userHlcs', 'userHlcs.hlc'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }
    const hlcIds: any = user?.userHlcs?.map((h) => h.hlc.id) || [];
    if (!hlcIds.includes(hlcId)) {
      throw new BadRequestException(
        `You cannot edit recommendation for this HLC.`,
      );
    }

    const currentStatus = recommendation?.currentStatus;

    let department: Departments | null = null;
    let ministry: Ministry | null = null;
    let hlc: Hlc | null = null;
    let primaryMinistry: Ministry | null = null;
    let primaryDepartment: Departments | null = null;

    if (ministryId) {
      ministry = await this.ministryRepository.findOne({
        where: { id: ministryId },
      });
      if (!ministry)
        throw new NotFoundException(`Implementation Ministry not found`);
      recommendation.ministry = ministry;
    }

    if (primaryMinistryId) {
      primaryMinistry = await this.ministryRepository.findOne({
        where: { id: primaryMinistryId },
      });
      if (!primaryMinistry)
        throw new NotFoundException(`Primary Ministry not found`);
      recommendation.primaryMinistry = primaryMinistry;
    }

    if (departmentId) {
      department = await this.departmentRepository.findOne({
        where: { id: departmentId },
        relations: ['ministry'],
      });
      if (!department)
        throw new NotFoundException(`Implementation Department not found`);
      if (department && department.ministry?.id !== ministryId)
        throw new BadRequestException('Department is not of this ministry');
      recommendation.department = department;
    } else {
      recommendation.department = null;
    }

    if (primaryDepartmentId) {
      primaryDepartment = await this.departmentRepository.findOne({
        where: { id: primaryDepartmentId },
        relations: ['ministry'],
      });
      if (!primaryDepartment)
        throw new NotFoundException(`Primary Department not found`);
      if (
        primaryDepartment &&
        primaryDepartment.ministry?.id !== primaryMinistryId
      )
        throw new BadRequestException(
          'Primary Department is not of this ministry',
        );
      recommendation.primaryDepartment = primaryDepartment;
    } else {
      recommendation.primaryDepartment = null;
    }

    if (hlcId) {
      hlc = await this.hlcRepository.findOne({
        where: { id: hlcId },
      });
      if (!hlc) throw new NotFoundException(`HLC not found`);
      recommendation.hlc = hlc;
    }

    if (dto.recommendationSlug) {
      const query: any = { recommendationSlug: dto.recommendationSlug };
      if (ministry) query.ministry = ministry;
      if (department) query.department = department;
      const duplicate = await this.recommendationRepository.findOne({
        where: query,
        relations: ['ministry', 'department'],
      });

      if (duplicate && duplicate.id !== id) {
        throw new BadRequestException(
          'Same recommendation with selected ministry and department already exists',
        );
      }
    }

    // Object.assign(recommendation, dto);
    if (name) recommendation.name = (name ?? '').trim();
    if (description) recommendation.description = (description ?? '').trim();
    if (recommendationSlug)
      recommendation.recommendationSlug = recommendationSlug;
    if (reportNumber) recommendation.reportNumber = reportNumber;
    if (timeline) recommendation.timeline = timeline;

    recommendation.currentStage = StageEnum.PENDING_WITH_NITI_APPROVER;
    recommendation.stage = RecommendationStageEnum.NITI_APPROVER;
    recommendation.updatedAt = new Date();
    recommendation.nitiRemark = '';

    this.addRecommendationTrail({
      currentStatus: currentStatus,
      nextStatus: StageEnum.PENDING_WITH_NITI_APPROVER,
      recommendationId: id,
      userId,
      description: TrailDescriptionEnum.UPDATE_RECOMMENDATION,
      otherDetails: {
        body: dto,
      },
    });

    return await this.recommendationRepository.save(recommendation);
  }

  async findAll(
    query: GetRecommendationQueryDto,
    userId: number,
    noPagination = false,
    all = false,
  ) {
    const {
      departmentId,
      ministryId,
      hlcId,
      status,
      search,
      date,
      reportNumber,
      page = 1,
      limit = 10,
      recommendations,
      pending,
      implementation,
      roleType,
    } = query;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: [
        'ministry',
        'role',
        'userHlcs',
        'userHlcs.hlc',
        'userRoles',
        'userRoles.role',
      ],
    });
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isMinistryRole =
      user.role?.roleName === RoleEnum.MINISTRY_DIRECTOR ||
      user.role?.roleName === RoleEnum.MINISTRY_APPROVER;

    let pendingCount = 0;
    if (user.ministry?.id && roleType === RoleEnum.NFRR_VIEWER) {
      const userHlcIds = user?.userHlcs?.map((h) => h.hlc.id) || [];
      if (hlcId && userHlcIds.length > 0 && !userHlcIds.includes(hlcId)) {
        throw new ForbiddenException('You do not have access to this HLC');
      }
      const finalHlcIds = hlcId ? [hlcId] : userHlcIds;
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
          hlc: {
            id: In(finalHlcIds),
          },
        },
      });
    } else if (user.ministry?.id) {
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          ministry: user.ministry,
        },
      });
    } else if (
      !all &&
      (user.role?.roleName === RoleEnum.NITI_APPROVER ||
        user.role?.roleName === RoleEnum.NITI_DIRECTOR ||
        user.role?.roleName === RoleEnum.NITI_VIEWER ||
        user.role?.roleName === RoleEnum.NFRR_VIEWER)
    ) {
      const userHlcIds = user?.userHlcs?.map((h) => h.hlc.id) || [];
      if (hlcId && userHlcIds.length > 0 && !userHlcIds.includes(hlcId)) {
        throw new ForbiddenException('You do not have access to this HLC');
      }
      const finalHlcIds = hlcId ? [hlcId] : userHlcIds;
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
          hlc: {
            id: In(finalHlcIds),
          },
        },
      });
    } else {
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
        },
      });
    }

    let stage: string = RecommendationStageEnum.NITI_APPROVER;
    switch (user.role?.roleName) {
      case RoleEnum.MINISTRY_APPROVER:
        stage = RecommendationStageEnum.MINISTRY_APPROVER;
        break;
      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        break;
      case RoleEnum.NITI_DIRECTOR:
        stage = RecommendationStageEnum.NITI_DIRECTOR;
        break;
      case RoleEnum.MINISTRY_DIRECTOR:
        stage = RecommendationStageEnum.NITI_APPROVER;
        break;
      default:
        stage = '';
        break;
    }

    const qb = this.recommendationRepository
      .createQueryBuilder('recommendation')
      .leftJoinAndSelect('recommendation.department', 'department')
      .leftJoinAndSelect('recommendation.ministry', 'ministry')
      .leftJoinAndSelect(
        'recommendation.primaryDepartment',
        'primaryDepartment',
      )
      .leftJoinAndSelect('recommendation.primaryMinistry', 'primaryMinistry')
      .leftJoinAndSelect('recommendation.hlc', 'hlc');

    if (isMinistryRole) {
      qb.leftJoinAndSelect(
        'recommendation.recommendationUpdates',
        'recommendationUpdates',
      );
    } else {
      qb.leftJoinAndSelect(
        'recommendation.recommendationUpdates',
        'recommendationUpdates',
        'recommendationUpdates.ministryApproverStatus = :approvedStatus',
        { approvedStatus: ImplementationStatusEnum.APPROVED },
      );
    }

    if (user.ministry?.id && roleType !== RoleEnum.NFRR_VIEWER) {
      const ministryId = user.ministry?.id;

      qb.andWhere('recommendation.nitiApproved = :nitiApproved', {
        nitiApproved: true,
      });

      if (implementation === ImplementationEnum.MY) {
        qb.andWhere('recommendation.ministry_id = :ministryId', {
          ministryId,
        });
      } else if (implementation === ImplementationEnum.OTHER) {
        qb.andWhere('recommendation.primary_ministry_id = :ministryId', {
          ministryId,
        })
          .andWhere('recommendation.ministry_id IS NOT NULL')
          .andWhere('recommendation.ministry_id != :ministryId', {
            ministryId,
          });
      } else if (implementation === ImplementationEnum.TOTAL) {
        qb.andWhere(
          `
            (recommendation.primary_ministry_id = :ministryId
            OR recommendation.ministry_id = :ministryId)
            `,
          { ministryId },
        );
      }
    } else {
      if (ministryId) {
        if (implementation === ImplementationEnum.MY) {
          qb.andWhere('recommendation.ministry_id = :ministryId', {
            ministryId,
          });
        } else if (implementation === ImplementationEnum.OTHER) {
          qb.andWhere('recommendation.primary_ministry_id = :ministryId', {
            ministryId,
          })
            .andWhere('recommendation.ministry_id IS NOT NULL')
            .andWhere('recommendation.ministry_id != :ministryId', {
              ministryId,
            });
        } else if (implementation === ImplementationEnum.TOTAL) {
          qb.andWhere(
            `
            (recommendation.primary_ministry_id = :ministryId
            OR recommendation.ministry_id = :ministryId)
            `,
            { ministryId },
          );
        } else {
          qb.andWhere('recommendation.ministry_id = :ministryId', {
            ministryId,
          });
        }
      }
    }

    if (departmentId)
      qb.andWhere('recommendation.department_id = :departmentId', {
        departmentId,
      });

    if (
      !all &&
      (user.role?.roleName == RoleEnum.NITI_APPROVER ||
        user.role?.roleName === RoleEnum.NITI_DIRECTOR)
    ) {
      const userHlcIds = user.userHlcs?.map((h) => h.hlc.id) || [];
      if (hlcId && userHlcIds.length > 0 && !userHlcIds.includes(hlcId)) {
        throw new ForbiddenException('You do not have access to this HLC');
      }
      const finalHlcIds = hlcId ? [hlcId] : userHlcIds;
      // const hlcIds = user.userHlcs?.map((h) => h.hlc.id) || [];
      if (!finalHlcIds.length) {
        qb.andWhere('1 = 0');
      } else {
        qb.andWhere('recommendation.hlc_id IN (:...hlcIds)', {
          hlcIds: finalHlcIds,
        });
      }
    } else if (
      (!all && user.role?.roleName == RoleEnum.NITI_VIEWER) ||
      user.role?.roleName === RoleEnum.NFRR_VIEWER ||
      (user.ministry?.id && roleType === RoleEnum.NFRR_VIEWER)
    ) {
      const userHlcIds = user.userHlcs?.map((h) => h.hlc.id) || [];

      const finalHlcIds = hlcId ? [hlcId] : userHlcIds;

      if (finalHlcIds.length > 0) {
        qb.andWhere('recommendation.hlc_id IN (:...hlcIds)', {
          hlcIds: finalHlcIds,
        });
      }
      // else {
      //   qb.andWhere('1 = 1');
      // }
    } else {
      if (hlcId) qb.andWhere('recommendation.hlc_id = :hlcId', { hlcId });
    }

    // if (reportNumber)
    //   qb.andWhere('recommendation.report_number = :reportNumber', {
    //     reportNumber,
    //   });

    if (reportNumber?.length) {
      qb.andWhere('recommendation.report_number IN (:...reportNumber)', {
        reportNumber,
      });
    }

    if (pending) qb.andWhere('recommendation.stage = :stage', { stage });

    if (status) {
      if (status === StatusEnum.NO_ACTION) {
        qb.andWhere(
          "(recommendation.current_status IS NULL OR recommendation.current_status = '')",
        );
      } else if (
        status.toLowerCase() === ClosureStatusEnum.CLOSED.toLowerCase()
      ) {
        qb.andWhere('recommendation.closure_status = :status', {
          status: ClosureStatusEnum.CLOSED,
        });
      } else {
        qb.andWhere('recommendation.current_status = :status', { status });
      }
    }

    if (search) {
      const searchValue = `%${search.toLowerCase()}%`;

      qb.andWhere(
        `
        (
          LOWER(recommendation.name) LIKE :search
          OR LOWER(recommendation.recommendation_slug) LIKE :search
          OR LOWER(recommendation.description) LIKE :search
        )
        `,
        { search: searchValue },
      );
    }

    if (date) {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate.getTime())) {
        throw new BadRequestException('Invalid date format');
      }

      const month = parsedDate.getMonth() + 1;
      const year = parsedDate.getFullYear();

      qb.andWhere(
        `EXTRACT(MONTH FROM recommendation."created_at") = :month AND EXTRACT(YEAR FROM recommendation."created_at") = :year`,
        { month, year },
      );
    }

    if (recommendations && recommendations.length > 0) {
      qb.andWhere('recommendation.id IN (:...recs)', {
        recs: recommendations,
      });
    }

    qb.orderBy('recommendation.recommendationSlug', 'ASC');

    if (!noPagination) {
      qb.skip((page - 1) * limit).take(limit);
    }

    let [data, total] = await qb.getManyAndCount();

    data = data.map((item: any) => {
      const isClosed =
        item.closureStatus === ClosureStatusEnum.CLOSED ||
        item.currentStage === StageEnum.CLOSED_BY_HLC;

      const isTimelineCrossed =
        item.timeline && new Date(item.timeline).getTime() < Date.now();

      const isNitiApprover = user.role?.roleName === RoleEnum.NITI_APPROVER;

      const showCloseButton = isNitiApprover && !isClosed && isTimelineCrossed;

      if (item.recommendationUpdates) {
        item.recommendationUpdates.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
      }
      let action = '';
      if (
        item.closureStatus === ClosureStatusEnum.CLOSED &&
        item.currentStage === StageEnum.CLOSED_BY_HLC
      ) {
        action = RecommendationActionEnum.CLOSED;
      } else {
        switch (user.role?.roleName) {
          case RoleEnum.MINISTRY_DIRECTOR:
            if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER &&
              item.nitiApproved
            )
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            else if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;

          case RoleEnum.MINISTRY_APPROVER:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER &&
              item.nitiApproved
            )
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;

          case RoleEnum.NITI_APPROVER:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (
              item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR &&
              !item.currentStatus
            )
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (
              item.stage === RecommendationStageEnum.NITI_APPROVER ||
              item.stage === RecommendationStageEnum.NITI_DIRECTOR
            )
              action = '';
            else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
            break;

          case RoleEnum.MINISTRY_SECRETARY:
            if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
              action =
                RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
            else if (item.stage === RecommendationStageEnum.NITI_DIRECTOR)
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
            else if (item.stage === RecommendationStageEnum.NITI_APPROVER)
              action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
            break;
        }
      }
      return {
        ...item,
        action,
        closureRemark: item.closureRemark ?? null,
        closureStatus: item.closureStatus ?? null,
        showCloseButton,
      };
    });

    return noPagination
      ? data
      : { pendingCount, total, page, limit, results: data };
  }

  async findAllRaw(
    query: GetRecommendationQueryDto,
    userId: number,
    noPagination = false,
  ) {
    const {
      ministryId,
      departmentId,
      hlcId,
      status,
      search,
      date,
      reportNumber,
      page = 1,
      limit = 10,
      recommendations,
      pending,
      implementation = ImplementationEnum.MY,
    } = query;

    // Fetch user
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userHlcs', 'userHlcs.hlc'],
    });
    if (!user) throw new NotFoundException('User not found');

    let pendingCount = 0;

    if (user.ministry?.id) {
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
          ministry: user.ministry,
        },
      });
    } else {
      const hlcIds = user?.userHlcs?.map((h) => h.hlc.id) || [];
      pendingCount = await this.recommendationRepository.count({
        where: {
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
          hlc: {
            id: In(hlcIds),
          },
        },
      });
    }

    const isMinistryRole =
      user.role?.roleName === RoleEnum.MINISTRY_DIRECTOR ||
      user.role?.roleName === RoleEnum.MINISTRY_APPROVER;

    const params: any[] = [];
    const whereClauses: string[] = [];

    // Ministry/HLC filter
    if (user.ministry?.id) {
      params.push(true); // nitiApproved
      whereClauses.push(`r.niti_approved = $${params.length}`);

      const mid = user.ministry.id;
      if (implementation === ImplementationEnum.MY) {
        params.push(mid);
        whereClauses.push(`r.ministry_id = $${params.length}`);
      } else {
        params.push(mid, mid);
        whereClauses.push(`r.primary_ministry_id = $${params.length - 1}`);
        whereClauses.push(`r.ministry_id IS NOT NULL`);
        whereClauses.push(`r.ministry_id != $${params.length}`);
      }
    } else {
      if (ministryId) {
        params.push(ministryId);
        whereClauses.push(`r.ministry_id = $${params.length}`);
      }
    }

    if (
      user.role?.roleName === RoleEnum.NITI_APPROVER ||
      user.role?.roleName === RoleEnum.NITI_DIRECTOR
    ) {
      // console.log(user);
      const hlcIds = user.userHlcs?.map((h) => h.hlc.id) || [];
      console.log(hlcIds);
      if (!hlcIds.length) {
        whereClauses.push('1 = 0');
      } else {
        const placeholders = hlcIds.map(
          (_, idx) => `$${params.length + idx + 1}`,
        );
        params.push(...hlcIds);

        whereClauses.push(`r.hlc_id IN (${placeholders.join(',')})`);
        console.log('NIT -> ', whereClauses);
        console.log('params', params);
      }
    } else {
      if (hlcId) {
        params.push(hlcId);
        whereClauses.push(`r.hlc_id = $${params.length}`);
      }
    }

    // Department filter
    if (departmentId) {
      params.push(departmentId);
      whereClauses.push(`r.department_id = $${params.length}`);
    }

    // Status filter
    if (status) {
      params.push(`%${status.toLowerCase()}%`);
      whereClauses.push(`LOWER(r.current_status) LIKE $${params.length}`);
    }

    // Report number filter
    if (reportNumber) {
      params.push(reportNumber);
      whereClauses.push(`r.report_number = $${params.length}`);
    }

    // Pending / stage
    if (pending) {
      let stage = RecommendationStageEnum.NITI_APPROVER;
      switch (user.role?.roleName) {
        case RoleEnum.MINISTRY_APPROVER:
          stage = RecommendationStageEnum.MINISTRY_APPROVER;
          break;
        case RoleEnum.MINISTRY_DIRECTOR:
          stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          break;
        case RoleEnum.NITI_DIRECTOR:
          stage = RecommendationStageEnum.NITI_DIRECTOR;
          break;
      }
      params.push(stage);
      whereClauses.push(`r.stage = $${params.length}`);
    }

    // Search filter
    if (search) {
      const searchVal = `%${search.toLowerCase()}%`;
      params.push(searchVal, searchVal, searchVal, searchVal);
      whereClauses.push(`(
      LOWER(r.name) LIKE $${params.length - 3} OR
      LOWER(r.recommendation_slug) LIKE $${params.length - 2} OR
      LOWER(r.description) LIKE $${params.length - 1} OR
      LOWER(r.report_number) LIKE $${params.length}
    )`);
    }

    // Date filter
    if (date) {
      const parsedDate = new Date(date);
      if (isNaN(parsedDate.getTime()))
        throw new BadRequestException('Invalid date format');
      const month = parsedDate.getMonth() + 1;
      const year = parsedDate.getFullYear();
      params.push(month, year);
      whereClauses.push(
        `EXTRACT(MONTH FROM r.created_at) = $${params.length - 1} AND EXTRACT(YEAR FROM r.created_at) = $${params.length}`,
      );
    }

    // Recommendation IDs
    if (recommendations && recommendations.length > 0) {
      const recPlaceholders = recommendations.map(
        (_, idx) => `$${params.length + idx + 1}`,
      );
      params.push(...recommendations);
      whereClauses.push(`r.id IN (${recPlaceholders.join(',')})`);
    }

    // console.log('whereClauses', whereClauses);
    const whereSQL = whereClauses.length
      ? `WHERE ${whereClauses.join(' AND ')}`
      : '';

    const offset = (page - 1) * limit;

    // console.log('WHERE SQL ---> ', whereSQL);

    const querySQL = `
      SELECT
        r.id as id,
        r.recommendation_slug as "recommendationSlug",
        r.name as name,
        r.description as description,
        r.timeline as timeline,
        r.niti_approved as "nitiApproved",
        r.updated_timeline as "updatedTimeline",
        r.report_number as "reportNumber",
        r.reason_not_implemented as "reasonNotImplemented",
        r.current_status as "currentStatus",
        r.current_stage as "currentStage",
        r.action_taken_by_ministry as "actionTakenByMinistry",
        r.remark,
        r.niti_remark as "nitiRemark",
        r.stage,
        r.created_at as "createdAt",
        r.updated_at as "updatedAt",

        CASE
          WHEN d.id IS NULL THEN NULL
          ELSE json_build_object(
            'id', d.id,
            'name', d.name,
            'createdAt', d.created_at,
            'updatedAt', d.updated_at
          )
        END AS department,

        CASE
          WHEN m.id IS NULL THEN NULL
          ELSE json_build_object(
            'id', m.id,
            'name', m.name,
            'createdAt', m.created_at,
            'updatedAt', m.updated_at
          )
        END AS ministry,

        CASE
          WHEN pd.id IS NULL THEN NULL
          ELSE json_build_object(
            'id', pd.id,
            'name', pd.name,
            'createdAt', pd.created_at,
            'updatedAt', pd.updated_at
          )
        END AS "primaryDepartment",

        CASE
          WHEN pm.id IS NULL THEN NULL
          ELSE json_build_object(
            'id', pm.id,
            'name', pm.name,
            'createdAt', pm.created_at,
            'updatedAt', pm.updated_at
          )
        END AS "primaryMinistry",

        CASE
          WHEN h.id IS NULL THEN NULL
          ELSE json_build_object(
            'id', h.id,
            'slug', h.slug,
            'name', h.name,
            'createdAt', h.created_at,
            'updatedAt', h.updated_at
          )
        END AS hlc,

        COALESCE(
          json_agg(
            json_build_object(
              'id', ru.id,
              'reasonNotImplemented', ru.reason_not_implemented,
              'status', ru.status,
              'actionTakenByMinistry', ru.action_taken_by_ministry,
              'remark', ru.remark,
              'ministryApproverStatus', LOWER(ru.ministry_approver_status),
              'createdAt', ru.created_at,
              'updatedAt', ru.updated_at
            )
            ORDER BY ru.created_at DESC
          )
          FILTER (
            WHERE ru.id IS NOT NULL
              AND (
                ${isMinistryRole}
                OR LOWER(ru.ministry_approver_status) = 'approved'
              )
          ),
          '[]'
        ) AS "recommendationUpdates"

      FROM t_recommendation r

      LEFT JOIN t_recommendation_updates ru
        ON ru.recommendation_id = r.id

      LEFT JOIN t_departments d ON d.id = r.department_id
      LEFT JOIN t_departments pd ON pd.id = r.primary_department_id

      LEFT JOIN t_ministry m ON m.id = r.ministry_id
      LEFT JOIN t_ministry pm ON pm.id = r.primary_ministry_id

      LEFT JOIN t_hlc h ON h.id = r.hlc_id

      ${whereSQL}

      GROUP BY
        r.id,
        d.id,
        pd.id,
        m.id,
        pm.id,
        h.id

      ORDER BY
        LEFT(r.recommendation_slug, 1),
        CASE
          WHEN r.recommendation_slug LIKE '%-I/%' THEN 1
          WHEN r.recommendation_slug LIKE '%-II/%' THEN 2
          WHEN r.recommendation_slug LIKE '%-III/%' THEN 3
          WHEN r.recommendation_slug LIKE '%-IV/%' THEN 4
          WHEN r.recommendation_slug LIKE '%-V/%' THEN 5
          WHEN r.recommendation_slug LIKE '%-VI/%' THEN 6
          WHEN r.recommendation_slug LIKE '%-VII/%' THEN 7
          WHEN r.recommendation_slug LIKE '%-VIII/%' THEN 8
          WHEN r.recommendation_slug LIKE '%-IX/%' THEN 9
          WHEN r.recommendation_slug LIKE '%-X/%' THEN 10
          ELSE 99
        END,
        string_to_array(
          regexp_replace(
            split_part(r.recommendation_slug, '/', 2),
            '[^0-9.]',
            '',
            'g'
          ),
          '.'
        )::int[],
        regexp_replace(
          r.recommendation_slug,
          '.*\\(([a-z])\\)[^a-z]*$',
          '\\1'
        ),
        r.recommendation_slug

      ${noPagination ? '' : `LIMIT ${limit} OFFSET ${offset}`};
      `;

    let data = await this.recommendationRepository.query(querySQL, params);

    // Total count
    const countSQL = `SELECT COUNT(*) AS total FROM t_recommendation r ${whereSQL}`;

    data = data.map((item: any) => {
      // if (item.recommendationUpdates) {
      //   item.recommendationUpdates.sort(
      //     (a, b) =>
      //       new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      //   );
      // }
      let action = '';
      switch (user.role?.roleName) {
        case RoleEnum.MINISTRY_DIRECTOR:
          if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
          else if (
            item.stage === RecommendationStageEnum.NITI_APPROVER &&
            item.nitiApproved
          )
            action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
          else if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
            action = '';
          else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
          break;

        case RoleEnum.MINISTRY_APPROVER:
          if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
          else if (
            item.stage === RecommendationStageEnum.NITI_APPROVER &&
            item.nitiApproved
          )
            action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
          else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
            action = '';
          else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
          break;

        case RoleEnum.NITI_APPROVER:
          if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
          else if (
            item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR &&
            !item.currentStatus
          )
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
          else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
          else if (item.stage === RecommendationStageEnum.NITI_APPROVER)
            action = '';
          else action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
          break;

        case RoleEnum.MINISTRY_SECRETARY:
          if (item.stage === RecommendationStageEnum.MINISTRY_DIRECTOR)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_DIRECTOR;
          else if (item.stage === RecommendationStageEnum.MINISTRY_APPROVER)
            action = RecommendationActionEnum.CURRENTLY_WITH_MINISTRY_APPROVER;
          else if (item.stage === RecommendationStageEnum.NITI_DIRECTOR)
            action = RecommendationActionEnum.CURRENTLY_WITH_NITI_DIRECTOR;
          else if (item.stage === RecommendationStageEnum.NITI_APPROVER)
            action = RecommendationActionEnum.CURRENTLY_WITH_NITI_APPROVER;
          break;
      }
      return {
        ...item,
        action,
      };
    });

    const totalResult = await this.recommendationRepository.query(
      countSQL,
      params,
    );
    const total = parseInt(totalResult[0]?.total || 0, 10);

    return noPagination
      ? data
      : { pendingCount, total, page, limit, results: data };
  }

  async nitiApproverRequest(
    body: NitiApproverRequestDto,
    recommendationId: number,
    userId: number,
  ) {
    const { status, remarks, updatedTimeline } = body;
    let responseMessage = '';
    let trailDescription: string;
    const recommendation: Recommendation | null =
      await this.recommendationRepository.findOne({
        where: { id: recommendationId },
      });
    if (!recommendation) {
      throw new BadRequestException('Recommendation does not exist');
    }

    const currentStatus = recommendation.currentStatus;
    const currentStage = recommendation.currentStage;

    let newStage = recommendation.currentStage;
    trailDescription = TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;

    if (currentStatus) {
      if (currentStage === StageEnum.PENDING_WITH_NITI_APPROVER) {
        if (
          ![
            RequestStatusEnum.APPROVE,
            RequestStatusEnum.REJECT,
            RequestStatusEnum.FORWARDED,
          ].includes(status)
        ) {
          throw new BadRequestException('Request cannnot be fulfilled');
        }
        if (status === RequestStatusEnum.APPROVE) {
          if (
            currentStatus != StatusEnum.FULLY_IMPLEMENTED &&
            recommendation.timeline &&
            new Date(recommendation.timeline) < new Date()
          ) {
            newStage =
              StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE;
            trailDescription =
              TrailDescriptionEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE;
            responseMessage = 'Request approved successfully';
          } else {
            newStage = StageEnum.ACCEPTED_BY_NITI_APPROVER;
            trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
            responseMessage = 'Recommendation accepted successfully';
          }
          recommendation.stage = RecommendationStageEnum.NITI_APPROVER;

          // this.sendEmail()
        } else if (status === RequestStatusEnum.FORWARDED) {
          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription =
            TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage = 'Recommendation forwaded to ministry director';
        } else {
          newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
          trailDescription = TrailDescriptionEnum.MARK_NOT_COMPLETED;
          recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
          responseMessage =
            'Recommendation rejected. Forwaded to ministry director';
        }
      } else if (currentStage === StageEnum.ACCEPTED_BY_NITI_APPROVER) {
        if (status !== RequestStatusEnum.FORWARDED) {
          throw new BadRequestException('Request cannnot be fulfilled');
        }
        newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
        recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        responseMessage = 'Recommendation forwaded to ministry director';
      } else if (
        updatedTimeline &&
        currentStage ===
          StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE
      ) {
        // if (recommendation.updatedTimeline) {
        //   recommendation.timeline = recommendation.updatedTimeline;
        // }
        recommendation.updatedTimeline = updatedTimeline;
        newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.TIMELINE_UPDATED;
        recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        responseMessage = 'Timeline updated successfully';
      }
    } else {
      if (status === RequestStatusEnum.APPROVE) {
        newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_NITI_APPROVER;
        recommendation.nitiApproved = true;
        recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        responseMessage = 'Request approved successfully';
      } else {
        newStage = StageEnum.PENDING_WITH_NITI_DIRECTOR;
        trailDescription = TrailDescriptionEnum.REJECTED_BY_NITI_APPROVER;
        recommendation.stage = RecommendationStageEnum.NITI_DIRECTOR;
        responseMessage = 'Request rejected';
      }
    }

    recommendation.currentStage = newStage;
    // if (remarks) recommendation.nitiRemark = remarks.trim();
    if (status !== RequestStatusEnum.APPROVE && remarks)
      recommendation.nitiRemark = remarks.trim();
    else recommendation.nitiRemark = '';

    await this.recommendationRepository.save(recommendation);

    this.addRecommendationTrail({
      recommendationId: recommendation.id,
      userId: userId,
      currentStatus: currentStage,
      nextStatus: newStage,
      description: trailDescription,
      otherDetails: {
        body,
      },
    });
    return responseMessage;
  }

  async ministryDirectorRequest(
    body: MinistryDirectorRequestDto,
    recommendationId: number,
    userId: number,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });
    if (!user) throw new BadRequestException('User not found');

    const {
      actionTakenByMinistry,
      status,
      reasonIfNotImplemented,
      actsRulesProvisionsModified,
      otherMinistriesConsulted,
    } = body;
    // const newStatus = status;
    const newStage = StageEnum.PENDING_WITH_MINISTRY_APPROVER;
    try {
      const recommendation = await this.recommendationRepository.findOne({
        where: { id: recommendationId },
      });

      if (!recommendation) {
        throw new BadRequestException('Recommendation does not exist');
      }
      let lastStatus = recommendation.currentStatus;
      // recommendation.currentStatus = status;
      recommendation.currentStage = newStage;
      // recommendation.actionTakenByMinistry = actionTakenByMinistry?.trim();
      // recommendation.reasonNotImplemented =
      //   status === StatusEnum.FULLY_IMPLEMENTED ? null : reasonIfNotImplemented;
      recommendation.stage = RecommendationStageEnum.MINISTRY_APPROVER;
      recommendation.remark = '';
      //      console.log(actsRulesProvisionsModified);
      //      console.log(otherMinistriesConsulted);

      recommendation.actsRulesProvisionsModified =
        actsRulesProvisionsModified?.trim() || null;

      recommendation.otherMinistriesConsulted =
        otherMinistriesConsulted?.trim() || null;

      await this.recommendationRepository.save(recommendation);

      let recommendationUpdate;

      if (user.role?.roleName === RoleEnum.MINISTRY_DIRECTOR) {
        recommendationUpdate = this.recommendationUpdatesRepository.create({
          recommendation,
          reasonNotImplemented:
            status === StatusEnum.FULLY_IMPLEMENTED
              ? null
              : reasonIfNotImplemented?.trim(),
          status,
          actionTakenByMinistry: actionTakenByMinistry?.trim(),
          ministryApproverStatus: ImplementationStatusEnum.PENDING,
          user: { id: userId },
        });
      } else {
        recommendationUpdate =
          await this.recommendationUpdatesRepository.findOne({
            where: {
              recommendation: { id: recommendation.id }, // ✅ FIX
              ministryApproverStatus: ImplementationStatusEnum.PENDING,
            },
            order: { createdAt: 'DESC' },
          });

        // if (!recommendationUpdate) {
        //   throw new BadRequestException(
        //     'No pending recommendation update found for approval',
        //   );
        // }

        if (!recommendationUpdate) {
          // create a NEW pending update
          recommendationUpdate = this.recommendationUpdatesRepository.create({
            recommendation,
            status,
            actionTakenByMinistry: actionTakenByMinistry?.trim(),
            reasonNotImplemented:
              status === StatusEnum.FULLY_IMPLEMENTED
                ? null
                : reasonIfNotImplemented?.trim(),
            ministryApproverStatus: ImplementationStatusEnum.PENDING,
            user: { id: userId },
          });
        } else {
          recommendationUpdate.actionTakenByMinistry =
            actionTakenByMinistry?.trim();
          recommendationUpdate.status = status;
          recommendationUpdate.reasonNotImplemented =
            status === StatusEnum.FULLY_IMPLEMENTED
              ? null
              : reasonIfNotImplemented?.trim();
        }
      }

      await this.recommendationUpdatesRepository.save(recommendationUpdate);

      this.addRecommendationTrail({
        recommendationId: recommendation.id,
        userId: userId,
        currentStatus: lastStatus,
        nextStatus: status,
        description: TrailDescriptionEnum.MINISTRY_DIRECTOR_UPDATE,
        otherDetails: {
          body: body,
        },
      });
      return 'Request updated successfully';
    } catch (error) {
      console.error('Error updating recommendation:', error);
      throw error;
    }
  }

  isMoreThanOneMonthAway(target: any, from: Date = new Date()): boolean {
    const t = new Date(target);
    const f = new Date(from);

    f.setHours(0, 0, 0, 0);
    t.setHours(0, 0, 0, 0);

    const monthsDiff =
      (t.getFullYear() - f.getFullYear()) * 12 + (t.getMonth() - f.getMonth());

    if (monthsDiff > 1) return true;
    if (monthsDiff < 1) return false;

    return t.getDate() > f.getDate();
  }

  // 30 nov - 16
  isMoreThanTenDaysAway(target: any, from: Date = new Date()): boolean {
    const t = new Date(target);
    const f = new Date(from);

    // normalize time
    f.setHours(0, 0, 0, 0);
    t.setHours(0, 0, 0, 0);

    const diffInMs = t.getTime() - f.getTime();
    const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

    return diffInDays > 10;
  }

  async ministryApproverRequest(
    body: MinistryApproverRequestDto,
    recommendationId: number,
    userId: number,
  ) {
    const { status, remarks } = body;
    try {
      const recommendation = await this.recommendationRepository.findOne({
        where: { id: recommendationId },
      });

      if (!recommendation) {
        throw new BadRequestException('Recommendation does not exist');
      }

      const lastStage = recommendation.currentStage;

      const timeline: any =
        recommendation?.updatedTimeline || recommendation?.timeline;
      const isTenDaysAway = this.isMoreThanTenDaysAway(timeline);

      const latestUpdate = await this.recommendationUpdatesRepository.findOne({
        where: {
          recommendation: recommendation,
          // ministryApproverStatus: ImplementationStatusEnum.PENDING,
        },
        order: { createdAt: 'DESC' },
      });

      // if (!latestUpdate) {
      //   throw new BadRequestException('No Update found');
      // }

      let trailDescription = '';
      let stage = '';
      if (
        isTenDaysAway &&
        status === RequestStatusEnum.APPROVE &&
        [
          StatusEnum.FULLY_IMPLEMENTED,
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ].includes(latestUpdate?.status as StatusEnum)
      ) {
        recommendation.actionTakenByMinistry =
          latestUpdate?.actionTakenByMinistry;
        recommendation.reasonNotImplemented =
          latestUpdate?.reasonNotImplemented;
        recommendation.currentStatus = latestUpdate?.status;
        recommendation.currentStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      } else if (status === RequestStatusEnum.REJECT) {
        recommendation.currentStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.REJECTED_BY_MINISTRY_APPROVER;
      } else if (
        !isTenDaysAway &&
        status === RequestStatusEnum.APPROVE &&
        [StatusEnum.FULLY_IMPLEMENTED].includes(
          latestUpdate?.status as StatusEnum,
        )
      ) {
        recommendation.actionTakenByMinistry =
          latestUpdate?.actionTakenByMinistry;
        recommendation.reasonNotImplemented =
          latestUpdate?.reasonNotImplemented;
        recommendation.currentStatus = latestUpdate?.status;
        recommendation.currentStage = StageEnum.PENDING_WITH_NITI_APPROVER;
        stage = RecommendationStageEnum.NITI_APPROVER;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      } else {
        recommendation.currentStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
        stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
        trailDescription = TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER;
      }
      if (stage) recommendation.stage = stage;
      if (remarks) recommendation.remark = remarks.trim();
      else recommendation.remark = '';

      if (latestUpdate) {
        await this.recommendationUpdatesRepository.update(
          {
            id: latestUpdate?.id,
            ministryApproverStatus: ImplementationStatusEnum.PENDING,
          },
          {
            remark: remarks?.trim(),
            ministryApproverStatus: ImplementationStatusEnum.APPROVED,
          },
        );
      }

      await this.recommendationRepository.save(recommendation);

      this.addRecommendationTrail({
        recommendationId: recommendation.id,
        userId: userId,
        currentStatus: lastStage,
        nextStatus: stage,
        description: trailDescription,
        otherDetails: {
          body,
        },
      });
      return status === RequestStatusEnum.APPROVE
        ? 'Request approved successfully'
        : 'Request rejected successfully';
    } catch (error) {
      console.error('Error updating recommendation:', error);
      throw new BadRequestException(
        error.message || 'Failed to process ministry approver request',
      );
    }
  }

  async addRecommendationTrail(body: {
    currentStatus?: string | null | undefined;
    nextStatus: string | null | undefined;
    recommendationId: number;
    userId: number;
    description?: string | null;
    otherDetails?: Record<string, any>;
  }) {
    const {
      currentStatus,
      nextStatus,
      recommendationId,
      userId,
      description,
      otherDetails,
    } = body;

    const recommendation = await this.recommendationRepository.findOne({
      where: { id: recommendationId },
    });
    const user = await this.userRepository.findOne({
      where: { id: userId },
    });

    if (!recommendation) {
      throw new NotFoundException('Recommendation not found');
    }

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const trail = this.recommendationTrailRepository.create({
      currentStatus,
      nextStatus,
      recommendation,
      user,
      description,
      otherDetails,
    });

    return await this.recommendationTrailRepository.save(trail);
  }

  async export(query: ExportRecommendationDto, userId: number, all = false) {
    const { format } = query;
    const recommendations: any = await this.findAll(query, userId, true, all);

    const data: any[] = [];
    recommendations.forEach((r) => {
      data.push({
        'Serial No. of HLC Recommendation': r.recommendationSlug,
        Description: r.description,
        Recommendations: r.name,
        Timeline: r.timeline
          ? new Date(r.timeline).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
          : '-',
        'Primary Ministry/Department': r.primaryDepartment?.name
          ? `${r.primaryMinistry?.name} / ${r.primaryDepartment?.name}`
          : r.primaryMinistry?.name,
        'Implementing Ministry/Department': r.department?.name
          ? `${r.ministry?.name} / ${r.department?.name}`
          : r.ministry?.name,
        'Implementation Status':
          r.recommendationUpdates.length > 0
            ? r.recommendationUpdates[0].status
            : r.currentStatus,
        'Details of Action Taken(To be entered by the Ministry)':
          r.recommendationUpdates.length > 0
            ? `${new Date(
                r.recommendationUpdates[0].createdAt,
              ).toLocaleDateString('en-IN', {
                timeZone: 'Asia/Kolkata',
                month: 'short',
                day: '2-digit',
                year: 'numeric',
              })}:\n${r.recommendationUpdates[0].actionTakenByMinistry}`
            : r.actionTakenByMinistry,
        'Reason If Not Implemented':
          r.recommendationUpdates.length > 0
            ? r.recommendationUpdates[0].reasonNotImplemented
            : r.reasonNotImplemented,
        'Updated Timeline': r.updatedTimeline
          ? new Date(r.updatedTimeline).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
          : '-',
        'Closure Remarks': r.closureRemark || '-',
      });

      if (r?.recommendationUpdates && r.recommendationUpdates.length > 1) {
        const updates = r.recommendationUpdates.splice(1);
        for (let item of updates) {
          data.push({
            'Serial No. of HLC Recommendation': '',
            Description: '',
            Recommendations: '',
            Timeline: '',
            'Primary Ministry/Department': '',
            'Implementing Ministry/Department': '',
            'Implementation Status': item.status,
            'Details of Action Taken(To be entered by the Ministry)': `${new Date(
              item.createdAt,
            ).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })}:\n${item.actionTakenByMinistry}`,
            'Reason If Not Implemented': item.reasonNotImplemented,
            'Updated Timeline': '',
          });
        }
      }
    });

    if (format === FormatEnum.EXCEL) {
      const worksheet = XLSX.utils.json_to_sheet(data);
      const columnWidths = [
        { wch: 10 }, // 'Serial No. of HLC Recommendation'
        { wch: 30 }, // Description
        { wch: 20 }, // Recommendations
        { wch: 15 }, // Timeline
        { wch: 40 }, // Ministry/Department
        { wch: 20 }, // Implementation Status
        { wch: 40 }, // Details of Action Taken
        { wch: 30 }, // Reason If Not Implemented
        { wch: 15 }, // Updated Timeline
      ];
      worksheet['!cols'] = columnWidths;
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Recommendations');
      return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    }
    if (format === FormatEnum.CSV) {
      const parser = new Parser();
      const csv = parser.parse(data);
      return Buffer.from(csv);
    }
    if (format === FormatEnum.PDF) {
      return await this.generatePdf(data);
    }
  }

  // async addPageNumbers(pdfBuffer: Buffer): Promise<Buffer> {
  //   const pdfDoc = await PDFLib.load(pdfBuffer);
  //   const totalPages = pdfDoc.getPageCount();

  //   for (let i = 0; i < totalPages; i++) {
  //     const page = pdfDoc.getPage(i);

  //     const { width, height } = page.getSize();

  //     page.drawText(`Page ${i + 1} / ${totalPages}`, {
  //       x: width / 2 - 22,
  //       y: 20,
  //       size: 12,
  //     });
  //   }

  //   // Convert Uint8Array -> Buffer
  //   const modifiedPdfBytes = await pdfDoc.save();
  //   return Buffer.from(modifiedPdfBytes);
  // }

  async generatePdf(data: any[]) {
    const fonts = {
      Helvetica: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique',
      },
    };
    var printer = new PdfPrinter(fonts);

    const headers = Object.keys(data[0]);
    const body = [
      headers.map((h) => ({ text: h, bold: true })),
      ...data.map((row) => headers.map((h) => row[h] || '')),
    ];
    const docDefinition: any = {
      pageOrientation: 'landscape',
      defaultStyle: {
        font: 'Helvetica',
        fontSize: 8,
      },
      content: [
        { text: 'HLC Recommendation Report', style: 'header' },
        {
          table: {
            headerRows: 1,
            // widths: Array(headers.length).fill('*'),
            widths: [50, 80, 80, 40, 60, 60, 50, 100, 50, 40, 40],
            body: body,
          },
        },
      ],
      footer: (currentPage, pageCount) => {
        return {
          text: `Page ${currentPage} of ${pageCount}`,
          alignment: 'center',
        };
      },
      styles: {
        header: {
          fontSize: 16,
          bold: true,
          alignment: 'center',
          margin: [0, 0, 0, 20],
        },
      },
    };
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks: any[] = [];
    return new Promise((resolve) => {
      pdfDoc.on('data', (chunk: any) => chunks.push(chunk));
      pdfDoc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });
      pdfDoc.end();
    });
  }

  // async generatePdfTable(data: any[]): Promise<Buffer> {
  //   return new Promise<Buffer>((resolve, reject) => {
  //     try {
  //       // Use A3 landscape for wide tables
  //       const doc = new PDFDocument({
  //         size: 'A3',
  //         layout: 'portrait',
  //         margin: 25,
  //       });
  //       const buffers: Buffer[] = [];

  //       doc.on('data', (chunk) => buffers.push(chunk));

  //       doc.on('end', async () => {
  //         try {
  //           const pdfBuffer = Buffer.concat(buffers);

  //           // === PASS 2: Insert Page X / Y ===
  //           const finalBuffer = await this.addPageNumbers(pdfBuffer);

  //           resolve(finalBuffer);
  //         } catch (err) {
  //           reject(err);
  //         }
  //       });
  //       // doc.on('end', () => resolve(Buffer.concat(buffers)));

  //       doc.fontSize(14);

  //       // Title
  //       doc
  //         .font('Helvetica-Bold')
  //         .text('HLC Sameeksha Report', { align: 'center' });
  //       doc.moveDown();

  //       if (!data.length) {
  //         doc.fontSize(12).text('No data available', { align: 'center' });
  //         doc.end();
  //         return;
  //       }

  //       const headers = Object.keys(data[0]);
  //       const pageWidth =
  //         doc.page.width - doc.page.margins.left - doc.page.margins.right;
  //       const columnWidth = pageWidth / headers.length;
  //       let y = 50;

  //       // Draw headers
  //       let headerMaxHeight = 20;
  //       headers.forEach((key) => {
  //         const textHeight = doc.heightOfString(key ? String(key) : '', {
  //           width: columnWidth - 4,
  //         });
  //         if (textHeight + 6 > headerMaxHeight)
  //           headerMaxHeight = textHeight + 6;
  //       });
  //       let x = doc.page.margins.left;

  //       doc.font('Helvetica-Bold');
  //       headers.forEach((h) => {
  //         doc.rect(x, y, columnWidth, headerMaxHeight).stroke();
  //         doc.text(h, x + 2, y + 5, { width: columnWidth - 4 });

  //         x += columnWidth;
  //       });

  //       y += headerMaxHeight;

  //       doc.font('Helvetica');

  //       // Draw rows
  //       for (const row of data) {
  //         x = doc.page.margins.left;

  //         // Calculate max row height for wrapping text
  //         let maxHeight = 20;
  //         const cellHeights = {};
  //         headers.forEach((key) => {
  //           const textHeight = doc.heightOfString(
  //             row[key] ? String(row[key]) : '',
  //             { width: columnWidth - 4 },
  //           );
  //           cellHeights[key] = textHeight;
  //           if (textHeight + 6 > maxHeight) maxHeight = textHeight + 6;
  //         });

  //         const remaining = doc.page.height - doc.page.margins.bottom - 25 - y;
  //         let overflowKey: any = headers.find(
  //           (key) => cellHeights[key] + 6 > remaining,
  //         );
  //         if (cellHeights[overflowKey] > remaining) {
  //           const text = row[overflowKey];
  //           const fullText = text ? String(text) : '-';
  //           const allowedHeight = remaining - 6;
  //           const avgCharHeight = cellHeights[overflowKey] / fullText.length;
  //           const approxChars = Math.floor(allowedHeight / avgCharHeight) - 20;
  //           const firstPart = fullText.slice(0, approxChars);
  //           const secondPart = fullText.slice(approxChars);
  //           x = doc.page.margins.left;
  //           headers.forEach((key) => {
  //             doc.rect(x, y, columnWidth, remaining).stroke();

  //             if (key === overflowKey) {
  //               doc.text(firstPart, x + 2, y + 2, { width: columnWidth - 4 });
  //             } else {
  //               doc.text(row[key] ? String(row[key]) : '-', x + 2, y + 2, {
  //                 width: columnWidth - 4,
  //               });
  //             }

  //             x += columnWidth;
  //           });

  //           doc.addPage();
  //           x = doc.page.margins.left;
  //           y = 50;
  //           headers.forEach((key) => {
  //             const tH = doc.heightOfString(secondPart, {
  //               width: columnWidth - 4,
  //             });
  //             doc.rect(x, y, columnWidth, tH).stroke();

  //             if (key === overflowKey) {
  //               doc.text(secondPart, x + 2, y + 2, { width: columnWidth - 4 });
  //             }

  //             x += columnWidth;
  //           });
  //         } else {
  //           headers.forEach((key) => {
  //             doc.rect(x, y, columnWidth, maxHeight).stroke();
  //             doc.text(row[key] ? String(row[key]) : '-', x + 2, y + 2, {
  //               width: columnWidth - 4,
  //             });
  //             x += columnWidth;
  //           });
  //         }
  //         y += maxHeight;
  //         if (y + maxHeight > doc.page.height - doc.page.margins.bottom) {
  //           doc.addPage();
  //           y = 50;
  //         }
  //       }

  //       doc.end();
  //     } catch (err) {
  //       reject(err);
  //     }
  //   });
  // }

  async getRecommendationTrail(recommendationId: number) {
    const trails = await this.recommendationTrailRepository.find({
      where: { recommendation: { id: recommendationId } },
      relations: ['user'],
      order: { createdAt: 'ASC' },
    });

    if (!trails || trails.length === 0) {
      throw new NotFoundException('No trail found for this recommendation');
    }

    return trails.map((t) => ({
      id: t.id,
      currentStatus: t.currentStatus,
      nextStatus: t.nextStatus,
      user: t.user ? { id: t.user.id, name: t.user.name } : null,
      description: t.description,
      createdAt: t.createdAt,
    }));
  }

  async deleteRecommendation(recommendationId: number) {
    const recommendation = await this.recommendationRepository.findOne({
      where: { id: recommendationId },
    });

    if (!recommendation) {
      throw new BadRequestException('Recommendation does not exist');
    }

    await this.recommendationRepository.delete(recommendationId);

    return { message: 'Recommendation deleted successfully' };
  }

  async closeRecommendation(
    recommendationId: number,
    body: CloseRecommendationDto,
    userId: number,
  ) {
    const { closureRemark } = body;
    // const user = await this.userRepository.findOne({
    //   where: { id: userId },
    // });

    // if (!user) {
    //   throw new BadRequestException('User not found');
    // }

    const recommendation = await this.recommendationRepository.findOne({
      where: { id: recommendationId },
    });

    if (!recommendation) {
      throw new BadRequestException('Recommendation does not exist');
    }
    const lastStage = recommendation.currentStage;

    if (recommendation.closureStatus === ClosureStatusEnum.CLOSED) {
      throw new BadRequestException('Recommendation is already closed');
    }

    recommendation.currentStage = StageEnum.CLOSED_BY_HLC;
    // recommendation.stage = RecommendationStageEnum.NITI_APPROVER; // if you have this enum
    recommendation.closureStatus = ClosureStatusEnum.CLOSED;
    recommendation.closedAt = new Date();
    recommendation.closedBy = { id: userId } as User;
    recommendation.closureRemark = closureRemark?.trim() || '';

    await this.recommendationRepository.save(recommendation);

    await this.addRecommendationTrail({
      recommendationId,
      userId,
      currentStatus: lastStage,
      nextStatus: StageEnum.CLOSED_BY_HLC,
      description: TrailDescriptionEnum.CLOSED_BY_HLC,
      otherDetails: {
        body,
      },
    });

    return { message: 'Recommendation closed successfully' };
  }

  /*   async generatePresignedUrls(
    recommendationId: number,
    files: { fileName: string; mimeType: string }[],
  ) {
    const results: any[] = [];

    for (const file of files) {
      const key = `recommendations/${recommendationId}/${uuid()}-${file.fileName}`;

      const command = new PutObjectCommand({
        Bucket: this.awsBucket,
        Key: key,
        ContentType: file.mimeType,
      });

      const uploadUrl = await getSignedUrl(this.s3, command, {
        expiresIn: 60 * 10,
      });

      results.push({
        fileName: file.fileName,
        key,
        uploadUrl,
        finalUrl: `https://${this.awsBucket}.s3.${this.awsRegion}.amazonaws.com/${key}`,
      });
    }

    return results;
  }

  async saveFiles(
    recommendationId: number,
    files: {
      fileName: string;
      fileKey: string;
      fileSize: number;
    }[],
  ) {
    const saved: any[] = [];

    for (const f of files) {
      const fileRecord = await this.recommendationFileRepository.save({
        recommendationId,
        fileName: f.fileName,
        s3Key: f.fileKey,
        fileSize: f.fileSize,
        url: `https://${this.awsBucket}.s3.${this.awsRegion}.amazonaws.com/${f.fileKey}`,
      });

      saved.push(fileRecord);
    }

    return saved;
  }

  async deleteFile(fileId: number) {
    const file = await this.recommendationFileRepository.findOne({
      where: { id: fileId },
    });

    if (!file) {
      throw new NotFoundException('File not found');
    }

    await this.s3.send(
      new DeleteObjectCommand({
        Bucket: this.awsBucket,
        Key: file.s3Key,
      }),
    );

    await this.recommendationFileRepository.delete(fileId);

    return { message: 'File deleted successfully' };
  }

  async deleteTempFile(key: string) {
    if (!key) {
      throw new BadRequestException('File key is required');
    }

    const command = new DeleteObjectCommand({
      Bucket: this.awsBucket,
      Key: key,
    });

    await this.s3.send(command);

    return { message: 'Temp file deleted successfully', key };
  }
 */
  async bulkApproveNiti(data: BulkApproveDto, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role', 'userHlcs', 'userHlcs.hlc'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (!user.userHlcs) {
      throw new NotFoundException('User ministry not found');
    }
    let ids = data.recommendations;

    let recommendations: any[];
    const hlcIds: any = user?.userHlcs?.map((h) => h.hlc.id) || [];

    if (!ids || ids.length === 0) {
      recommendations = await this.recommendationRepository.find({
        where: {
          nitiApproved: false,
          hlc: In(hlcIds),
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
        },
      });
    } else {
      recommendations = await this.recommendationRepository.find({
        where: {
          id: In(ids),
          hlc: In(hlcIds),
          nitiApproved: false,
          currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
        },
      });
    }
    ids = recommendations.map((r) => r.id);

    if (recommendations.length === 0) {
      return {
        message: 'No recommendations available for approval',
        total: 0,
      };
    }

    await this.recommendationRepository.update(
      { id: In(ids) },
      {
        nitiApproved: true,
        currentStage: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
        stage: RecommendationStageEnum.MINISTRY_DIRECTOR,
        updatedAt: new Date(),
      },
    );

    for (const rec of recommendations) {
      await this.addRecommendationTrail({
        recommendationId: rec.id,
        userId,
        currentStatus: StageEnum.PENDING_WITH_NITI_APPROVER,
        nextStatus: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
        description: TrailDescriptionEnum.APPROVED_BY_NITI_APPROVER,
        otherDetails: {},
      });
    }

    return {
      message: 'Bulk approval completed successfully',
      total: ids.length,
    };
  }

  async bulkApproveMinistry(data: BulkApproveDto, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (!user.ministry) {
      throw new NotFoundException('User ministry not found');
    }

    let ids = data.recommendations;

    let recommendations: any[];

    if (!ids || ids.length === 0) {
      recommendations = await this.recommendationRepository.find({
        where: {
          ministry: user?.ministry,
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
        },
      });

      if (recommendations.length === 0) {
        return {
          message: 'No recommendations available for approval',
          total: 0,
        };
      }

      ids = recommendations.map((r) => r.id);
    } else {
      recommendations = await this.recommendationRepository.find({
        where: {
          id: In(ids),
          ministry: user?.ministry,
          nitiApproved: true,
          currentStage: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
        },
      });

      if (recommendations.length !== ids.length) {
        throw new BadRequestException(
          'Some recommendations do not exist, are already approved, or are not in the correct stage',
        );
      }
    }

    await this.recommendationRepository.update(
      { id: In(ids) },
      {
        currentStage: StageEnum.PENDING_WITH_NITI_APPROVER,
        stage: RecommendationStageEnum.NITI_APPROVER,
        updatedAt: new Date(),
      },
    );

    for (const rec of recommendations) {
      await this.addRecommendationTrail({
        recommendationId: rec.id,
        userId,
        currentStatus: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
        nextStatus: StageEnum.PENDING_WITH_NITI_APPROVER,
        description: TrailDescriptionEnum.APPROVED_BY_MINISTRY_APPROVER,
        otherDetails: {},
      });
    }

    return {
      message: 'Bulk approval completed successfully',
      total: ids.length,
    };
  }

  /*   async fixRecommendationUpdates() {
    const ministryRecommendations = await this.recommendationRepository.find({
      where: {
        stage: In([
          RecommendationStageEnum.MINISTRY_APPROVER,
          RecommendationStageEnum.MINISTRY_DIRECTOR,
        ]),
        currentStatus: IsNull(),
        actionTakenByMinistry: IsNull(),
      },
    });

    for (const rec of ministryRecommendations) {
      // 🔴 Skip if updates already exist for this recommendation
      const existingUpdatesCount =
        await this.recommendationUpdatesRepository.count({
          where: { recommendation: { id: rec.id } },
        });

      console.log('Count ----> ', existingUpdatesCount);

      // if (existingUpdatesCount > 0) continue;

      const trail = await this.recommendationTrailRepository.find({
        where: {
          recommendation: { id: rec.id },
          description: 'Ministry director updated status of recommendation',
        },
        order: { createdAt: 'DESC' },
      });
      console.log('Length', trail.length);
      console.log(trail[0]);
      if (!trail || trail.length === 0) {
        // const recUpdate = this.recommendationUpdatesRepository.create({
        //   recommendation: rec,
        //   user: user,
        //   ministryApproverStatus: ImplementationStatusEnum.APPROVED,
        // });
      } else {
        for (let i = 0; i < 1; i++) {
          const t = trail[i];

          console.log(typeof t.otherDetails);
          console.log(t.otherDetails);

          // const recUpdate = this.recommendationUpdatesRepository.create({
          //   recommendation: rec,
          //   user: t.user,
          //   ministryApproverStatus:
          //     i === 0
          //       ? ImplementationStatusEnum.PENDING
          //       : ImplementationStatusEnum.APPROVED,
          // });

          // await this.recommendationUpdatesRepository.save(recUpdate);
        }
      }
    }
  }
 */
  // if (currentStatus) {
  //   if (
  //     currentStatus === StatusEnum.FULLY_IMPLEMENTED &&
  //     currentStage === StageEnum.PENDING_WITH_NITI_APPROVER
  //   ) {
  //     if (
  //       ![
  //         RequestStatusEnum.COMPLETED,
  //         RequestStatusEnum.NOT_COMPLETED,
  //       ].includes(status)
  //     ) {
  //       throw new BadRequestException(
  //         'Invalid status for fully implemented recommendation',
  //       );
  //     }

  //     if (status === RequestStatusEnum.COMPLETED) {
  //       newStage = StageEnum.ACCEPTED_BY_NITI_APPROVER;
  //       trailDescription = TrailDescriptionEnum.MARK_COMPLETED;
  //       responseMessage = 'Recommendation accepted successfully';
  //       // this.sendEmail()
  //     } else if (status === RequestStatusEnum.FORWARDED) {
  //       newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //       trailDescription = TrailDescriptionEnum.MARK_NOT_COMPLETED;
  //       recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //       responseMessage = 'Recommendation forwaded to ministry director';
  //     } else {
  //       newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //       trailDescription = TrailDescriptionEnum.MARK_NOT_COMPLETED;
  //       recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //       responseMessage =
  //         'Recommendation rejected. Forwaded to ministry director';
  //     }
  //   } else if (
  //     updatedTimeline &&
  //     recommendation.currentStage ===
  //       StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE
  //   ) {
  //     if (recommendation.updatedTimeline) {
  //       recommendation.timeline = recommendation.updatedTimeline;
  //     }
  //     recommendation.updatedTimeline = updatedTimeline;
  //     newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //     trailDescription = TrailDescriptionEnum.TIMELINE_UPDATED;
  //     recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //     responseMessage = 'Timeline updated successfully';
  //   } else {
  //     if (
  //       ![RequestStatusEnum.APPROVE, RequestStatusEnum.REJECT].includes(
  //         status,
  //       )
  //     ) {
  //       throw new BadRequestException(
  //         'Invalid status for fully implemented recommendation',
  //       );
  //     }
  // if (
  //   recommendation.timeline &&
  //   new Date(recommendation.timeline) < new Date() &&
  //   status === RequestStatusEnum.APPROVE
  // ) {
  //   newStage = StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE;
  //   trailDescription =
  //     TrailDescriptionEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE;
  //   recommendation.stage = RecommendationStageEnum.NITI_APPROVER;
  //   responseMessage = 'Request approved successfully';
  // } else if (status === RequestStatusEnum.APPROVE) {
  //       newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //       trailDescription =
  //         TrailDescriptionEnum.FORWARDED_TO_MINISTRY_DIRECTOR;
  //       recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //       responseMessage = 'Request approved successfully';
  //     } else {
  //       newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //       trailDescription = TrailDescriptionEnum.REJECTED_BY_NITI_APPROVER;
  //       recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //       responseMessage = 'Request rejected';
  //     }
  //   }
  // } else {
  //   if (status === RequestStatusEnum.APPROVE) {
  //     newStage = StageEnum.PENDING_WITH_MINISTRY_DIRECTOR;
  //     trailDescription = TrailDescriptionEnum.APPROVED_BY_NITI_APPROVER;
  //     recommendation.nitiApproved = true;
  //     recommendation.stage = RecommendationStageEnum.MINISTRY_DIRECTOR;
  //     responseMessage = 'Request approved successfully';
  //   } else {
  //     trailDescription = TrailDescriptionEnum.REJECTED_BY_NITI_APPROVER;
  //     newStage = StageEnum.PENDING_WITH_NITI_DIRECTOR;
  //     recommendation.stage = RecommendationStageEnum.NITI_DIRECTOR;
  //     responseMessage = 'Request rejected';
  //   }
  // }

  async getDistinctReportNumbers(hlcId?: number) {
    const query = this.recommendationRepository
      .createQueryBuilder('r')
      .select('DISTINCT r.reportNumber', 'reportNumber')
      .where('r.reportNumber IS NOT NULL')
      .andWhere("r.reportNumber != ''");

    if (hlcId) {
      query.andWhere('r.hlc_id = :hlcId', { hlcId });
    }

    const reports = await query.orderBy('r.reportNumber', 'ASC').getRawMany();

    return reports.map(
      (item, index) => `Report ${index + 1}: ${item.reportNumber}`,
    );
  }

  /*   async fixRecUpdate() {
    const recommendations = await this.recommendationRepository.find();
    console.log('Total recommendations ---> ', recommendations.length);
    // const recs = recommendations.slice(0,5);
    let count = 0;
    for (const rec of recommendations) {
      const update = await this.recommendationUpdatesRepository.findOne({
        where: {
          recommendation: rec,
          ministryApproverStatus: 'approved',
        },
        order: {
          createdAt: 'DESC', // latest record
        },
      });

      if (!update) continue;

      // compare status
      if (update.status !== '' && update.status !== rec.currentStatus) {
        count += 1;
        console.log('---------------------------------------');
        console.log('RecommendationId --->', rec.id);
        console.log('New Status ---> ', update.status);
        console.log(
          'New actionTakenByMinistry ---> ',
          update.actionTakenByMinistry,
        );
        console.log(
          'New reasonNotImplemented ---> ',
          update.reasonNotImplemented,
        );

        console.log('Old Status ---->', rec.currentStatus);
        console.log(
          'Old actionTakenByMinistry ---->',
          rec.actionTakenByMinistry,
        );
        console.log('Old reasonNotImplemented ---->', rec.reasonNotImplemented);

        console.log('---------------------------------------');
        rec.currentStatus = update.status;
        rec.actionTakenByMinistry = update.actionTakenByMinistry;
        rec.reasonNotImplemented = update.reasonNotImplemented;
        rec.updatedAt = new Date();

        await this.recommendationRepository.save(rec);
      }
    }
    return count;
  }
 */
}

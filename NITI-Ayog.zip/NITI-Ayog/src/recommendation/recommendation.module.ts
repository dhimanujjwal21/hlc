import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Ministry } from 'src/entities/ministry.entity';
import { JwtService } from '@nestjs/jwt';
import { Recommendation } from 'src/entities/recommendation.entity';
import { RecommendationController } from './recommendation.controller';
import { RecommendationService } from './recommendation.service';
import { Departments } from 'src/entities/departments.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import { AuditLogs } from 'src/entities/audit.entity';
import { RecommendationFile } from 'src/entities/recommendation-file.entity';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      User,
      Recommendation,
      Departments,
      Ministry,
      Hlc,
      RecommendationTrail,
      AuditLogs,
      RecommendationFile,
      RecommendationUpdates
    ]),
  ],
  controllers: [RecommendationController],
  providers: [RecommendationService, JwtService],
  exports: [],
})
export class RecommendationModule {}

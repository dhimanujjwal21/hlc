import {
  Body,
  Controller,
  Delete,
  ForbiddenException,
  Get,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { RecommendationService } from './recommendation.service';
import {
  BulkApproveDto,
  CloseRecommendationDto,
  CreateRecommendationDto,
  ExportRecommendationDto,
  GetRecommendationQueryDto,
  MinistryApproverRequestDto,
  MinistryDirectorRequestDto,
  NitiApproverRequestDto,
  PresignFileDto,
  SaveFilesDto,
} from './dto/recommendation.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
@ApiTags('Recommendation')
@Controller({
  path: 'recommendation',
  version: '1',
})
export class RecommendationController {
  constructor(private readonly recommendationService: RecommendationService) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_RECOMMENDATION)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Create a new recommendation' })
  async createRecommendation(@Req() req, @Body() dto: CreateRecommendationDto) {
    const userId = req?.user?.id;
    const recommendation =
      await this.recommendationService.createRecommendation(dto, userId);
    return {
      message: 'Recommendation created successfully',
      data: recommendation,
    };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('bulk-approve-niti')
  async bulkApproveNiti(@Req() req, @Body() body: BulkApproveDto) {
    const userId = req?.user?.id;
    return await this.recommendationService.bulkApproveNiti(body, userId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('bulk-approve-ministry')
  async bulkApproveMinistry(@Req() req, @Body() body: BulkApproveDto) {
    const userId = req?.user?.id;
    return await this.recommendationService.bulkApproveMinistry(body, userId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get()
  @ApiOperation({ summary: 'Get list of recommendations' })
  async getRecommendations(
    @Req() req,
    @Query() query: GetRecommendationQueryDto,
  ) {
    const userId = req.user?.id;
    return this.recommendationService.findAll(query, userId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('list')
  @ApiOperation({ summary: 'Get list of recommendations' })
  async getRecommendationList(
    @Req() req,
    @Query() query: GetRecommendationQueryDto,
  ) {
    if (!req.user?.viewingAccess) {
      throw new ForbiddenException('You are not allowed to access this.');
    }
    const userId = req.user?.id;
    return this.recommendationService.findAll(query, userId, false, true);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('list/export')
  @ApiOperation({ summary: 'Export recommendations (Excel, CSV, PDF)' })
  async exportRecommendationList(
    @Req() req,
    @Body() query: ExportRecommendationDto,
    @Res() res,
  ) {
    if (!req.user?.viewingAccess) {
      throw new ForbiddenException('You are not allowed to access this.');
    }
    const userId = req.user?.id;
    const buffer = await this.recommendationService.export(query, userId, true);

    let filename: string = '',
      contentType: string = '';
    switch (query.format) {
      case 'csv':
        filename = 'recommendations.csv';
        contentType = 'text/csv';
        break;

      case 'excel':
        filename = 'recommendations.xlsx';
        contentType =
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;

      case 'pdf':
        filename = 'recommendations.pdf';
        contentType = 'application/pdf';
        break;

      default:
        break;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    return res.send(buffer);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('export')
  @ApiOperation({ summary: 'Export recommendations (Excel, CSV, PDF)' })
  async exportRecommendations(
    @Req() req,
    @Body() query: ExportRecommendationDto,
    @Res() res,
  ) {
    const userId = req.user?.id;
    const buffer = await this.recommendationService.export(query, userId);

    let filename: string = '',
      contentType: string = '';
    switch (query.format) {
      case 'csv':
        filename = 'recommendations.csv';
        contentType = 'text/csv';
        break;

      case 'excel':
        filename = 'recommendations.xlsx';
        contentType =
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;

      case 'pdf':
        filename = 'recommendations.pdf';
        contentType = 'application/pdf';
        break;

      default:
        break;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    return res.send(buffer);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.NITI_APPROVER_REQUEST)
  @ApiBearerAuth()
  @Put('niti-approver-request/:id')
  @ApiParam({ name: 'id', type: Number, description: 'Recommendation ID' })
  @ApiOperation({
    summary: 'Approve or reject a recommendation by NITI Approver',
  })
  @ApiParam({ name: 'id', type: Number, description: 'Recommendation ID' })
  async nitiApproverRequest(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: NitiApproverRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.nitiApproverRequest(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.MINISTRY_DIRECTOR_REQUEST)
  @Put('ministry-director-request/:id')
  @ApiOperation({
    summary: 'Submit Ministry Director’s response for a recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async ministryDirectorRequest(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: MinistryDirectorRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.ministryDirectorRequest(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.MINISTRY_APPROVER_REQUEST)
  @Put('ministry-approver-request/:id')
  @ApiOperation({
    summary: 'Submit Ministry Approver’s review/decision on a recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async ministryApproverRequest(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() body: MinistryApproverRequestDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.ministryApproverRequest(
      body,
      id,
      userId,
    );
    return { message };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.CLOSE_RECOMMENDATION)
  @Put('close-recommendation/:id')
  @ApiOperation({
    summary: 'Submit Ministry Approver’s review/decision on a recommendation',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID',
    example: 101,
  })
  async closeRecommendation(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() bodyData: CloseRecommendationDto,
  ) {
    const userId = req.user?.id;
    const message = await this.recommendationService.closeRecommendation(
      id,
      bodyData,
      userId,
    );
    return message;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @PermissionsDecorator(PermissionsEnum.NITI_APPROVER_REQUEST)
  @Get('trail/:id')
  @ApiOperation({ summary: 'Get recommendation trail by recommendation ID' })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Recommendation ID to fetch trail for',
    example: 12,
  })
  async getRecommendationTrail(@Param('id', ParseIntPipe) id: number) {
    return this.recommendationService.getRecommendationTrail(id);
  }

  @ApiOperation({ summary: 'Delete a recommendation by ID' })
  @PermissionsDecorator(PermissionsEnum.NITI_APPROVER_REQUEST)
  @PermissionsDecorator(PermissionsEnum.DELETE_RECOMMENDATION)
  @Delete(':id')
  @UseGuards(AuthGuard)
  async deleteRecommendation(@Param('id', ParseIntPipe) id: number) {
    return this.recommendationService.deleteRecommendation(id);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_RECOMMENDATION)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Update an existing recommendation' })
  @ApiParam({ name: 'id', type: Number, description: 'Recommendation ID' })
  async updateRecommendation(
    @Req() req,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: CreateRecommendationDto,
  ) {
    const userId = req?.user?.id;
    await this.recommendationService.updateRecommendation(id, dto, userId);
    return { message: 'Recommendation updated successfully' };
  }

  /*   @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post(':id/files/presign')
  @ApiOperation({ summary: 'Generate presigned URLs for uploading files' })
  @ApiParam({ name: 'id', type: Number })
  @ApiBody({
    schema: {
      example: {
        files: [
          {
            fileName: 'document.pdf',
            mimeType: 'application/pdf',
            size: 200000,
          },
        ],
      },
    },
  })
  async generatePresignedUrls(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: PresignFileDto,
  ) {
    return this.recommendationService.generatePresignedUrls(id, body.files);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post(':id/files')
  @ApiOperation({ summary: 'Save metadata of uploaded files to DB' })
  @ApiParam({ name: 'id', type: Number })
  async saveFiles(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: SaveFilesDto,
  ) {
    return this.recommendationService.saveFiles(id, body.files);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Delete('files/:fileId')
  @ApiOperation({ summary: 'Delete a file from S3 and DB' })
  @ApiParam({ name: 'fileId', type: Number })
  async deleteFile(@Param('fileId', ParseIntPipe) fileId: number) {
    return this.recommendationService.deleteFile(fileId);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: 'key', type: String })
  @Delete('temp-file/:key')
  async deleteTempFile(@Param('key') key: string) {
    return this.recommendationService.deleteTempFile(key);
  }
 */
  /*   @Post('fix-updates')
  @UseGuards(AuthGuard)
  async fixRecommendationUpdates() {
    return this.recommendationService.fixRecommendationUpdates();
  }
 */
  @Get('report-numbers-list')
  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get distinct report numbers for a given HLC' })
  async getDistinctReportNumbers(@Query('hlcId') hlcId?: number) {
    return this.recommendationService.getDistinctReportNumbers(
      hlcId ? Number(hlcId) : undefined,
    );
  }

  /*   @Get('fix-recommendation-update')
  async fixRecUpdate() {
    const result = await this.recommendationService.fixRecUpdate();
    return { message: `Total fixed recom ${result}`}
  } */
}

import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
2;
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { ResponseInterceptor } from './interceptor/response.interceptor';
import { AllExceptionsFilter } from './filters/all-exceptions.filter';

async function bootstrap() {
  // rawBody is needed to verify HMAC signatures on e-Office requests
  const app = await NestFactory.create(AppModule, { rawBody: true });
  const configService = app.get(ConfigService);
  const frontendUrl = configService.get<string>('FRONTEND_URL');
  const localhostUrl = configService.get<string>('LOCALHOST_URL');
  const env = configService.get<string>('APP_ENV');
  app.setGlobalPrefix('api');
  app.enableVersioning({
    type: VersioningType.URI,
  });
  app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
  app.useGlobalInterceptors(new ResponseInterceptor());
  app.useGlobalFilters(new AllExceptionsFilter());
  const allowedOrigins =
    env === 'staging'
      ? [
          ...(localhostUrl ? [new URL(localhostUrl).origin] : []),
          ...(frontendUrl ? [new URL(frontendUrl).origin] : []),
        ]
      : frontendUrl
        ? [new URL(frontendUrl).origin]
        : [];
  app.enableCors({
    origin: allowedOrigins,
  });
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: false,
    }),
  );
  const config = new DocumentBuilder()
    .setTitle('Viksit Bharat')
    .setDescription('API documentation for viksit bharat')
    .setVersion('1.0')
    .addBearerAuth({
      type: 'http',
      scheme: 'bearer',
      bearerFormat: 'JWT',
      name: 'Authorization',
      in: 'header',
    })
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api-docs', app, document);
  const port = configService.get<number>('APP_PORT') ?? 3000;
  await app.listen(port);
}
bootstrap();

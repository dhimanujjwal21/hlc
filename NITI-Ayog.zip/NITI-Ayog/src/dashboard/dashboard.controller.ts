import {
  Controller,
  ForbiddenException,
  Get,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { DashboardService } from './dashboard.service';
import { MinistryReportDto } from './dto/dashboard.dto';
import { AuthGuard } from 'src/guards/auth.guard';

@ApiTags('Dashboard')
@Controller({
  path: 'dashboard',
  version: '1',
})
export class DeshboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  private ensureDashboardAccess(user: any) {
    if (!user?.dashboardView) {
      throw new ForbiddenException(
        'You are not allowed to access the dashboard',
      );
    }
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('summary')
  async summar(@Req() req) {
    this.ensureDashboardAccess(req.user);
    const summary = await this.dashboardService.getSummary(req.user.ministryId);
    return summary;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('report')
  async report(@Req() req, @Query() dto: MinistryReportDto) {
    this.ensureDashboardAccess(req.user);
    const overAllReport = await this.dashboardService.getOverallCompliance(req.user.ministryId);
    const hlcReport = await this.dashboardService.getHLCCompliance(req.user.ministryId);

    return { overAllReport, hlcReport };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('ministry-compliance-report')
  async ministryComplianceReport(@Req() req, @Query() dto: MinistryReportDto) {
    this.ensureDashboardAccess(req.user);
    const ministryId = req.user.ministryId ?? dto.ministryId;
    const ministryRequest = req.user.ministryId != null;
    return this.dashboardService.getMinistryCompliance(ministryId, ministryRequest);
  }


  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('delayed-report')
  async delayedReport(@Req() req) {
    this.ensureDashboardAccess(req.user);
    const delayedReport =
      await this.dashboardService.getDelayedRecommendationBuckets(req.user.ministryId);
    return delayedReport;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('ministry-wise-report')
  async ministryWiseReport(@Req() req) {
    this.ensureDashboardAccess(req.user);
    const ministryReport =
      await this.dashboardService.getStatusWiseMinistryCounts(req.user.ministryId);
    return ministryReport;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('ministry-delay-report')
  async ministryDelayReport(@Req() req) {
    this.ensureDashboardAccess(req.user);
    const delayedMinistryReport =
      await this.dashboardService.getDelayedRecommendationByMinistry(req.user.ministryId);
    return delayedMinistryReport;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('hlc-delayed-report')
  async hlcDelayedReport(@Req() req) {
    this.ensureDashboardAccess(req.user);
    const delayedReport =
      await this.dashboardService.getDelayedBucketsByHLC(req.user.ministryId);
    return delayedReport;
  }
}

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import {
  RecommendationStageEnum,
  StageEnum,
  StatusEnum,
} from 'src/constants/enums';
import { Departments } from 'src/entities/departments.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { User } from 'src/entities/users.entity';
import { Repository } from 'typeorm';

@Injectable()
export class DashboardService {
  constructor(
    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,

    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,

    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,
  ) {}

  async getSummary(ministryId: any) {

    // 1. Fetch all HLC slugs
    const allHLC = await this.hlcRepository
      .createQueryBuilder('hlc')
      .select('hlc.slug', 'hlcSlug')
      .orderBy('hlc.slug', 'ASC')
      .getRawMany();

    const allSlugs = allHLC.map((h) => h.hlcSlug);

    let total = 0;
    // Helper: convert raw rows → map
    const toMap = (arr) => {
      const map = {};
      arr.forEach((row) => (map[row.hlcSlug] = Number(row.count)));
      return map;
    };

    const buildStage2Breakdown = (initialMap, actionMap) =>
      allSlugs.map((slug) => {
        const i = initialMap[slug] ?? 0;
        const a = actionMap[slug] ?? 0;

        return {
          hlcSlug: `HLC-${slug}`,
          initial: i,
          actionTaken: a,
          total: i + a,
        };
      });

    // Helper: build array for each HLC with zero fallback
    const buildHLCArray = (map) =>
      allSlugs.map((slug) => ({
        hlcSlug: `HLC-${slug}`,
        count: map[slug] ?? 0,
      }));

    // Helper: compute stage total
    const computeTotal = (map) =>
      allSlugs.reduce((acc, slug) => acc + (map[slug] ?? 0), 0);

    // Helper: generic query builder
    const runQuery = async (whereFn?: (qb) => void) => {
      const qb = this.recommendationRepository
        .createQueryBuilder('r')
        .leftJoin('r.hlc', 'hlc')
        .select('hlc.slug', 'hlcSlug')
        .addSelect('COUNT(r.id)', 'count')
        .groupBy('hlc.slug')
        .orderBy('hlc.slug', 'ASC');

      if (whereFn) whereFn(qb);

      return await qb.getRawMany();
    };

    // STAGE-WISE QUERIES
    const stage1Result = await runQuery((qb) =>
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_NITI_DIRECTOR,
      }),
    );

    const stage2Result = await runQuery((qb) =>
      qb
        .andWhere('r.current_stage IN (:...s)', {
          s: [StageEnum.PENDING_WITH_NITI_APPROVER],
        })
        .andWhere("(r.current_status IS NULL OR r.current_status = '')"),
    );

    const stage21Result = await runQuery((qb) =>
      qb
        .andWhere('r.current_stage IN (:...s)', {
          s: [
            StageEnum.PENDING_WITH_NITI_APPROVER,
            StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE,
          ],
        })
        .andWhere("(r.current_status IS NOT NULL AND r.current_status != '')"),
    );

    const stage3Result = await runQuery((qb) => {
      qb.where('r.niti_approved = true');
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
      });
    });

    const stage4Result = await runQuery((qb) => {
      qb.where('r.niti_approved = true');
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
      });
    });

    const stage5Result = await runQuery((qb) => {
      qb.where('r.niti_approved = true');
      qb.andWhere('r.current_status = :status', {
        status: StatusEnum.FULLY_IMPLEMENTED,
      });
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      });
    });

    // Convert each to maps
    const m1 = toMap(stage1Result);
    const m2 = toMap(stage2Result);
    const m21 = toMap(stage21Result);
    const m3 = toMap(stage3Result);
    const m4 = toMap(stage4Result);
    const m5 = toMap(stage5Result);

    const stage1Total = computeTotal(m1);
    const stage2Total = computeTotal(m2);
    const stage21Total = computeTotal(m21);
    const stage3Total = computeTotal(m3);
    const stage4Total = computeTotal(m4);
    const stage5Total = computeTotal(m5);

    // Final JSON
    return {
      total:
        stage1Total +
        stage2Total +
        stage21Total +
        stage3Total +
        stage4Total +
        stage5Total,
      stage1: {
        key: 'Stage 1',
        stageName: StageEnum.PENDING_WITH_NITI_DIRECTOR,
        total: stage1Total,
        hlc: buildHLCArray(m1),
      },
      stage2: {
        key: 'Stage 2',
        stageName: StageEnum.PENDING_WITH_NITI_APPROVER,
        total: stage2Total + stage21Total,
        initial: {
          total: stage2Total,
          hlc: buildHLCArray(m2),
        },
        actionTaken: {
          total: stage21Total,
          hlc: buildHLCArray(m21),
        },
        hlc: buildStage2Breakdown(m2, m21),
      },
      stage3: {
        key: 'Stage 3',
        stageName: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
        total: stage3Total,
        hlc: buildHLCArray(m3),
      },
      stage4: {
        key: 'Stage 4',
        stageName: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
        total: stage4Total,
        hlc: buildHLCArray(m4),
      },
      stage5: {
        key: 'Stage 5',
        stageName: StageEnum.ACCEPTED_BY_NITI_APPROVER,
        total: stage5Total,
        hlc: buildHLCArray(m5),
      },
    };
  }

  async getOverallCompliance() {
    // 1. Total recommendations
    const totalRecommendations = await this.recommendationRepository
      .createQueryBuilder('r')
      .getCount();

    // 2. Fully implemented + accepted by NITI Approver
    const fullyImplementedCount = await this.recommendationRepository
      .createQueryBuilder('r')
      .where('r.current_status = :currentStatus', {
        currentStatus: StatusEnum.FULLY_IMPLEMENTED,
      })
      .andWhere('r.current_stage = :currentStage', {
        currentStage: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      })
      .getCount();

    const statusCase = `
    CASE
      WHEN r.current_status IS NULL OR r.current_status = ''
      THEN 'No Action'
      ELSE r.current_status
    END
  `;

    // 3. Get counts for each status (WITH ministry filter)
    const raw = await this.recommendationRepository
      .createQueryBuilder('r')
      .select(`${statusCase}`, 'currentStatus')
      .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count')
      .groupBy(statusCase)
      .getRawMany();

    // 4. Total = sum of all status counts
    const total = raw.reduce((sum, r) => sum + Number(r.count), 0);

    // 5. Build lookup
    const lookup: Record<string, any> = {};
    raw.forEach((row) => {
      const key = row.currentStatus.toLowerCase();
      lookup[key] = {
        currentStatus: row.currentStatus,
        count: Number(row.count),
        percentage: total ? ((row.count / total) * 100).toFixed(2) + '%' : '0%',
      };
    });

    // 6. Ensure all statuses appear
    const result = Object.values(StatusEnum).map((status) => {
      const key = status.toLowerCase();
      return (
        lookup[key] || {
          currentStatus: status,
          count: 0,
          percentage: '0%',
        }
      );
    });

    return {
      total: totalRecommendations,
      result,
      accepted: fullyImplementedCount,
      acceptedPercentage: (fullyImplementedCount / totalRecommendations) * 100,
    };
  }

  async calculateCompliance(whereBuilder: (qb: any) => any) {
    const statusCase = `
      CASE
        WHEN r.current_status IS NULL OR r.current_status = ''
        THEN 'No Action'
        ELSE r.current_status
      END
    `;

    // 3. Status-wise counts
    const raw = await whereBuilder(
      this.recommendationRepository
        .createQueryBuilder('r')
        .select(statusCase, 'currentStatus')
        .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count')
        .groupBy(statusCase),
    ).getRawMany();

    // 4. Total
    const total = raw.reduce((sum, r) => sum + Number(r.count), 0);

    // 5. Lookup map
    const lookup: Record<string, any> = {};
    raw.forEach((row) => {
      const key = row.currentStatus.toLowerCase();
      lookup[key] = {
        currentStatus: row.currentStatus,
        count: Number(row.count),
        percentage: total ? ((row.count / total) * 100).toFixed(2) + '%' : '0%',
      };
    });

    // 6. Ensure all statuses exist
    const result = Object.values(StatusEnum).map((status) => {
      const key = status.toLowerCase();
      return (
        lookup[key] || {
          currentStatus: status,
          count: 0,
          percentage: '0%',
        }
      );
    });

    // 7. Final response
    return {
      total,
      result,
    };
  }

  async getMinistryCompliance(ministryId?: number) {
    const thisMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
      return qb;
    };

    const otherMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere(
          `
          r.primary_ministry_id = :ministryId
          AND r.ministry_id != :ministryId
          `,
          { ministryId },
        );
      }
      return qb;
    };

    const totalMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere(
          `
          r.primary_ministry_id = :ministryId
          OR r.ministry_id = :ministryId
          `,
          { ministryId },
        );
      }
      return qb;
    };

    const thisMinistry = await this.calculateCompliance(thisMinistryWhere);
    const otherMinistry = await this.calculateCompliance(otherMinistryWhere);
    const totalMinistry = await this.calculateCompliance(totalMinistryWhere);

    return {
      thisMinistry,
      otherMinistry,
      totalMinistry,
    };
  }

  async getHLCCompliance() {
    const acceptedHLC = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'h')
      .select('h.id', 'hlcId')
      .addSelect('h.name', 'hlcName')
      .addSelect('COUNT(r.id)', 'count')
      .where('r.current_status = :status', {
        status: StatusEnum.FULLY_IMPLEMENTED,
      })
      .andWhere('r.current_stage = :stage', {
        stage: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      })
      .groupBy('h.id')
      .addGroupBy('h.name')
      .getRawMany();

    let result = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'hlc')
      .select('hlc.id', 'hlcId')
      .addSelect('hlc.slug', 'hlcSlug')
      .addSelect('hlc.name', 'hlcName')
      .addSelect(
        `
      CASE
        WHEN r.current_status IS NULL OR r.current_status = ''
        THEN 'No Action'
        ELSE r.current_status
      END
    `,
        'currentStatus',
      )
      .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count')
      .groupBy('hlc.id')
      .addGroupBy('hlc.name')
      .addGroupBy(
        `
        CASE
          WHEN r.current_status IS NULL OR r.current_status = ''
          THEN 'No Action'
          ELSE r.current_status
        END
      `,
      )
      .getRawMany();

    const grouped = Object.values(
      result.reduce((acc, item) => {
        const { hlcId, hlcName, currentStatus, hlcSlug } = item;
        const count = Number(item.count);

        if (!acc[hlcId]) {
          acc[hlcId] = {
            hlcId,
            hlcName,
            hlcSlug: `HLC-${hlcSlug}`,
            accepted: 0,
            acceptedPercentage: '',
            total: 0,
            status: [],
          };
        }

        // Add to total
        acc[hlcId].total += count;

        // Push status entry
        acc[hlcId].status.push({
          currentStatus,
          count,
        });

        return acc;
      }, {}),
    );

    const total: any = grouped.reduce((acc, item: any) => {
      return acc + item.total;
    }, 0);

    grouped.forEach((hlc: any) => {
      const acc = acceptedHLC.find((item) => item.hlcId == hlc.hlcId);

      hlc.percentage = ((hlc.total / total) * 100).toFixed(2) + '%';
      hlc.accepted = acc?.count || 0;
      hlc.acceptedPercentage =
        (((acc?.count ?? 0) / total) * 100).toFixed(2) + '%';
      hlc.status = hlc.status.map((s) => ({
        ...s,
        percentage: ((s.count / hlc.total) * 100).toFixed(2) + '%',
      }));
    });

    return grouped;
  }

  async getDelayedRecommendationBuckets() {
    let result = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      (
        EXTRACT(MONTH FROM AGE(current_date, COALESCE(r.updated_timeline, r.timeline))) +
        EXTRACT(YEAR FROM AGE(current_date, COALESCE(r.updated_timeline, r.timeline))) * 12
      )
      `,
        'months_diff',
      )
      .where('COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE')
      .andWhere(
        "(r.current_status IN (:...statuses) OR r.current_status IS NULL OR r.current_status = '')",
        {
          statuses: [
            StatusEnum.PARTIALLY_IMPLEMENTED,
            StatusEnum.UNDER_IMPLEMENTATION,
            StatusEnum.YET_TO_INITIATE,
          ],
        },
      )
      .andWhere('r.niti_approved = :nitiApproved', { nitiApproved: true })
      .getRawMany();

    const buckets: any = {};

    for (const row of result) {
      const months = Number(row.months_diff);

      let bucket = '';
      let bucketNumber = 0;

      if (months < 1) {
        bucket = '0-30 Days';
        bucketNumber = 1;
      } else if (months < 3) {
        bucket = '30-90 Days';
        bucketNumber = 2;
      } else if (months < 12) {
        bucket = '90-365 Days';
        bucketNumber = 3;
      } else {
        bucket = '1+ year';
        bucketNumber = 4;
      }

      if (!buckets[bucket]) {
        buckets[bucket] = {
          delayBucket: bucket,
          bucketNumber,
          count: 0,
          ministries: {},
        };
      }

      buckets[bucket].count += 1;

      const ministryId = row.ministryId ?? 0;
      const ministryName = row.ministryName ?? 'Unknown';

      if (!buckets[bucket].ministries[ministryId]) {
        buckets[bucket].ministries[ministryId] = {
          ministryId,
          ministryName,
          count: 0,
        };
      }

      buckets[bucket].ministries[ministryId].count += 1;
    }

    const total: any = Object.values(buckets).reduce(
      (acc: any, item: any) => acc + item.count,
      0,
    );

    const finalResult = Object.values(buckets)
      .map((item: any) => ({
        ...item,
        percentage: ((item.count / total) * 100).toFixed(2) + '%',
        ministries: Object.values(item.ministries),
      }))
      .sort((a: any, b: any) => a.bucketNumber - b.bucketNumber);

    return { total, result: finalResult };
  }

  async getStatusWiseMinistryCounts() {
    const ministries = await this.ministryRepository.find({
      select: ['id', 'name'],
    });

    const mResult = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      CASE 
          WHEN r.current_status IS NULL OR r.current_status = '' 
          THEN 'No Action'
          ELSE r.current_status
      END
      `,
        'currentStatus',
      )
      .addSelect('COUNT(r.id)', 'count')
      .groupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('r.current_status')
      .getRawMany();

    const departments = await this.getStatusWiseDepartmentCounts();

    const allStatuses = Object.values(StatusEnum);

    const keys = {
      [StatusEnum.FULLY_IMPLEMENTED]: 'fullyImplemented',
      [StatusEnum.PARTIALLY_IMPLEMENTED]: 'partiallyImplemented',
      [StatusEnum.UNDER_IMPLEMENTATION]: 'underProgress',
      [StatusEnum.YET_TO_INITIATE]: 'yetToInitiate',
      [StatusEnum.NO_ACTION]: 'noAction',
    };

    const grouped = Object.values(
      mResult.reduce((acc, item) => {
        const { ministryId, ministryName, currentStatus } = item;
        const count = Number(item.count);

        if (!acc[ministryId]) {
          acc[ministryId] = {
            ministryId,
            ministryName,
            total: 0,
            status: {},
            departments: [],
          };
        }

        acc[ministryId].departments = departments.filter(
          (item: any) => item.ministryId === ministryId,
        );

        acc[ministryId].total += count;

        acc[ministryId].status[keys[currentStatus]] = {
          currentStatus,
          count,
        };

        return acc;
      }, {}),
    );

    grouped.forEach((min: any) => {
      allStatuses.forEach((s) => {
        const key = keys[s];
        if (!min.status[key]) {
          min.status[key] = { currentStatus: s, count: 0 };
        }
      });

      // Add percentage but keep as object
      Object.keys(min.status).forEach((k) => {
        const entry = min.status[k];
        entry.percentage =
          min.total === 0
            ? '0%'
            : ((entry.count / min.total) * 100).toFixed(2) + '%';
      });
    });

    ministries.forEach((min) => {
      const exists = grouped.find((g: any) => g.ministryId === min.id);

      if (!exists) {
        grouped.push({
          ministryId: min.id,
          ministryName: min.name,
          total: 0,
          status: {
            fullyImplemented: {
              currentStatus: StatusEnum.FULLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            partiallyImplemented: {
              currentStatus: StatusEnum.PARTIALLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            underProgress: {
              currentStatus: StatusEnum.UNDER_IMPLEMENTATION,
              count: 0,
              percentage: '0%',
            },
            yetToInitiate: {
              currentStatus: StatusEnum.YET_TO_INITIATE,
              count: 0,
              percentage: '0%',
            },
            noAction: {
              currentStatus: StatusEnum.NO_ACTION,
              count: 0,
              percentage: '0%',
            },
          },
          departments: departments.filter(
            (item: any) => item.ministryId === min.id,
          ),
        });
      }
    });

    grouped.sort((a: any, b: any) => b.total - a.total);

    return grouped;
  }

  async getDelayedRecommendationByMinistry() {
    const result = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')

      // Total recommendations
      .addSelect('COUNT(r.id)', 'totalCount')

      // Delayed recommendations
      .addSelect(
        `
      SUM(
        CASE 
          WHEN COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE
            AND (
              r.current_status IN (:...statuses)
              OR r.current_status IS NULL
              OR r.current_status = ''
            )
            AND r.niti_approved = true
          THEN 1 ELSE 0 
        END
      )
      `,
        'delayedCount',
      )

      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
      })

      .groupBy('m.id')
      .addGroupBy('m.name')
      .getRawMany();

    const departments = await this.getDelayedRecommendationByDepartment();

    // Map and filter
    let mapped = result
      .map((row) => {
        const total = Number(row.totalCount) || 0;
        const delayed = Number(row.delayedCount) || 0;

        return {
          ministryId: row.ministryId,
          ministryName: row.ministryName,
          totalCount: total,
          delayedCount: delayed,
          percentage:
            total === 0 ? 0 : Number(((delayed / total) * 100).toFixed(2)),
          departments: departments.filter(
            (item: any) => item.ministryId === row.ministryId,
          ),
        };
      })
      // Filter — only ministries with delayed > 0
      .filter((x) => x.delayedCount > 0);

    // Sort by percentage DESC
    mapped.sort((a, b) => b.delayedCount - a.delayedCount);

    return mapped;
  }

  async getStatusWiseDepartmentCounts(mId?: number) {
    // Fetch all departments under a ministry (or all)
    const departments = await this.departmentRepository.find({
      select: ['id', 'name'],
      where: mId ? { ministry: { id: mId } } : {},
      relations: ['ministry'], // ensures ministryId + ministryName available
    });

    // Fetch recommendation grouped data
    const result = await this.recommendationRepository
      .createQueryBuilder('r')
      .innerJoin('r.department', 'd')
      .leftJoin('r.ministry', 'm')
      .select('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      CASE 
          WHEN r.current_status IS NULL OR r.current_status = '' 
          THEN 'No Action'
          ELSE r.current_status
      END
      `,
        'currentStatus',
      )
      .addSelect('COUNT(r.id)', 'count')
      .where(mId ? 'm.id = :mid' : '1=1', { mid: mId })
      .groupBy('d.id')
      .addGroupBy('d.name')
      .addGroupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('r.current_status')
      .getRawMany();

    const allStatuses = Object.values(StatusEnum);

    const keys = {
      [StatusEnum.FULLY_IMPLEMENTED]: 'fullyImplemented',
      [StatusEnum.PARTIALLY_IMPLEMENTED]: 'partiallyImplemented',
      [StatusEnum.UNDER_IMPLEMENTATION]: 'underProgress',
      [StatusEnum.YET_TO_INITIATE]: 'yetToInitiate',
      [StatusEnum.NO_ACTION]: 'noAction',
    };

    // Group rows by department
    const grouped = Object.values(
      result.reduce((acc, item) => {
        const {
          departmentId,
          departmentName,
          ministryId,
          ministryName,
          currentStatus,
        } = item;

        const count = Number(item.count);

        if (!acc[departmentId]) {
          acc[departmentId] = {
            departmentId,
            departmentName,
            ministryId,
            ministryName,
            total: 0,
            status: {},
          };
        }

        acc[departmentId].total += count;

        acc[departmentId].status[keys[currentStatus]] = {
          currentStatus,
          count,
        };

        return acc;
      }, {}),
    );

    // Fill missing statuses + add percentage
    grouped.forEach((dep: any) => {
      allStatuses.forEach((s) => {
        const key = keys[s];
        if (!dep.status[key]) {
          dep.status[key] = { currentStatus: s, count: 0 };
        }
      });

      Object.keys(dep.status).forEach((k) => {
        const entry = dep.status[k];
        entry.percentage =
          dep.total === 0
            ? '0%'
            : ((entry.count / dep.total) * 100).toFixed(2) + '%';
      });
    });

    // Add departments with 0 recommendations → including ministry id + name
    departments.forEach((dep) => {
      const exists = grouped.find((g: any) => g.departmentId === dep.id);

      if (!exists) {
        grouped.push({
          departmentId: dep.id,
          departmentName: dep.name,
          ministryId: dep.ministry?.id || null,
          ministryName: dep.ministry?.name || null,
          total: 0,
          status: {
            fullyImplemented: {
              currentStatus: StatusEnum.FULLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            partiallyImplemented: {
              currentStatus: StatusEnum.PARTIALLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            underProgress: {
              currentStatus: StatusEnum.UNDER_IMPLEMENTATION,
              count: 0,
              percentage: '0%',
            },
            yetToInitiate: {
              currentStatus: StatusEnum.YET_TO_INITIATE,
              count: 0,
              percentage: '0%',
            },
            noAction: {
              currentStatus: StatusEnum.NO_ACTION,
              count: 0,
              percentage: '0%',
            },
          },
        });
      }
    });

    // Sort by total
    grouped.sort((a: any, b: any) => b.total - a.total);

    return grouped;
  }

  async getDelayedRecommendationByDepartment(ministryId?: number) {
    const result = await this.recommendationRepository
      .createQueryBuilder('r')
      .innerJoin('r.department', 'd')
      .leftJoin('r.ministry', 'm')
      .select('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')

      // Total recommendations
      .addSelect('COUNT(r.id)', 'totalCount')

      // Delayed recommendations
      .addSelect(
        `
      SUM(
        CASE 
          WHEN COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE
            AND (
              r.current_status IN (:...statuses)
              OR r.current_status IS NULL
              OR r.current_status = ''
            )
            AND r.niti_approved = true
          THEN 1 ELSE 0 
        END
      )
      `,
        'delayedCount',
      )

      // Optional filter (department under ministry)
      .where(ministryId ? 'm.id = :mid' : '1=1', { mid: ministryId })

      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
      })

      .groupBy('d.id')
      .addGroupBy('d.name')
      .addGroupBy('m.id')
      .addGroupBy('m.name')
      .getRawMany();

    // Map and filter
    let mapped = result
      .map((row) => {
        const total = Number(row.totalCount) || 0;
        const delayed = Number(row.delayedCount) || 0;

        return {
          departmentId: row.departmentId,
          departmentName: row.departmentName,
          ministryId: row.ministryId,
          ministryName: row.ministryName,
          totalCount: total,
          delayedCount: delayed,
          percentage:
            total === 0 ? 0 : Number(((delayed / total) * 100).toFixed(2)),
        };
      })
      // Keep only where delayed > 0
      .filter((x) => x.delayedCount > 0);

    // Sort by delayed count DESC
    mapped.sort((a, b) => b.delayedCount - a.delayedCount);

    return mapped;
  }

  async getDelayedBucketsByHLC() {
    const rows = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'h')
      .select('h.slug', 'hlcSlug')
      .addSelect('h.name', 'hlcName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
        (
          EXTRACT(MONTH FROM AGE(current_date, COALESCE(r.updated_timeline, r.timeline))) +
          EXTRACT(YEAR FROM AGE(current_date, COALESCE(r.updated_timeline, r.timeline))) * 12
        )
      `,
        'months_diff',
      )
      .where('COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE')
      .andWhere(
        "(r.current_status IN (:...statuses) OR r.current_status IS NULL OR r.current_status = '')",
        {
          statuses: [
            StatusEnum.PARTIALLY_IMPLEMENTED,
            StatusEnum.UNDER_IMPLEMENTATION,
            StatusEnum.YET_TO_INITIATE,
          ],
        },
      )
      .andWhere('r.niti_approved = :approved', { approved: true })
      .getRawMany();

    // Master bucket
    const bucketMaster = [
      { name: '0-30 Days', number: 1 },
      { name: '30-90 Days', number: 2 },
      { name: '90-365 Days', number: 3 },
      { name: '1+ year', number: 4 },
    ];

    const hlcMap: any = {};

    // Populate HLC + bucket + ministries
    for (const row of rows) {
      const months = Number(row.months_diff);

      let delayBucket = '';
      let bucketNumber = 0;

      if (months < 1) {
        delayBucket = '0-30 Days';
        bucketNumber = 1;
      } else if (months < 3) {
        delayBucket = '30-90 Days';
        bucketNumber = 2;
      } else if (months < 12) {
        delayBucket = '90-365 Days';
        bucketNumber = 3;
      } else {
        delayBucket = '1+ year';
        bucketNumber = 4;
      }

      const hlcSlug = row.hlcSlug ?? 'unknown';
      const hlcName = row.hlcName ?? 'Unknown';
      const ministryId = row.ministryId ?? 0;
      const ministryName = row.ministryName ?? 'Unknown';

      if (!hlcMap[hlcSlug]) {
        hlcMap[hlcSlug] = {
          hlcSlug,
          hlcName,
          buckets: {},
        };
      }

      if (!hlcMap[hlcSlug].buckets[delayBucket]) {
        hlcMap[hlcSlug].buckets[delayBucket] = {
          delayBucket,
          bucketNumber,
          count: 0,
          ministries: {},
        };
      }

      hlcMap[hlcSlug].buckets[delayBucket].count += 1;

      if (!hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId]) {
        hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId] = {
          ministryId,
          ministryName,
          count: 0,
        };
      }

      hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId].count += 1;
    }

    // Build final result with all buckets and sorted
    const final: any = {};

    Object.values(hlcMap).forEach((hlc: any) => {
      const totalDelayed: any = Object.values(hlc.buckets).reduce(
        (acc: any, b: any) => acc + b.count,
        0,
      );

      // Build bucket array always
      const bucketArray = bucketMaster.map((bucket) => {
        const exists = hlc.buckets[bucket.name];

        if (exists) {
          return {
            delayBucket: bucket.name,
            bucketNumber: bucket.number,
            count: exists.count,
            ministries: Object.values(exists.ministries),
            percentage:
              totalDelayed === 0
                ? '0%'
                : ((exists.count / totalDelayed) * 100).toFixed(2) + '%',
          };
        }

        return {
          delayBucket: bucket.name,
          bucketNumber: bucket.number,
          count: 0,
          ministries: [],
          percentage: '0%',
        };
      });

      // Sort bucket array by bucketNumber
      bucketArray.sort((a, b) => a.bucketNumber - b.bucketNumber);

      final[hlc.hlcSlug] = {
        hlcSlug: hlc.hlcSlug,
        hlcName: hlc.hlcName,
        buckets: bucketArray, // ARRAY NOW ✔
      };
    });

    return final;
  }
}

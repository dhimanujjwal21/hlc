import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Recommendation } from "src/entities/recommendation.entity";
import { User } from "src/entities/users.entity";
import { DeshboardController } from "./dashboard.controller";
import { DashboardService } from "./dashboard.service";
import { Hlc } from "src/entities/hlc.entity";
import { Ministry } from "src/entities/ministry.entity";
import { Departments } from "src/entities/departments.entity";
import { JwtService } from "@nestjs/jwt";
import { DashboardV2Controller } from "./dashboard.v2.controller";

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Recommendation, Hlc, Ministry, Departments])
  ],
  controllers: [DeshboardController, DashboardV2Controller],
  providers: [DashboardService, JwtService],
  exports: [],
})
export class DashboardModule {}
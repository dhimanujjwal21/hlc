import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  Post,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { DashboardService } from './dashboard.service';
import { AuthGuard } from 'src/guards/auth.guard';
import {
  GetRecommendationSummaryDto,
  GetReportStatusSummaryDto,
  MinistryWiseReportDto,
  SummaryDto,
} from './dto/dashboard.dto';

@ApiTags('Dashboard V2')
@Controller({
  path: 'dashboard',
  version: '2',
})
export class DashboardV2Controller {
  constructor(private readonly dashboardService: DashboardService) { }

  private ensureDashboardAccess(user: any) {
    if (!user?.dashboardView) {
      throw new ForbiddenException(
        'You are not allowed to access the dashboard',
      );
    }
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('summary')
  async summary(@Req() req, @Query() query: SummaryDto) {
    this.ensureDashboardAccess(req.user);
    const summary = await this.dashboardService.getSummaryV2(
      query
    );
    return summary;
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('report-status-summary')
  async getReportStatusSummary(
    @Req() req,
    @Query() dto: GetReportStatusSummaryDto,
  ) {
    this.ensureDashboardAccess(req.user);
    return this.dashboardService.getReportStatusSummary(dto);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('ministry-wise-progress')
  async ministryWiseProgress(@Req() req, @Query() dto: MinistryWiseReportDto) {
    this.ensureDashboardAccess(req.user);
    return this.dashboardService.ministryWiseProgress(dto);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('recommendation-summary-list')
  async getRecommendationSummary(
    @Req() req,
    @Query() dto: GetRecommendationSummaryDto,
  ) {
    this.ensureDashboardAccess(req.user);
    return this.dashboardService.getRecommendationSummary(dto);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('export-recommendation-summary-list')
  async exportRecommendationSummary(
    @Req() req,
    @Body() query: GetRecommendationSummaryDto,
    @Res() res
  ) {
    this.ensureDashboardAccess(req.user);
    const buffer = await this.dashboardService.export(query);

    let filename: string = '',
      contentType: string = '';
    switch (query.format) {
      case 'csv':
        filename = 'recommendations.csv';
        contentType = 'text/csv';
        break;

      case 'excel':
        filename = 'recommendations.xlsx';
        contentType =
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;

      case 'pdf':
        filename = 'recommendations.pdf';
        contentType = 'application/pdf';
        break;

      default:
        break;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', contentType);

    return res.end(buffer);
  }
}

import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import {
  AllStatusEnum,
  ClosureStatusEnum,
  FormatEnum,
  ImplementationStatusEnum,
  RecommendationStageEnum,
  StageEnum,
  StatusEnum,
} from 'src/constants/enums';
import { Departments } from 'src/entities/departments.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { User } from 'src/entities/users.entity';
import { Brackets, Repository } from 'typeorm';
import {
  GetRecommendationSummaryDto,
  GetReportStatusSummaryDto,
  MinistryWiseReportDto,
  SummaryDto,
} from './dto/dashboard.dto';
import * as XLSX from 'xlsx';
import { Parser } from 'json2csv';
var PdfPrinter = require('pdfmake');


@Injectable()
export class DashboardService {
  constructor(
    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,

    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,

    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,
  ) { }

  private toMap(rows: { hlcSlug: string; count: string }[]) {
    return rows.reduce<Record<string, number>>((acc, row) => {
      acc[row.hlcSlug] = Number(row.count);
      return acc;
    }, {});
  }

  private buildHLCArray(allSlugs: string[], map: Record<string, number>) {
    return allSlugs.map((slug) => ({
      hlcSlug: `HLC-${slug}`,
      count: map[slug] ?? 0,
    }));
  }

  private computeTotal(allSlugs: string[], map: Record<string, number>) {
    return allSlugs.reduce((sum, slug) => sum + (map[slug] ?? 0), 0);
  }

  private buildStage2Breakdown(
    allSlugs: string[],
    initialMap: Record<string, number>,
    actionMap: Record<string, number>,
  ) {
    return allSlugs.map((slug) => ({
      hlcSlug: `HLC-${slug}`,
      initial: initialMap[slug] ?? 0,
      actionTaken: actionMap[slug] ?? 0,
      total: (initialMap[slug] ?? 0) + (actionMap[slug] ?? 0),
    }));
  }

  private async runQuery(whereFn: (qb) => void) {
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'hlc')
      .select('hlc.slug', 'hlcSlug')
      .addSelect('COUNT(r.id)', 'count')
      .groupBy('hlc.slug');

    whereFn(qb);

    return this.toMap(await qb.getRawMany());
  }

  private async getStage1(allSlugs: string[], ministryId?: number) {
    const map = await this.runQuery((qb) => {
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_NITI_DIRECTOR,
      });

      if (ministryId) {
        qb.andWhere('r.niti_approved = true').andWhere(
          'r.ministry_id = :ministryId',
          { ministryId },
        );
      }
    });

    const total = this.computeTotal(allSlugs, map);

    return {
      key: 'Stage 1',
      stageName: StageEnum.PENDING_WITH_NITI_DIRECTOR,
      total,
      hlc: this.buildHLCArray(allSlugs, map),
    };
  }

  private async getStage2(allSlugs: string[], ministryId?: number) {
    const initialMap = await this.runQuery((qb) => {
      qb.andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_NITI_APPROVER,
      }).andWhere("(r.current_status IS NULL OR r.current_status = '')");
      if (ministryId) {
        qb.andWhere('r.niti_approved = true').andWhere(
          'r.ministry_id = :ministryId',
          { ministryId },
        );
      }
    });

    const actionMap = await this.runQuery((qb) => {
      qb.andWhere('r.current_stage IN (:...s)', {
        s: [
          StageEnum.PENDING_WITH_NITI_APPROVER,
          StageEnum.PENDING_WITH_NITI_APPROVER_FOR_UPDATED_TIMELINE,
        ],
      }).andWhere("(r.current_status IS NOT NULL AND r.current_status != '')");

      if (ministryId) {
        qb.andWhere('r.niti_approved = true').andWhere(
          'r.ministry_id = :ministryId',
          { ministryId },
        );
      }
    });

    const initialTotal = this.computeTotal(allSlugs, initialMap);
    const actionTotal = this.computeTotal(allSlugs, actionMap);

    return {
      key: 'Stage 2',
      stageName: StageEnum.PENDING_WITH_NITI_APPROVER,
      total: initialTotal + actionTotal,
      initial: {
        total: initialTotal,
        hlc: this.buildHLCArray(allSlugs, initialMap),
      },
      actionTaken: {
        total: actionTotal,
        hlc: this.buildHLCArray(allSlugs, actionMap),
      },
      hlc: this.buildStage2Breakdown(allSlugs, initialMap, actionMap),
    };
  }

  private async getStage3(allSlugs: string[], ministryId?: number) {
    const map = await this.runQuery((qb) => {
      qb.where('r.niti_approved = true').andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
      });

      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
    });

    const total = this.computeTotal(allSlugs, map);

    return {
      key: 'Stage 3',
      stageName: StageEnum.PENDING_WITH_MINISTRY_DIRECTOR,
      total,
      hlc: this.buildHLCArray(allSlugs, map),
    };
  }

  private async getStage4(allSlugs: string[], ministryId?: number) {
    const map = await this.runQuery((qb) => {
      qb.where('r.niti_approved = true').andWhere('r.current_stage = :s', {
        s: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
      });

      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
    });

    const total = this.computeTotal(allSlugs, map);

    return {
      key: 'Stage 4',
      stageName: StageEnum.PENDING_WITH_MINISTRY_APPROVER,
      total,
      hlc: this.buildHLCArray(allSlugs, map),
    };
  }

  private async getStage5(allSlugs: string[], ministryId?: number) {
    const map = await this.runQuery((qb) => {
      qb.where('r.niti_approved = true')
        .andWhere('r.current_stage = :s', {
          s: StageEnum.ACCEPTED_BY_NITI_APPROVER,
        })
        .andWhere('r.current_status = :status', {
          status: StatusEnum.FULLY_IMPLEMENTED,
        });

      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
    });

    const total = this.computeTotal(allSlugs, map);

    return {
      key: 'Stage 5',
      stageName: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      total,
      hlc: this.buildHLCArray(allSlugs, map),
    };
  }

  private async getStage6(allSlugs: string[], ministryId?: number) {
    const map = await this.runQuery((qb) => {
      qb.where('r.closure_status = :st', {
        st: ClosureStatusEnum.CLOSED,
      }).andWhere('r.current_stage = :s', {
        s: StageEnum.CLOSED_BY_HLC,
      });

      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
    });

    const total = this.computeTotal(allSlugs, map);

    return {
      key: 'Stage 6',
      stageName: StageEnum.CLOSED_BY_HLC,
      total,
      hlc: this.buildHLCArray(allSlugs, map),
    };
  }

  async getSummary(ministryId?: number) {
    const allHLC = await this.hlcRepository
      .createQueryBuilder('hlc')
      .select('hlc.slug', 'hlcSlug')
      .orderBy('hlc.slug', 'ASC')
      .getRawMany();

    const allSlugs = allHLC.map((h) => h.hlcSlug);

    if (ministryId) {
      const stage3 = await this.getStage3(allSlugs, ministryId);
      const stage4 = await this.getStage4(allSlugs, ministryId);

      return {
        total: stage3.total + stage4.total,
        stage3,
        stage4,
      };
    }

    const stage1 = await this.getStage1(allSlugs, ministryId);
    const stage2 = await this.getStage2(allSlugs, ministryId);
    const stage3 = await this.getStage3(allSlugs, ministryId);
    const stage4 = await this.getStage4(allSlugs, ministryId);
    const stage5 = await this.getStage5(allSlugs, ministryId);
    const stage6 = await this.getStage6(allSlugs, ministryId);

    return {
      total:
        stage1.total +
        stage2.total +
        stage3.total +
        stage4.total +
        stage5.total +
        stage6.total,
      stage1,
      stage2,
      stage3,
      stage4,
      stage5,
      stage6,
    };
  }

  async getOverallCompliance(ministryId?: number) {
    // Base query (reused everywhere)
    const baseQuery = this.recommendationRepository.createQueryBuilder('r');

    if (ministryId) {
      baseQuery
        .andWhere('r.niti_approved = true')
        .andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    // 1️⃣ Total recommendations
    const totalRecommendations = await baseQuery.getCount();

    // 2️⃣ Fully implemented + accepted by NITI Approver
    const acceptedQuery = this.recommendationRepository
      .createQueryBuilder('r')
      .where('r.current_status = :currentStatus', {
        currentStatus: StatusEnum.FULLY_IMPLEMENTED,
      })
      .andWhere('r.current_stage = :currentStage', {
        currentStage: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      });

    if (ministryId) {
      acceptedQuery.andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    const fullyImplementedCount = await acceptedQuery.getCount();

    const closed = await this.recommendationRepository
      .createQueryBuilder('r')
      .where('r.closure_status = :status', { status: ClosureStatusEnum.CLOSED })
      .andWhere('r.current_stage = :currentStage', {
        currentStage: StageEnum.CLOSED_BY_HLC,
      })
      .getCount();

    // 3️⃣ Status-wise counts
    const statusCase = `
      CASE
        WHEN r.current_status IS NULL OR r.current_status = ''
        THEN 'No Action'
        ELSE r.current_status
      END
    `;

    const statusQuery = this.recommendationRepository
      .createQueryBuilder('r')
      .select(statusCase, 'currentStatus')
      .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count')
      .where('r.closure_status = :status', { status: ClosureStatusEnum.OPEN })
      .groupBy(statusCase);

    if (ministryId) {
      statusQuery
        .andWhere('r.niti_approved = true')
        .andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    const raw = await statusQuery.getRawMany();

    // 4️⃣ Total = sum of all statuses
    let total = raw.reduce((sum, r) => sum + Number(r.count), 0);

    total += closed || 0;

    // 5️⃣ Build lookup
    const lookup: Record<string, any> = {};
    raw.forEach((row) => {
      const key = row.currentStatus.toLowerCase();
      lookup[key] = {
        currentStatus: row.currentStatus,
        count: Number(row.count),
        percentage: total ? ((row.count / total) * 100).toFixed(2) + '%' : '0%',
      };
    });

    lookup[ClosureStatusEnum.CLOSED.toLowerCase()] = {
      currentStatus: 'Closed',
      count: closed || 0,
      percentage: total ? ((closed / total) * 100).toFixed(2) + '%' : '0%',
    };

    // 6️⃣ Ensure all statuses appear
    const result = Object.values(AllStatusEnum).map((status) => {
      const key = status.toLowerCase();
      return (
        lookup[key] || {
          currentStatus: status,
          count: 0,
          percentage: '0%',
        }
      );
    });

    return {
      total: totalRecommendations,
      result,
      accepted: fullyImplementedCount,
      acceptedPercentage: totalRecommendations
        ? (fullyImplementedCount / totalRecommendations) * 100
        : 0,
    };
  }

  async getHLCCompliance(ministryId?: number) {
    const acceptedQB = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'h')
      .select('h.id', 'hlcId')
      .addSelect('h.name', 'hlcName')
      .addSelect('COUNT(r.id)', 'count')
      .where('r.current_status = :status', {
        status: StatusEnum.FULLY_IMPLEMENTED,
      })
      .andWhere('r.current_stage = :stage', {
        stage: StageEnum.ACCEPTED_BY_NITI_APPROVER,
      });

    if (ministryId) {
      acceptedQB
        .andWhere('r.niti_approved = true')
        .andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    const acceptedHLC = await acceptedQB
      .groupBy('h.id')
      .addGroupBy('h.name')
      .getRawMany();

    const statusCase = `
    CASE
      WHEN r.current_status IS NULL OR r.current_status = ''
      THEN 'No Action'
      ELSE r.current_status
    END
  `;

    const statusQB = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'hlc')
      .select('hlc.id', 'hlcId')
      .addSelect('hlc.slug', 'hlcSlug')
      .addSelect('hlc.name', 'hlcName')
      .addSelect(statusCase, 'currentStatus')
      .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count');

    if (ministryId) {
      statusQB
        .andWhere('r.niti_approved = true')
        .andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    const raw = await statusQB
      .groupBy('hlc.id')
      .addGroupBy('hlc.slug')
      .addGroupBy('hlc.name')
      .addGroupBy(statusCase)
      .getRawMany();

    const grouped = Object.values(
      raw.reduce((acc: any, item: any) => {
        const { hlcId, hlcName, hlcSlug, currentStatus } = item;
        const count = Number(item.count);

        if (!acc[hlcId]) {
          acc[hlcId] = {
            hlcId,
            hlcName,
            hlcSlug: `HLC-${hlcSlug}`,
            total: 0,
            accepted: 0,
            acceptedPercentage: '0%',
            percentage: '0%',
            status: [],
          };
        }

        acc[hlcId].total += count;

        acc[hlcId].status.push({
          currentStatus,
          count,
        });

        return acc;
      }, {}),
    );

    const grandTotal: any = grouped.reduce(
      (sum: number, h: any) => sum + h.total,
      0,
    );

    grouped.forEach((hlc: any) => {
      const accepted = acceptedHLC.find(
        (a) => Number(a.hlcId) === Number(hlc.hlcId),
      );

      const acceptedCount = Number(accepted?.count ?? 0);

      hlc.accepted = acceptedCount;
      hlc.acceptedPercentage = grandTotal
        ? ((acceptedCount / grandTotal) * 100).toFixed(2) + '%'
        : '0%';

      hlc.percentage = grandTotal
        ? ((hlc.total / grandTotal) * 100).toFixed(2) + '%'
        : '0%';

      hlc.status = hlc.status.map((s) => ({
        ...s,
        percentage: hlc.total
          ? ((s.count / hlc.total) * 100).toFixed(2) + '%'
          : '0%',
      }));
    });

    return grouped;
  }

  async calculateCompliance(whereBuilder: (qb: any) => any) {
    const statusCase = `
      CASE
        WHEN r.current_status IS NULL OR r.current_status = ''
        THEN 'No Action'
        ELSE r.current_status
      END
    `;

    // 3. Status-wise counts
    const raw = await whereBuilder(
      this.recommendationRepository
        .createQueryBuilder('r')
        .select(statusCase, 'currentStatus')
        .addSelect('CAST(COUNT(r.id) AS INTEGER)', 'count')
        .where('r.closure_status = :status', { status: ClosureStatusEnum.OPEN })
        .groupBy(statusCase),
    ).getRawMany();

    const closedQb = this.recommendationRepository
      .createQueryBuilder('r')
      .where('r.closure_status = :status', {
        status: ClosureStatusEnum.CLOSED,
      })
      .andWhere('r.current_stage = :stage', {
        stage: StageEnum.CLOSED_BY_HLC,
      });

    whereBuilder(closedQb);

    const closedCount = await closedQb.getCount();

    // const total = raw.reduce((sum, r) => sum + Number(r.count), 0);
    const openTotal = raw.reduce((sum, r) => sum + Number(r.count), 0);
    const total = openTotal + closedCount;

    const lookup: Record<string, any> = {};
    raw.forEach((row) => {
      const key = row.currentStatus.toLowerCase();
      lookup[key] = {
        currentStatus: row.currentStatus,
        count: Number(row.count),
        percentage: total ? ((row.count / total) * 100).toFixed(2) + '%' : '0%',
      };
    });

    lookup[ClosureStatusEnum.CLOSED.toLowerCase()] = {
      currentStatus: 'Closed',
      count: closedCount || 0,
      percentage: total ? ((closedCount / total) * 100).toFixed(2) + '%' : '0%',
    };

    const result = Object.values(AllStatusEnum).map((status) => {
      const key = status.toLowerCase();
      return (
        lookup[key] || {
          currentStatus: status,
          count: 0,
          percentage: '0%',
        }
      );
    });

    return {
      total,
      result,
    };
  }

  async getMinistryCompliance(ministryId?: number, ministryRequest?: boolean) {
    const thisMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere('r.ministry_id = :ministryId', { ministryId });
      }
      if (ministryRequest) {
        qb.andWhere('r.niti_approved = true');
      }
      return qb;
    };

    const otherMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere(
          `
          r.primary_ministry_id = :ministryId
          AND r.ministry_id != :ministryId
          `,
          { ministryId },
        );
      }
      if (ministryRequest) {
        qb.andWhere('r.niti_approved = true');
      }
      return qb;
    };

    const totalMinistryWhere = (qb: any) => {
      if (ministryId) {
        qb.andWhere(
          new Brackets((qb2) => {
            qb2
              .where('r.primary_ministry_id = :ministryId')
              .orWhere('r.ministry_id = :ministryId');
          }),
          { ministryId },
        );
        // qb.andWhere(
        //   `
        //   r.primary_ministry_id = :ministryId
        //   OR r.ministry_id = :ministryId
        //   `,
        //   { ministryId },
        // );
      }
      if (ministryRequest) {
        qb.andWhere('r.niti_approved = true');
      }
      return qb;
    };

    const thisMinistry = await this.calculateCompliance(thisMinistryWhere);
    const otherMinistry = await this.calculateCompliance(otherMinistryWhere);
    const totalMinistry = await this.calculateCompliance(totalMinistryWhere);

    return {
      thisMinistry,
      otherMinistry,
      totalMinistry,
    };
  }

  async getDelayedRecommendationBuckets(ministryId?: number) {
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      (
        EXTRACT(MONTH FROM AGE(CURRENT_DATE, COALESCE(r.updated_timeline, r.timeline))) +
        EXTRACT(YEAR FROM AGE(CURRENT_DATE, COALESCE(r.updated_timeline, r.timeline))) * 12
      )
      `,
        'months_diff',
      )
      .where('COALESCE(r.updated_timeline, r.timeline) < CURRENT_DATE')
      .andWhere(
        `
      (
        r.current_status IN (:...statuses)
        OR r.current_status IS NULL
        OR r.current_status = ''
      )
      `,
        {
          statuses: [
            StatusEnum.PARTIALLY_IMPLEMENTED,
            StatusEnum.UNDER_IMPLEMENTATION,
            StatusEnum.YET_TO_INITIATE,
          ],
        },
      )
      .andWhere('r.niti_approved = :nitiApproved', { nitiApproved: true });

    if (ministryId) {
      qb.andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    const result = await qb.getRawMany();

    const buckets: Record<string, any> = {};

    for (const row of result) {
      const months = Number(row.months_diff);

      let bucket = '';
      let bucketNumber = 0;

      if (months < 1) {
        bucket = '0-30 Days';
        bucketNumber = 1;
      } else if (months < 3) {
        bucket = '30-90 Days';
        bucketNumber = 2;
      } else if (months < 12) {
        bucket = '90-365 Days';
        bucketNumber = 3;
      } else {
        bucket = '1+ year';
        bucketNumber = 4;
      }

      if (!buckets[bucket]) {
        buckets[bucket] = {
          delayBucket: bucket,
          bucketNumber,
          count: 0,
          ministries: {},
        };
      }

      buckets[bucket].count += 1;

      const mId = row.ministryId ?? 0;
      const mName = row.ministryName ?? 'Unknown';

      if (!buckets[bucket].ministries[mId]) {
        buckets[bucket].ministries[mId] = {
          ministryId: mId,
          ministryName: mName,
          count: 0,
        };
      }

      buckets[bucket].ministries[mId].count += 1;
    }

    const total = Object.values(buckets).reduce(
      (sum: number, item: any) => sum + item.count,
      0,
    );

    const finalResult = Object.values(buckets)
      .map((item: any) => ({
        ...item,
        percentage: total
          ? ((item.count / total) * 100).toFixed(2) + '%'
          : '0%',
        ministries: Object.values(item.ministries),
      }))
      .sort((a: any, b: any) => a.bucketNumber - b.bucketNumber);

    return {
      total,
      result: finalResult,
    };
  }

  async getStatusWiseDepartmentCounts(ministryId?: number) {
    // Fetch all departments under a ministry (or all)
    const departments = await this.departmentRepository.find({
      select: ['id', 'name'],
      where: ministryId ? { ministry: { id: ministryId } } : {},
      relations: ['ministry'], // ensures ministryId + ministryName available
    });

    // Fetch recommendation grouped data
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .innerJoin('r.department', 'd')
      .leftJoin('r.ministry', 'm')
      .select('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      CASE 
          WHEN r.current_status IS NULL OR r.current_status = '' 
          THEN 'No Action'
          ELSE r.current_status
      END
      `,
        'currentStatus',
      )
      .addSelect('COUNT(r.id)', 'count')
      .groupBy('d.id')
      .addGroupBy('d.name')
      .addGroupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('r.current_status');

    if (ministryId) {
      qb.andWhere('r.niti_approved = true').andWhere('m.id = :mid', {
        mid: ministryId,
      });
    }

    const result = await qb.getRawMany();

    const allStatuses = Object.values(StatusEnum);

    const keys = {
      [StatusEnum.FULLY_IMPLEMENTED]: 'fullyImplemented',
      [StatusEnum.PARTIALLY_IMPLEMENTED]: 'partiallyImplemented',
      [StatusEnum.UNDER_IMPLEMENTATION]: 'underProgress',
      [StatusEnum.YET_TO_INITIATE]: 'yetToInitiate',
      [StatusEnum.NO_ACTION]: 'noAction',
    };

    // Group rows by department
    const grouped = Object.values(
      result.reduce((acc, item) => {
        const {
          departmentId,
          departmentName,
          ministryId,
          ministryName,
          currentStatus,
        } = item;

        const count = Number(item.count);

        if (!acc[departmentId]) {
          acc[departmentId] = {
            departmentId,
            departmentName,
            ministryId,
            ministryName,
            total: 0,
            status: {},
          };
        }

        acc[departmentId].total += count;

        acc[departmentId].status[keys[currentStatus]] = {
          currentStatus,
          count,
        };

        return acc;
      }, {}),
    );

    // Fill missing statuses + add percentage
    grouped.forEach((dep: any) => {
      allStatuses.forEach((s) => {
        const key = keys[s];
        if (!dep.status[key]) {
          dep.status[key] = { currentStatus: s, count: 0 };
        }
      });

      Object.keys(dep.status).forEach((k) => {
        const entry = dep.status[k];
        entry.percentage =
          dep.total === 0
            ? '0%'
            : ((entry.count / dep.total) * 100).toFixed(2) + '%';
      });
    });

    // Add departments with 0 recommendations → including ministry id + name
    departments.forEach((dep) => {
      const exists = grouped.find((g: any) => g.departmentId === dep.id);

      if (!exists) {
        grouped.push({
          departmentId: dep.id,
          departmentName: dep.name,
          ministryId: dep.ministry?.id || null,
          ministryName: dep.ministry?.name || null,
          total: 0,
          status: {
            fullyImplemented: {
              currentStatus: StatusEnum.FULLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            partiallyImplemented: {
              currentStatus: StatusEnum.PARTIALLY_IMPLEMENTED,
              count: 0,
              percentage: '0%',
            },
            underProgress: {
              currentStatus: StatusEnum.UNDER_IMPLEMENTATION,
              count: 0,
              percentage: '0%',
            },
            yetToInitiate: {
              currentStatus: StatusEnum.YET_TO_INITIATE,
              count: 0,
              percentage: '0%',
            },
            noAction: {
              currentStatus: StatusEnum.NO_ACTION,
              count: 0,
              percentage: '0%',
            },
          },
        });
      }
    });
    grouped.sort((a: any, b: any) => b.total - a.total);

    return grouped;
  }

  async getStatusWiseMinistryCounts(ministryId?: number) {
    const totalRow: any = {
      ministryId: null,
      ministryName: 'Total',
      total: 0,
      status: {},
      departments: [],
    };
    const ministries = await this.ministryRepository.find({
      select: ['id', 'name'],
    });

    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
      CASE 
          WHEN r.current_status IS NULL OR r.current_status = '' 
          THEN 'No Action'
          ELSE r.current_status
      END
      `,
        'currentStatus',
      )
      .addSelect('COUNT(r.id)', 'count')
      .groupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('r.current_status');

    if (ministryId) {
      qb.andWhere('r.niti_approved = true').andWhere('m.id = :mid', {
        mid: ministryId,
      });
    }

    const mResult = await qb.getRawMany();

    const departments = await this.getStatusWiseDepartmentCounts(ministryId);

    const allStatuses = Object.values(StatusEnum);

    const keys = {
      [StatusEnum.FULLY_IMPLEMENTED]: 'fullyImplemented',
      [StatusEnum.PARTIALLY_IMPLEMENTED]: 'partiallyImplemented',
      [StatusEnum.UNDER_IMPLEMENTATION]: 'underProgress',
      [StatusEnum.YET_TO_INITIATE]: 'yetToInitiate',
      [StatusEnum.NO_ACTION]: 'noAction',
    };

    allStatuses.forEach((s) => {
      const key = keys[s];
      totalRow.status[key] = {
        currentStatus: s,
        count: 0,
        percentage: '0%',
      };
    });

    const grouped = Object.values(
      mResult.reduce((acc, item) => {
        const { ministryId, ministryName, currentStatus } = item;
        const count = Number(item.count);

        if (!acc[ministryId]) {
          acc[ministryId] = {
            ministryId,
            ministryName,
            total: 0,
            status: {},
            departments: [],
          };
        }

        acc[ministryId].departments = departments.filter(
          (item: any) => item.ministryId === ministryId,
        );

        acc[ministryId].total += count;

        acc[ministryId].status[keys[currentStatus]] = {
          currentStatus,
          count,
        };

        return acc;
      }, {}),
    );

    grouped.forEach((min: any) => {
      allStatuses.forEach((s) => {
        const key = keys[s];
        if (!min.status[key]) {
          min.status[key] = { currentStatus: s, count: 0 };
        }
      });

      // Add percentage but keep as object
      Object.keys(min.status).forEach((k) => {
        const entry = min.status[k];
        entry.percentage =
          min.total === 0
            ? '0%'
            : ((entry.count / min.total) * 100).toFixed(2) + '%';
      });
    });

    if (!ministryId) {
      ministries.forEach((min) => {
        const exists = grouped.find((g: any) => g.ministryId === min.id);

        if (!exists) {
          grouped.push({
            ministryId: min.id,
            ministryName: min.name,
            total: 0,
            status: {
              fullyImplemented: {
                currentStatus: StatusEnum.FULLY_IMPLEMENTED,
                count: 0,
                percentage: '0%',
              },
              partiallyImplemented: {
                currentStatus: StatusEnum.PARTIALLY_IMPLEMENTED,
                count: 0,
                percentage: '0%',
              },
              underProgress: {
                currentStatus: StatusEnum.UNDER_IMPLEMENTATION,
                count: 0,
                percentage: '0%',
              },
              yetToInitiate: {
                currentStatus: StatusEnum.YET_TO_INITIATE,
                count: 0,
                percentage: '0%',
              },
              noAction: {
                currentStatus: StatusEnum.NO_ACTION,
                count: 0,
                percentage: '0%',
              },
            },
            departments: departments.filter(
              (item: any) => item.ministryId === min.id,
            ),
          });
        }
      });

      grouped.sort((a: any, b: any) => b.total - a.total);
    }

    grouped.forEach((min: any) => {
      totalRow.total += min.total;

      Object.keys(min.status).forEach((k) => {
        totalRow.status[k].count += min.status[k].count;
      });
    });

    Object.keys(totalRow.status).forEach((k) => {
      totalRow.status[k].percentage =
        totalRow.total === 0
          ? '0%'
          : ((totalRow.status[k].count / totalRow.total) * 100).toFixed(2) +
          '%';
    });

    grouped.push(totalRow);

    return grouped;
  }

  async getDelayedRecommendationByDepartment(ministryId?: number) {
    const result = await this.recommendationRepository
      .createQueryBuilder('r')
      .innerJoin('r.department', 'd')
      .leftJoin('r.ministry', 'm')
      .select('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')

      // Total recommendations
      .addSelect('COUNT(r.id)', 'totalCount')

      // Delayed recommendations
      .addSelect(
        `
      SUM(
        CASE 
          WHEN DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE
            AND (
              r.current_status IN (:...statuses)
              OR r.current_status IS NULL
              OR r.current_status = ''
            )
            AND r.niti_approved = true
          THEN 1 ELSE 0 
        END
      )
      `,
        'delayedCount',
      )

      // Optional filter (department under ministry)
      .where(ministryId ? 'm.id = :mid' : '1=1', { mid: ministryId })

      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
      })

      .groupBy('d.id')
      .addGroupBy('d.name')
      .addGroupBy('m.id')
      .addGroupBy('m.name')
      .getRawMany();

    // Map and filter
    let mapped = result
      .map((row) => {
        const total = Number(row.totalCount) || 0;
        const delayed = Number(row.delayedCount) || 0;

        return {
          departmentId: row.departmentId,
          departmentName: row.departmentName,
          ministryId: row.ministryId,
          ministryName: row.ministryName,
          totalCount: total,
          delayedCount: delayed,
          percentage:
            total === 0 ? 0 : Number(((delayed / total) * 100).toFixed(2)),
        };
      })
      // Keep only where delayed > 0
      .filter((x) => x.delayedCount > 0);

    // Sort by delayed count DESC
    mapped.sort((a, b) => b.delayedCount - a.delayedCount);

    return mapped;
  }

  async getDelayedRecommendationByMinistry(ministryId?: number) {
    let qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')

      // Total recommendations
      .addSelect('COUNT(r.id)', 'totalCount')

      // Delayed recommendations
      .addSelect(
        `
      SUM(
        CASE 
          WHEN DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE
            AND (
              r.current_status IN (:...statuses)
              OR r.current_status IS NULL
              OR r.current_status = ''
            )
            AND r.niti_approved = true
          THEN 1 ELSE 0 
        END
      )
      `,
        'delayedCount',
      )

      .setParameters({
        statuses: [
          StatusEnum.PARTIALLY_IMPLEMENTED,
          StatusEnum.UNDER_IMPLEMENTATION,
          StatusEnum.YET_TO_INITIATE,
        ],
      });

    if (ministryId) {
      qb.andWhere('r.niti_approved = true').andWhere('m.id = :mid', {
        mid: ministryId,
      });
    }

    qb.groupBy('m.id').addGroupBy('m.name');

    const result = await qb.getRawMany();

    const departments =
      await this.getDelayedRecommendationByDepartment(ministryId);

    // Map and filter
    let mapped = result
      .map((row) => {
        const total = Number(row.totalCount) || 0;
        const delayed = Number(row.delayedCount) || 0;

        return {
          ministryId: row.ministryId,
          ministryName: row.ministryName,
          totalCount: total,
          delayedCount: delayed,
          percentage:
            total === 0 ? 0 : Number(((delayed / total) * 100).toFixed(2)),
          departments: departments.filter(
            (item: any) => item.ministryId === row.ministryId,
          ),
        };
      })
      // Filter — only ministries with delayed > 0
      .filter((x) => x.delayedCount > 0);

    // Sort by percentage DESC
    mapped.sort((a, b) => b.delayedCount - a.delayedCount);

    return mapped;
  }

  async getDelayedBucketsByHLC(ministryId?: number) {
    const rows = await this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.hlc', 'h')
      .select('h.slug', 'hlcSlug')
      .addSelect('h.name', 'hlcName')
      .addSelect('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect(
        `
        (
          EXTRACT(MONTH FROM AGE(current_date, DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'))) +
          EXTRACT(YEAR FROM AGE(current_date, DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'))) * 12
        )
      `,
        'months_diff',
      )
      .where("DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE")
      .andWhere(
        "(r.current_status IN (:...statuses) OR r.current_status IS NULL OR r.current_status = '')",
        {
          statuses: [
            StatusEnum.PARTIALLY_IMPLEMENTED,
            StatusEnum.UNDER_IMPLEMENTATION,
            StatusEnum.YET_TO_INITIATE,
          ],
        },
      )
      .where(ministryId ? 'm.id = :mid' : '1=1', { mid: ministryId })
      .andWhere('r.niti_approved = :approved', { approved: true })
      .getRawMany();

    // Master bucket
    const bucketMaster = [
      { name: '0-30 Days', number: 1 },
      { name: '30-90 Days', number: 2 },
      { name: '90-365 Days', number: 3 },
      { name: '1+ year', number: 4 },
    ];

    const hlcMap: any = {};

    // Populate HLC + bucket + ministries
    for (const row of rows) {
      const months = Number(row.months_diff);

      let delayBucket = '';
      let bucketNumber = 0;

      if (months < 1) {
        delayBucket = '0-30 Days';
        bucketNumber = 1;
      } else if (months < 3) {
        delayBucket = '30-90 Days';
        bucketNumber = 2;
      } else if (months < 12) {
        delayBucket = '90-365 Days';
        bucketNumber = 3;
      } else {
        delayBucket = '1+ year';
        bucketNumber = 4;
      }

      const hlcSlug = row.hlcSlug ?? 'unknown';
      const hlcName = row.hlcName ?? 'Unknown';
      const ministryId = row.ministryId ?? 0;
      const ministryName = row.ministryName ?? 'Unknown';

      if (!hlcMap[hlcSlug]) {
        hlcMap[hlcSlug] = {
          hlcSlug,
          hlcName,
          buckets: {},
        };
      }

      if (!hlcMap[hlcSlug].buckets[delayBucket]) {
        hlcMap[hlcSlug].buckets[delayBucket] = {
          delayBucket,
          bucketNumber,
          count: 0,
          ministries: {},
        };
      }

      hlcMap[hlcSlug].buckets[delayBucket].count += 1;

      if (!hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId]) {
        hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId] = {
          ministryId,
          ministryName,
          count: 0,
        };
      }

      hlcMap[hlcSlug].buckets[delayBucket].ministries[ministryId].count += 1;
    }

    const final: any = {};

    Object.values(hlcMap).forEach((hlc: any) => {
      const totalDelayed: any = Object.values(hlc.buckets).reduce(
        (acc: any, b: any) => acc + b.count,
        0,
      );

      const bucketArray = bucketMaster.map((bucket) => {
        const exists = hlc.buckets[bucket.name];

        if (exists) {
          return {
            delayBucket: bucket.name,
            bucketNumber: bucket.number,
            count: exists.count,
            ministries: Object.values(exists.ministries),
            percentage:
              totalDelayed === 0
                ? '0%'
                : ((exists.count / totalDelayed) * 100).toFixed(2) + '%',
          };
        }

        return {
          delayBucket: bucket.name,
          bucketNumber: bucket.number,
          count: 0,
          ministries: [],
          percentage: '0%',
        };
      });

      bucketArray.sort((a, b) => a.bucketNumber - b.bucketNumber);

      final[hlc.hlcSlug] = {
        hlcSlug: hlc.hlcSlug,
        hlcName: hlc.hlcName,
        buckets: bucketArray,
      };
    });

    return final;
  }

  async fetchDues(status: string) {
    const result = await this.recommendationRepository
      .createQueryBuilder('r')
      .select([
        "SUM(CASE WHEN DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END) AS track",
        "SUM(CASE WHEN DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END) AS overdue",
      ])
      .where('current_status = :status', { status })
      .getRawOne();

    return {
      track: result.track || 0,
      overdue: result.overdue || 0,
    };
  }

  async getSummaryV2(query: SummaryDto) {
    const { hlcId, ministryId, departmentId, reportNumbers } = query;
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .select('COUNT(r.id)', 'total')
      .addSelect(`SUM(CASE WHEN r.current_status = :fullyImplemented THEN 1 ELSE 0 END)`, 'fullyImplemented')
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) THEN 1 ELSE 0 END)`, 'inProgressTotal')
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END)`, 'inProgressOnTrack')
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END)`, 'inProgressOverdue')
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) THEN 1 ELSE 0 END)`, 'yetToInitiateTotal')
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END)`, 'yetToInitiateOnTrack')
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END)`, 'yetToInitiateOverdue')
      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,
        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,
        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED
      });

    if (hlcId) {
      qb.andWhere('r.hlc_id = :hlcId', { hlcId });
    }

    if (ministryId) {
      qb.andWhere('r.ministry_id = :ministryId', { ministryId });
    }

    if (departmentId) {
      qb.andWhere('r.department_id = :departmentId', { departmentId });
    }

    if (reportNumbers?.length) {
      qb.andWhere('r.reportNumber IN (:...reportNumbers)', { reportNumbers });
    }

    const raw = await qb.getRawOne();
    const total = Number(raw?.total) || 0;
    const calculatePercentage = (value: number) =>
      total ? Math.round((value / total) * 100) : 0;
    return {
      total,
      fullyImplemented: {
        count: Number(raw?.fullyImplemented) || 0,
        percentage: calculatePercentage(Number(raw?.fullyImplemented) || 0),
      },
      inProgress: {
        total: Number(raw?.inProgressTotal) || 0,
        onTrack: Number(raw?.inProgressOnTrack) || 0,
        overdue: Number(raw?.inProgressOverdue) || 0,
        percentage: calculatePercentage(Number(raw?.inProgressTotal) || 0),
      },
      yetToInitiate: {
        total: Number(raw?.yetToInitiateTotal) || 0,
        onTrack: Number(raw?.yetToInitiateOnTrack) || 0,
        overdue: Number(raw?.yetToInitiateOverdue) || 0,
        percentage: calculatePercentage(Number(raw?.yetToInitiateTotal) || 0),
      },
    };
  }

  async getReportStatusSummary(dto: GetReportStatusSummaryDto) {
    const { reportNumbers, hlcId } = dto;
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .select('r.reportNumber', 'reportNumber')
      .addSelect('COUNT(r.id)', 'total')
      .addSelect(` SUM(CASE WHEN r.current_status = :fullyImplemented THEN 1 ELSE 0 END) `, 'fullyImplemented')
      .addSelect(` SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) THEN 1 ELSE 0 END) `, 'yetToInitiateTotal')
      .addSelect(` SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END) `, 'yetToInitiateOnTrack')
      .addSelect(` SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END) `, 'yetToInitiateOverdue')
      .addSelect(` SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) THEN 1 ELSE 0 END) `, 'inProgressTotal')
      .addSelect(` SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END) `, 'inProgressOnTrack')
      .addSelect(` SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END) `, 'inProgressOverdue')
      .where('r.reportNumber IS NOT NULL')
      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,
        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,
        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED

      });
    if (hlcId) {
      qb.andWhere('r.hlc_id = :hlcId', { hlcId });
    }
    if (reportNumbers?.length) {
      qb.andWhere('r.reportNumber IN (:...reportNumbers)', { reportNumbers });
    }
    qb.groupBy('r.reportNumber');

    const raw = await qb.getRawMany();
    return raw.map((row) => {
      const total = Number(row.total) || 0;
      const calculatePercentage = (value: number) =>
        total ? Math.round((value / total) * 100) : 0;
      return {
        reportNumber: row.reportNumber,
        total,
        fullyImplemented: {
          count: Number(row.fullyImplemented),
          percentage: calculatePercentage(Number(row.fullyImplemented)),
        },
        inProgress: {
          total: Number(row.inProgressTotal),
          onTrack: Number(row.inProgressOnTrack),
          overdue: Number(row.inProgressOverdue),
          percentage: calculatePercentage(Number(row.inProgressTotal)),
        },
        yetToInitiate: {
          total: Number(row.yetToInitiateTotal),
          onTrack: Number(row.yetToInitiateOnTrack),
          overdue: Number(row.yetToInitiateOverdue),
          percentage: calculatePercentage(Number(row.yetToInitiateTotal)),
        },
      };
    });
  }

  async ministryWiseProgress(dto: MinistryWiseReportDto) {
    const { hlcId } = dto;
    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.department', 'd')
      .select('m.id', 'ministryId')
      .addSelect('m.name', 'ministryName')
      .addSelect('d.id', 'departmentId')
      .addSelect('d.name', 'departmentName')
      .addSelect('COUNT(r.id)', 'total')
      .addSelect(`SUM(CASE WHEN r.current_status = :fullyImplemented THEN 1 ELSE 0 END)`, 'fullyImplemented',)
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) THEN 1 ELSE 0 END)`, 'yetToInitiateTotal',)
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END)`, 'yetToInitiateOnTrack')
      .addSelect(`SUM(CASE WHEN (r.current_status = :yetToInitiate OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END)`, 'yetToInitiateOverdue')
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) THEN 1 ELSE 0 END)`, 'inProgressTotal',)
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 1 ELSE 0 END)`, 'inProgressOnTrack',)
      .addSelect(`SUM(CASE WHEN r.current_status IN (:inProgress, :partiallyImplemented) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 1 ELSE 0 END)`, 'inProgressOverdue',)
      .groupBy('m.id')
      .addGroupBy('m.name')
      .addGroupBy('d.id')
      .addGroupBy('d.name')
      .orderBy('COUNT(r.id)', 'DESC')
      .setParameters({
        fullyImplemented: AllStatusEnum.FULLY_IMPLEMENTED,
        yetToInitiate: AllStatusEnum.YET_TO_INITIATE,
        inProgress: AllStatusEnum.UNDER_IMPLEMENTATION,
        partiallyImplemented: AllStatusEnum.PARTIALLY_IMPLEMENTED
      });
    if (hlcId) {
      qb.andWhere('r.hlc_id = :hlcId', { hlcId });
    }
    const raw = await qb.getRawMany();
    return raw.map((row) => {
      const total = Number(row.total) || 0;
      const calculatePercentage = (value: number) =>
        total ? Math.round((value / total) * 100) : 0;
      return {
        ministryId: row.ministryId,
        ministryName: row.ministryName,
        departmentId: row.departmentId || null,
        departmentName: row.departmentName || null,
        level: row.departmentId ? 'DEPARTMENT' : 'MINISTRY',
        total,
        fullyImplemented: {
          count: Number(row.fullyImplemented) || 0,
          percentage: calculatePercentage(Number(row.fullyImplemented) || 0)
        },
        inProgress: {
          total: Number(row.inProgressTotal) || 0,
          onTrack: Number(row.inProgressOnTrack) || 0,
          overdue: Number(row.inProgressOverdue) || 0,
          percentage: calculatePercentage(Number(row.inProgressTotal) || 0),
        }, yetToInitiate: {
          total: Number(row.yetToInitiateTotal) || 0,
          onTrack: Number(row.yetToInitiateOnTrack) || 0,
          overdue: Number(row.yetToInitiateOverdue) || 0,
          percentage: calculatePercentage(Number(row.yetToInitiateTotal) || 0),
        },
      };
    });
  }

  // async getRecommendationSummary(dto: GetRecommendationSummaryDto, noPagination = false) {
  //   const {
  //     hlcId,
  //     ministryId,
  //     departmentId,
  //     reportNumbers,
  //     status,
  //     detail = false,
  //     recommendations,
  //     page = 1,
  //     limit = 10,
  //   } = dto;

  //   const query = this.recommendationRepository
  //     .createQueryBuilder('r')
  //     .leftJoin('r.recommendationUpdates', 'updates')
  //     .select([
  //       'r.id AS id',
  //       'r.description AS description',
  //       'r.name AS name',
  //       `
  //         CASE
  //           WHEN r.current_status = '${AllStatusEnum.FULLY_IMPLEMENTED}' THEN 'Fully Implemented'
  //           WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' or r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Partially Implemented / Under Progress: Overdue'
  //           WHEN (r.current_status ='${AllStatusEnum.UNDER_IMPLEMENTATION}' or r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') THEN 'Partially Implemented / Under Progress: On Track'
  //           WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' or r.current_status IS NULL) AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Yet to Initiate: Overdue'
  //           WHEN (r.current_status ='${AllStatusEnum.YET_TO_INITIATE}' or r.current_status IS NULL) THEN 'Yet to Initiate: Not Due'
  //         END AS currentstatus
  //       `,
  //       'r.recommendation_slug AS slug',
  //       'r.current_status AS rawstatus',
  //       'updates.id AS updaterecommendationid',
  //       'updates.status AS updatestatus',
  //       'updates.created_at AS updatecreatedat',
  //       'updates.action_taken_by_ministry AS updateactiontakenbyministry',
  //       'updates.reason_not_implemented AS updatereasonnotimplemented'
  //     ])

  //     .where('r.hlc_id = :hlcId', { hlcId });

  //   if (ministryId) {
  //     query.andWhere('r.ministry_id = :ministryId', { ministryId });
  //   }

  //   if (departmentId) {
  //     query.andWhere('r.department_id = :departmentId', { departmentId });
  //   }

  //   if (reportNumbers && reportNumbers.length > 0) {
  //     query.andWhere('r.report_number IN (:...reportNumbers)', {
  //       reportNumbers,
  //     });
  //   }

  //   if (status) {
  //     query.andWhere(`
  //       CASE WHEN r.current_status = :fully THEN 'Fully Implemented' 
  //       WHEN (r.current_status = :under OR r.current_status = :partial) AND COALESCE(r.updated_timeline, r.timeline) < NOW() THEN 'Partially Implemented / Under Progress: Overdue' 
  //       WHEN (r.current_status = :under OR r.current_status = :partial) THEN 'Partially Implemented / Under Progress: On Track' 
  //       WHEN (r.current_status = :yet OR r.current_status IS NULL) AND COALESCE(r.updated_timeline, r.timeline) < NOW() 
  //       THEN 'Yet to Initiate: Overdue' WHEN (r.current_status = :yet OR r.current_status IS NULL) THEN 'Yet to Initiate: Not Due' 
  //       END = :status `,
  //       {
  //         status,
  //         fully: AllStatusEnum.FULLY_IMPLEMENTED,
  //         under: AllStatusEnum.UNDER_IMPLEMENTATION,
  //         partial: AllStatusEnum.PARTIALLY_IMPLEMENTED,
  //         yet: AllStatusEnum.YET_TO_INITIATE
  //       }
  //     );
  //   }

  //   if (recommendations && recommendations.length > 0) {
  //     query.andWhere('r.id IN (:...recs)', {
  //       recs: recommendations,
  //     });
  //   }

  //   if (detail) {
  //     query
  //       .leftJoinAndSelect('r.department', 'department')
  //       .leftJoinAndSelect('r.ministry', 'ministry')
  //       .leftJoinAndSelect(
  //         'r.primaryDepartment',
  //         'primaryDepartment',
  //       )
  //       .leftJoinAndSelect('r.primaryMinistry', 'primaryMinistry')
  //       .leftJoinAndSelect('r.hlc', 'hlc')
  //       .addSelect([
  //         'r.timeline AS timeline',
  //         'r.updated_timeline AS updatedtimeline',
  //         'r.closure_remark AS closureremark',
  //         'r.action_taken_by_ministry AS actiontakenbyministry',
  //         'r.reason_not_implemented AS reasonnotimplemented'
  //       ])
  //   }

  //   query.orderBy('updates.created_at', 'DESC');

  //   const totalQuery = query.clone();

  //   if (!noPagination) {
  //     query.skip((page - 1) * limit).take(limit);
  //   }

  //   // let [raw, total] = await query.getRawAndCount();
  //   const raw = await query.getRawMany();
  //   const total = await totalQuery.getCount()

  //   let grouped: any = {};

  //   raw.forEach((row: any) => {
  //     if (!grouped[row.id]) {
  //       if (detail) {
  //         grouped[row.id] = {
  //           id: row.id,
  //           recommendationSlug: row.slug,
  //           name: row.name,
  //           description: row.description,
  //           status: row.currentstatus,
  //           updatedTimeline: row.updatedtimeline,
  //           timeline: row.timeline,
  //           currentStatus: row.rawstatus,
  //           actionTakenByMinistry: row.actiontakenbyministry,
  //           reasonNotImplemented: row.reasonnotimplemented,
  //           primaryDepartment: {
  //             id: row.primaryDepartment_id,
  //             name: row.primaryDepartment_name
  //           },
  //           primaryMinistry: {
  //             id: row.primaryMinistry_id,
  //             name: row.primaryMinistry_name
  //           },
  //           department: {
  //             id: row.department_id,
  //             name: row.department_name
  //           },
  //           ministry: {
  //             id: row.ministry_id,
  //             name: row.ministry_name
  //           },
  //           closureRemark: row.closureremark,
  //           updates: [],
  //         }
  //       } else {
  //         grouped[row.id] = {
  //           id: row.id,
  //           recommendationSlug: row.slug,
  //           name: row.name,
  //           description: row.description,
  //           status: row.currentstatus,
  //           currentStatus: row.rawstatus,
  //           updates: [],
  //         };
  //       }
  //     }

  //     if (row.updaterecommendationid) {
  //       grouped[row.id].updates.push({
  //         updateId: row.updaterecommendationid,
  //         status: row.updatestatus,
  //         createdAt: row.updatecreatedat,
  //         actionTakenByMinistry: row.updateactiontakenbyministry,
  //         reasonNotImplemented: row.updatereasonnotimplemented
  //       });
  //     }
  //   });

  //   grouped = Object.values(grouped).map((item: any) => {
  //     item.updates.sort(
  //       (a, b) =>
  //         new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  //     );
  //     return item;
  //   });

  //   return noPagination
  //     ? grouped
  //     : { total, page, limit, result: grouped };
  //   // return grouped;
  // }

  async getRecommendationSummary(dto: GetRecommendationSummaryDto, noPagination = false) {
    const {
      hlcId,
      ministryId,
      departmentId,
      reportNumbers,
      status, detail = false,
      recommendations,
      page = 1,
      limit = 10
    } = dto;
    const baseQuery = this.recommendationRepository
      .createQueryBuilder('r')
      .where('r.hlc_id = :hlcId', { hlcId });
    if (ministryId) {
      baseQuery.andWhere('r.ministry_id = :ministryId', { ministryId });
    }
    if (departmentId) {
      baseQuery.andWhere('r.department_id = :departmentId', { departmentId });
    }
    if (reportNumbers?.length) {
      baseQuery.andWhere('r.report_number IN (:...reportNumbers)', { reportNumbers, });
    }
    if (recommendations?.length) {
      baseQuery.andWhere('r.id IN (:...recs)', { recs: recommendations });
    }
    if (status) {
      baseQuery.andWhere(`
        CASE 
          WHEN r.current_status = :fully THEN 'Fully Implemented' 
          WHEN (r.current_status = :under OR r.current_status = :partial) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 'Partially Implemented / Under Progress: Overdue' 
          WHEN (r.current_status = :under OR r.current_status = :partial) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 'Partially Implemented / Under Progress: On Track' 
          WHEN (r.current_status = :yet OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 'Yet to Initiate: Overdue' 
          WHEN (r.current_status = :yet OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 'Yet to Initiate: Not Due' END = :status
        `,
        {
          status,
          fully: AllStatusEnum.FULLY_IMPLEMENTED,
          under: AllStatusEnum.UNDER_IMPLEMENTATION,
          partial: AllStatusEnum.PARTIALLY_IMPLEMENTED,
          yet: AllStatusEnum.YET_TO_INITIATE
        });
    }

    const total = await baseQuery.getCount();
    let ids: number[] = [];
    if (!noPagination) {
      const paginatedIds = await baseQuery.clone()
        .select('r.id', 'id')
        .orderBy('r.id', 'DESC')
        .skip((page - 1) * limit)
        .take(limit)
        .getRawMany();
      ids = paginatedIds.map((r) => r.id);
    } else {
      const allIds = await baseQuery.clone().select('r.id', 'id').getRawMany();
      ids = allIds.map((r) => r.id);
    }

    if (!ids.length) {
      return noPagination ? [] : { total, page, limit, result: [] }
    }

    const query = this.recommendationRepository
      .createQueryBuilder('r')
      .select([
        'r.id AS id',
        'r.description AS description',
        'r.name AS name',
        'r.recommendation_slug AS slug',
        'r.current_status AS rawstatus',
        `CASE 
          WHEN r.current_status = '${AllStatusEnum.FULLY_IMPLEMENTED}' THEN 'Fully Implemented' 
          WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 'Partially Implemented / Under Progress: Overdue' 
          WHEN (r.current_status = '${AllStatusEnum.UNDER_IMPLEMENTATION}' OR r.current_status = '${AllStatusEnum.PARTIALLY_IMPLEMENTED}') AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 'Partially Implemented / Under Progress: On Track' 
          WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') < CURRENT_DATE THEN 'Yet to Initiate: Overdue' 
          WHEN (r.current_status = '${AllStatusEnum.YET_TO_INITIATE}' OR r.current_status IS NULL) AND DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') >= CURRENT_DATE THEN 'Yet to Initiate: Not Due'
        END 
          AS currentstatus
        `,
        'updates.id AS updaterecommendationid',
        'updates.status AS updatestatus',
        'updates.created_at AS updatecreatedat',
        'updates.action_taken_by_ministry AS updateactiontakenbyministry',
        'updates.reason_not_implemented AS updatereasonnotimplemented',
        'ministry.name AS ministry',
        'department.name as department',
        'primaryMinistry.name AS primaryministry',
        'primaryDepartment.name as primarydepartment'
      ])
      .leftJoin(
        'r.recommendationUpdates',
        'updates',
        'updates.ministry_approver_status = :approvalStatus',
        { approvalStatus: ImplementationStatusEnum.APPROVED })
      .leftJoin('r.department', 'department')
      .leftJoin('r.ministry', 'ministry')
      .leftJoin(
        'r.primaryDepartment',
        'primaryDepartment',
      )
      .leftJoin('r.primaryMinistry', 'primaryMinistry')
      .where('r.hlc_id = :hlcId', { hlcId })
      .andWhere('r.id IN (:...ids)', { ids })
      // .andWhere('updates.ministry_approver_status = :approvalStatus', { approvalStatus: ImplementationStatusEnum.APPROVED })
      .orderBy('r.recommendationSlug', 'ASC')
      .addOrderBy('updates.created_at', 'DESC');
    const raw = await query.getRawMany();

    console.log(raw[0])
    const grouped: any = {};
    raw.forEach((row: any) => {
      if (!grouped[row.id]) {
        grouped[row.id] = {
          id: row.id,
          recommendationSlug: row.slug,
          name: row.name,
          description: row.description,
          status: row.currentstatus,
          currentStatus: row.rawstatus,
          primaryMinistry: { name: row.primaryministry },
          primaryDepartment: { name: row.primarydepartment },
          ministry: { name: row.ministry },
          department: { name: row.department },
          updates: []
        }
      }

      if (row.updaterecommendationid) {
        grouped[row.id].updates.push({
          updateId: row.updaterecommendationid,
          status: row.updatestatus,
          createdAt: row.updatecreatedat,
          actionTakenByMinistry: row.updateactiontakenbyministry,
          reasonNotImplemented: row.updatereasonnotimplemented
        });
      }
    });
    const result = Object.values(grouped);
    return noPagination
      ? result
      : {
        total,
        page,
        limit,
        result
      };
  }

  async export(query: GetRecommendationSummaryDto) {
    const { format, detail = false } = query;
    const recommendations: any = await this.getRecommendationSummary(query, true);

    const data: any[] = [];
    recommendations.forEach((r) => {
      if (detail) {
        data.push({
          'Serial No. of HLC Recommendation': r.recommendationSlug,
          Description: r.description,
          Recommendations: r.name,
          Timeline: r.timeline
            ? new Date(r.timeline).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
            : '-',
          'Primary Ministry/Department': r.primaryDepartment?.name
            ? `${r.primaryMinistry?.name} / ${r.primaryDepartment?.name}`
            : r.primaryMinistry?.name,
          'Implementing Ministry/Department': r.department?.name
            ? `${r.ministry?.name} / ${r.department?.name}`
            : r.ministry?.name,
          'Implementation Status':
            r.updates.length > 0
              ? r.updates[0].status
              : r.currentStatus,
          'Details of Action Taken(To be entered by the Ministry)':
            r.updates.length > 0
              ? `${new Date(
                r.updates[0].createdAt,
              ).toLocaleDateString('en-IN', {
                timeZone: 'Asia/Kolkata',
                month: 'short',
                day: '2-digit',
                year: 'numeric',
              })}:\n${r.updates[0].actionTakenByMinistry}`
              : r.actionTakenByMinistry,
          'Reason If Not Implemented':
            r.updates.length > 0
              ? r.updates[0].reasonNotImplemented
              : r.reasonNotImplemented,
          'Updated Timeline': r.updatedTimeline
            ? new Date(r.updatedTimeline).toLocaleDateString('en-IN', {
              timeZone: 'Asia/Kolkata',
              month: 'short',
              day: '2-digit',
              year: 'numeric',
            })
            : '-',
          'Closure Remarks': r.closureRemark || '-',
        });

        if (r?.updates && r.updates.length > 1) {
          const updates = r.updates.splice(1);
          for (let item of updates) {

            data.push({
              'Serial No. of HLC Recommendation': '',
              Description: '',
              Recommendations: '',
              Timeline: '',
              'Primary Ministry/Department': '',
              'Implementing Ministry/Department': '',
              'Implementation Status': item.status,
              'Details of Action Taken(To be entered by the Ministry)': `${new Date(
                item.createdAt,
              ).toLocaleDateString('en-IN', {
                timeZone: 'Asia/Kolkata',
                month: 'short',
                day: '2-digit',
                year: 'numeric',
              })}:\n${item.actionTakenByMinistry}`,
              'Reason If Not Implemented': item.reasonNotImplemented,
              'Updated Timeline': '',
            });
          }
        }
      } else {
        data.push({
          'Recommendation Id': r.recommendationSlug,
          Description: r.description,
          Status: r.status,
          'Implementation Status': r.currentStatus,
          'Latest Update': r?.updates[0]?.createdAt ? new Date(r?.updates[0]?.createdAt).toLocaleDateString('en-IN', {
            timeZone: 'Asia/Kolkata',
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          }) : '-',
          'Details of Action Taken(To be entered by the Ministry)': r?.updates[0]?.actionTakenByMinistry || '-'
        });

        if (r?.updates && r.updates.length > 1) {
          const updates = r.updates.splice(1);
          for (let item of updates) {
            data.push({
              'Recommendation Id': '',
              Description: '',
              Status: '',
              'Implementation Status': r.currentStatus,
              'Latest Update': item.createdAt ? new Date(item.createdAt).toLocaleDateString('en-IN', {
                timeZone: 'Asia/Kolkata',
                month: 'short',
                day: '2-digit',
                year: 'numeric',
              }) : '-',
              'Details of Action Taken(To be entered by the Ministry)': item.actionTakenByMinistry
            });
          }
        }
      }
    });

    if (format === FormatEnum.EXCEL) {
      const worksheet = XLSX.utils.json_to_sheet(data);
      let columnWidths: any[] = []
      if (detail) {
        columnWidths = [
          { wch: 10 }, // 'Serial No. of HLC Recommendation'
          { wch: 30 }, // Description
          { wch: 20 }, // Recommendations
          { wch: 15 }, // Timeline
          { wch: 40 }, // Ministry/Department
          { wch: 20 }, // Implementation Status
          { wch: 40 }, // Details of Action Taken
          { wch: 30 }, // Reason If Not Implemented
          { wch: 15 }, // Updated Timeline
        ];
      } else {
        columnWidths = [
          { wch: 20 }, // 'Serial No. of HLC Recommendation'
          { wch: 40 }, // Description
          { wch: 20 }, // Recommendations
          { wch: 25 }, // Timeline
          { wch: 25 }, // Timeline
        ];
      }


      worksheet['!cols'] = columnWidths;
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Recommendations');
      return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    }
    if (format === FormatEnum.CSV) {
      const parser = new Parser();
      const csv = parser.parse(data);
      return Buffer.from(csv);
    }
    if (format === FormatEnum.PDF) {
      return this.generatePdf(data, detail);
    }
  }

  async generatePdf(data: any[], detail = false) {
    const fonts = {
      Helvetica: {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        italics: 'Helvetica-Oblique',
        bolditalics: 'Helvetica-BoldOblique'
      }
    };
    var printer = new PdfPrinter(fonts)

    const headers = Object.keys(data[0]);
    const body = [
      headers.map(h => ({ text: h, bold: true })),
      ...data.map(row => headers.map(h => row[h] || ''))
    ];
    const docDefinition: any = {
      pageOrientation: 'landscape',
      defaultStyle: {
        font: 'Helvetica',
        fontSize: 8
      },
      content: [
        { text: 'HLC Recommendation Report', style: 'header' },
        {
          table: {
            headerRows: 1,
            // widths: Array(headers.length).fill('*'),
            widths: detail ? [
              50,
              80,
              80,
              40,
              60,
              60,
              50,
              100,
              50,
              40,
              40,
            ] : Array(headers.length).fill('*'),
            body: body
          }
        }],
      footer: (currentPage, pageCount) => {
        return {
          text: `Page ${currentPage} of ${pageCount}`,
          alignment: 'center'
        };
      },
      styles: {
        header: {
          fontSize: 16,
          bold: true,
          alignment: 'center',
          margin: [0, 0, 0, 20]
        }
      }
    };
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks: any[] = [];
    return new Promise((resolve) => {
      pdfDoc.on('data', (chunk: any) => chunks.push(chunk));
      pdfDoc.on('end', () => { resolve(Buffer.concat(chunks)); });
      pdfDoc.end();
    });
  }
}

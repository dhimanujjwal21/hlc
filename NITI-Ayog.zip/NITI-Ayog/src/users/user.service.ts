import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository, DataSource, Like } from 'typeorm';
import { User } from '../entities/users.entity';
import * as bcrypt from 'bcrypt';
import {
  ChangeRoleDto,
  LoginUserDto,
  NodalOfficerDto,
  RegisterUserDto,
  UpdateUserDto,
  UpdateUserPasswordDto,
} from './dto/users.dto';
import { Role } from 'src/entities/roles.entity';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Hlc } from 'src/entities/hlc.entity';
import { UserHlc } from 'src/entities/user-hlc.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Departments } from 'src/entities/departments.entity';
import { RoleEnum } from 'src/constants/enums';
import { NODAL_OFFICERS } from 'src/constants/nodalOfficer';
import { UserRoles } from 'src/entities/user-roles.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Role)
    private readonly roleRepository: Repository<Role>,

    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,

    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,

    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,

    @InjectRepository(UserHlc)
    private readonly userHlcRepository: Repository<UserHlc>,

    @InjectRepository(UserRoles)
    private readonly userRolesRepository: Repository<UserRoles>,

    private readonly jwtService: JwtService,

    private configService: ConfigService,

    private dataSource: DataSource,
  ) {}

  async fetchMyProfileOld(email: string) {
    const user: any = await this.userRepository.findOne({
      where: { email },
      relations: [
        'role',
        'role.rolePermissions',
        'role.rolePermissions.permission',
        'ministry',
        'userHlcs',
        'userHlcs.hlc',
        'userIgoms',
        'userIgoms.igom',
        'department',
      ],
    });

    const role = user.role;
    const roleName = role?.roleName ?? null;
    const permissions =
      role?.rolePermissions?.map((rp) => rp.permission.permissionName) ?? [];

    return {
      id: user.id,
      name: user.displayName || user.name,
      email: user.email,
      role: roleName,
      permissions,
      ministry: user.ministry
        ? {
            id: user.ministry.id,
            name: user.ministry.name,
          }
        : null,
      department: user.department
        ? {
            id: user.department.id,
            name: user.department.name,
          }
        : null,
      dashboardView: user.dashboardView,
      viewingAccess: user.viewingAccess,
      lastLogin: user.lastLogin,
      hlcs: user.userHlcs.map((u) => u.hlc),
      igoms: user.userIgoms.map((u) => u.igom),
    };
  }

  async fetchMyProfile(email: string) {
    const user: any = await this.userRepository.findOne({
      where: { email },
      relations: [
        'role.rolePermissions.permission',
        'userRoles.role.rolePermissions.permission',
        'ministry',
        'userHlcs.hlc',
        'userIgoms.igom',
        'department',
      ],
    });

    const role = user.role;
    const roleName = role?.roleName ?? null;
    const permissions =
      role?.rolePermissions?.map((rp) => rp.permission.permissionName) ?? [];

    // All assigned roles with their permissions
    const allRoles =
      user.userRoles
        ?.filter((ur) => ur.isActive)
        .map((ur) => ({
          id: ur.role.id,
          name: ur.role.roleName,
          type: ur.role.type,
          permissions:
            ur.role.rolePermissions?.map(
              (rp) => rp.permission.permissionName,
            ) ?? [],
          assignedAt: ur.assignedAt,
        })) ?? [];

    return {
      id: user.id,
      name: user.displayName || user.name,
      email: user.email,
      role: roleName, // current active role
      permissions, // active role permissions
      allRoles, // all assigned roles
      ministry: user.ministry
        ? {
            id: user.ministry.id,
            name: user.ministry.name,
          }
        : null,
      department: user.department
        ? {
            id: user.department.id,
            name: user.department.name,
          }
        : null,
      dashboardView: user.dashboardView,
      viewingAccess: user.viewingAccess,
      homeView: user.homeView,
      lastLogin: user.lastLogin,
      hlcs: user.userHlcs.map((u) => u.hlc),
      igoms: user.userIgoms.map((u) => u.igom),
    };
  }

  async create(data: Partial<User>): Promise<User> {
    const user = this.userRepository.create(data);
    return await this.userRepository.save(user);
  }

  async findByEmail(email: string): Promise<User | null> {
    return await this.userRepository.findOne({
      where: { email },
      relations: ['role'],
    });
  }

  async login(payload: LoginUserDto) {
    const email = payload.email.trim().toLowerCase();
    const password = payload.password;

    const user = await this.userRepository.findOne({
      where: { email },
      relations: [
        'role',
        'role.rolePermissions',
        'role.rolePermissions.permission',
        'ministry',
        'userHlcs',
        'userHlcs.hlc',
        'userIgoms',
        'userIgoms.igom',
      ],
    });

    const invalidError = new BadRequestException('Invalid credentials');

    if (!user) {
      throw invalidError;
    }

    if (user && user.isDisabled) {
      throw new NotFoundException('User does not exists');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw invalidError;
    }

    const role = user.role;
    const roleName = role?.roleName ?? null;
    const permissions =
      role?.rolePermissions?.map((rp) => rp.permission.permissionName) ?? [];

    const jwtPayload = {
      id: user.id,
      email: user.email,
      roleId: role?.id ?? null,
      ministryId: user.ministry?.id ?? null,
      roleName,
      permissions,
      dashboardView: user.dashboardView,
      viewingAccess: user.viewingAccess,
      loginProcess: 'native',
    };

    const token = await this.jwtService.signAsync(jwtPayload, {
      secret: this.configService.get<string>('JWT_SECRET'),
      expiresIn: this.configService.get<string>('JWT_EXPIRES_IN') ?? '30m',
    } as any);

    await this.userRepository.update(user.id, {
      lastLogin: new Date(),
    });

    return {
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.displayName || user.name,
        email: user.email,
        role: roleName,
        permissions,
        ministry: user.ministry
          ? {
              id: user.ministry.id,
              name: user.ministry.name,
            }
          : null,
        dashboardView: user.dashboardView,
        viewingAccess: user.viewingAccess,
        homeView: user.homeView,
        lastLogin: user.lastLogin,
        hlcs: user.userHlcs.map((u) => u.hlc),
        igoms: user.userIgoms.map((u) => u.igom),
      },
      token,
    };
  }

  async getUserList() {
    const users = await this.userRepository.find({
      relations: ['role', 'ministry'],
    });

    return users.map((user: any) => {
      const { password, ...userDetails } = user;
      return userDetails;
    });
  }

  async registerUser(payload: RegisterUserDto) {
    const {
      email,
      password,
      name,
      roleId,
      hlcIds = [],
      ministryId,
      departmentId,
      mobileNumber,
      displayName,
      dashboardView = false,
    } = payload;

    const normalizedEmail = email?.toLowerCase().trim();
    if (!normalizedEmail) {
      throw new BadRequestException('Email is required');
    }

    const existingUser = await this.findByEmail(normalizedEmail);
    if (existingUser) {
      throw new BadRequestException('Email already registered');
    }

    const [role, ministry, department] = await Promise.all([
      roleId
        ? this.roleRepository.findOne({ where: { id: roleId } })
        : Promise.resolve(null),

      ministryId
        ? this.ministryRepository.findOne({ where: { id: ministryId } })
        : Promise.resolve(null),

      departmentId
        ? this.departmentRepository.findOne({
            where: { id: departmentId },
            relations: ['ministry'],
          })
        : Promise.resolve(null),
    ]);

    if (roleId && !role) {
      throw new BadRequestException('Role does not exist');
    }

    if (ministryId && !ministry) {
      throw new BadRequestException('Ministry does not exist');
    }

    if (departmentId && !department) {
      throw new BadRequestException('Department does not exist');
    }

    if (department && department.ministry?.id !== ministryId) {
      throw new BadRequestException('Department is not of this ministry');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await this.create({
      name: name?.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      role,
      ministry,
      department,
      mobileNumber,
      displayName,
      dashboardView: dashboardView || false,
    });

    if (hlcIds.length > 0) {
      const hlcs = await this.hlcRepository.find({
        where: { id: In(hlcIds) },
      });

      if (hlcs.length !== hlcIds.length) {
        throw new BadRequestException(
          'Some HLC IDs are invalid or do not exist',
        );
      }

      await Promise.all(
        hlcs.map((hlc) =>
          this.userHlcRepository.save(
            this.userHlcRepository.create({ user, hlc }),
          ),
        ),
      );
    }

    return {
      message: 'User registered successfully',
      user: {
        id: user.id,
        name: user.name,
        displayName: user.displayName,
        email: user.email,
        role: role ? role.roleName : null,
        ministry: ministry ? ministry.name : null,
        department: department ? department.name : null,
      },
    };
  }

  async updateUser(id: number, data: UpdateUserDto) {
    return await this.dataSource.transaction(async (manager) => {
      const user = await manager.findOne(this.userRepository.target, {
        where: { id },
        relations: ['role', 'ministry'],
      });

      if (!user) {
        throw new BadRequestException('User not found');
      }

      if (data.email && data.email !== user.email) {
        const existing = await manager.findOne(this.userRepository.target, {
          where: { email: data.email.toLowerCase() },
        });
        if (existing && existing.id !== id)
          throw new BadRequestException('Email already in use');

        user.email = data.email.toLowerCase();
      }

      if (data.name) user.name = data.name;
      if (data.displayName) user.displayName = data.displayName;
      if (data.mobileNumber) user.mobileNumber = data.mobileNumber;
      if (typeof data.dashboardView === 'boolean')
        user.dashboardView = data.dashboardView;
      if (data.disable) user.isDisabled = data.disable;

      if (data.password) {
        const salt = await bcrypt.genSalt();
        user.password = await bcrypt.hash(data.password, salt);
      }

      if (data.roleId) {
        const role = await manager.findOne(this.roleRepository.target, {
          where: { id: data.roleId },
        });
        if (!role) throw new BadRequestException('Role does not exist');

        user.role = role;
      }

      if (data.ministryId) {
        const ministry = await manager.findOne(this.ministryRepository.target, {
          where: { id: data.ministryId },
        });
        if (!ministry) throw new BadRequestException('Ministry does not exist');

        user.ministry = ministry;
      }

      if (data.departmentId) {
        const department = await manager.findOne(
          this.departmentRepository.target,
          {
            where: { id: data.departmentId },
          },
        );
        if (!department)
          throw new BadRequestException('Deartment does not exist');
        if (department && department.ministry?.id !== data.ministryId)
          throw new BadRequestException('Department is not of this ministry');
        user.department = department;
      }

      if (data.hlcIds) {
        await manager.delete(this.userHlcRepository.target, { user: { id } });
        if (data.hlcIds.length > 0) {
          const hlcs = await manager.find(this.hlcRepository.target, {
            where: { id: In(data.hlcIds) },
          });

          const mappings = hlcs.map((hlc) =>
            manager.create(this.userHlcRepository.target, { user, hlc }),
          );

          await manager.save(this.userHlcRepository.target, mappings);
        }
      }

      user.updatedAt = new Date();

      return await manager.save(this.userRepository.target, user);
    });
  }

  async updateUserPassword(id: number, data: UpdateUserPasswordDto) {
    const { currentPassword, password, confirmPassword } = data;

    const user = await this.userRepository.findOne({
      where: { id },
    });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    const isCurrentPasswordValid = await bcrypt.compare(
      currentPassword,
      user.password,
    );

    if (!isCurrentPasswordValid) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    if (password !== confirmPassword) {
      throw new BadRequestException(
        'Password and confirm password do not match',
      );
    }

    const isSamePassword = await bcrypt.compare(password, user.password);

    if (isSamePassword) {
      throw new BadRequestException(
        'New password must be different from current password',
      );
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    user.password = hashedPassword;
    user.updatedAt = new Date();

    await this.userRepository.save(user);

    return {
      message: 'Password updated successfully',
    };
  }

  async switchRole(userId: number, data: ChangeRoleDto) {
    const role = await this.roleRepository.findOne({
      where: { id: data.roleId },
    });
    const assigned = await this.userRolesRepository.findOne({
      where: {
        user: { id: userId },
        role: { id: data.roleId },
      },
    });

    if (!assigned) throw new ForbiddenException('Role not assigned to user');

    if (!assigned.isActive) throw new BadRequestException('Role not active');

    await this.userRepository.update(
      {
        id: userId,
      },
      {
        role,
      },
    );
  }

  async fetchNodalOfficer(query: NodalOfficerDto) {
    return { users: NODAL_OFFICERS };
    // const { search, roleId, ministryId, departmentId, page = 1, limit = 500 } = query;

    // // Count total users matching the filters
    // const [users, total] = await this.userRepository.findAndCount({
    //   select: [
    //     'id',
    //     'name',
    //     'email',
    //     'designation',
    //     'mobileNumber',
    //     'ministry',
    //     'department'
    //   ],
    //   relations: ['role', 'ministry', 'department'],
    //   where: {
    //     ...(roleId ? { role: { id: roleId } } : {}),
    //     ...(ministryId ? { ministry: { id: ministryId } } : {}),
    //     ...(departmentId ? { department: { id: departmentId } } : {}),
    //     ...(search ? {
    //       name: Like(`%${search}%`)
    //     } : {}),
    //     role: {
    //       roleName: In([
    //         RoleEnum.MINISTRY_APPROVER,
    //         RoleEnum.MINISTRY_DIRECTOR,
    //         RoleEnum.MINISTRY_SECRETARY
    //       ])
    //     }
    //   },
    //   skip: (page - 1) * limit,
    //   take: limit
    // });

    // const totalPages = Math.ceil(total / limit);
    // return {
    //   users,
    //   pagination: {
    //     total,
    //     page,
    //     limit,
    //     totalPages
    //   }
    // };
  }

  async assignRoles() {
    const users = await this.userRepository
      .createQueryBuilder()
      .select(['id', 'role_id'])
      .getRawMany();
    console.log(users[0]);
    const userRoles = users
      .filter((user) => user.role_id)
      .map((user) => ({
        user: { id: user.id },
        role: { id: user.role_id },
        isActive: true,
      }));

    console.log(userRoles[0]);
    await this.userRolesRepository
      .createQueryBuilder()
      .insert()
      .into('t_user_roles')
      .values(userRoles)
      .orIgnore()
      .execute();
    return {
      message: `Inserted all roles, user roles ${userRoles.length} and users ${users.length}`,
    };
  }
}

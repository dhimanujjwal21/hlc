import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class UserResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 'John Doe' })
  name: string;

  @ApiProperty({ example: 'john@example.com' })
  email: string;

  @ApiProperty({ example: '9999999999' })
  mobileNumber: string;

  @ApiPropertyOptional({ example: 2, description: 'Role ID (null if not assigned)' })
  role?: number;

  @ApiPropertyOptional({ example: 1, description: 'Ministry Id (null if not assigned)'})
  ministry?: number;

  @ApiProperty({ example: '2025-11-07T10:00:00Z' })
  createdAt: string;
}

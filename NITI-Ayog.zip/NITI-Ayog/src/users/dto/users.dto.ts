import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsEmail,
  IsNotEmpty,
  MinLength,
  IsString,
  IsOptional,
  IsInt,
  ArrayUnique,
  IsArray,
  IsBoolean,
  MaxLength,
  Matches,
} from 'class-validator';

export class RegisterUserDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Unique email address of the user',
  })
  @IsNotEmpty({ message: 'Email is required' })
  @IsEmail({}, { message: 'Invalid email format' })
  email: string;

  @ApiProperty({
    example: 'password123',
    description: 'User password (min 6 characters)',
  })
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(6, { message: 'Password must be at least 6 characters long' })
  password: string;

  @ApiProperty({ example: 'John Doe', description: 'Full name of the user' })
  @IsNotEmpty({ message: 'Name is required' })
  @IsString({ message: 'Name must be a string' })
  name: string;

  @ApiPropertyOptional({
    example: 'John Doe',
    description: 'Full name of the user',
  })
  @IsString({ message: 'Display Name must be a string' })
  @IsOptional()
  displayName: string;

  @ApiPropertyOptional({
    example: '+911234567890',
    description: 'Mobile number of the user',
  })
  @IsOptional()
  @IsString()
  mobileNumber?: string;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional role ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Role must be a number' })
  roleId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional ministry ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Ministry must be a number' })
  ministryId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional department ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Department must be a number' })
  departmentId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  dashboardView: boolean;

  @ApiPropertyOptional({
    example: [1, 2],
    description: 'List of HLC IDs to assign to this user',
    type: [Number],
  })
  @IsOptional()
  @IsArray({ message: 'hlcIds must be an array of numbers' })
  @ArrayUnique({ message: 'HLC IDs must be unique' })
  hlcIds?: number[];
}

export class LoginUserDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'Registered user email',
  })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'password123', description: 'User password' })
  @IsNotEmpty()
  @MinLength(6)
  password: string;
}

export class UpdateUserDto {
  @ApiPropertyOptional({
    example: 'user@example.com',
    description: 'Unique email address of the user',
  })
  @IsOptional()
  @IsNotEmpty({ message: 'Email is required' })
  @IsEmail({}, { message: 'Invalid email format' })
  email: string;

  @ApiPropertyOptional({ example: 'John Doe' })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional({
    example: 'John Doe',
    description: 'Full name of the user',
  })
  @IsString({ message: 'Display Name must be a string' })
  @IsOptional()
  displayName: string;

  @ApiPropertyOptional({ example: 'newStrongPassword123' })
  @IsOptional()
  @IsString()
  @MinLength(6)
  password?: string;

  @ApiPropertyOptional({
    example: '+911234567890',
    description: 'Mobile number of the user',
  })
  @IsOptional()
  @IsString()
  mobileNumber?: string;

  @ApiPropertyOptional({
    example: [1, 2],
    description: 'List of HLC IDs to assign to this user',
    type: [Number],
  })
  @IsOptional()
  @IsArray({ message: 'hlcIds must be an array of numbers' })
  @ArrayUnique({ message: 'HLC IDs must be unique' })
  hlcIds?: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  dashboardView: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  disable: boolean;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional role ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Role must be a number' })
  roleId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional ministry ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Ministry must be a number' })
  ministryId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional department ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Department must be a number' })
  departmentId?: number;
}

export class UpdateUserPasswordDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty({ message: 'Current password is required' })
  currentPassword!: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(12, {
    message: 'Password must be at least 12 characters long',
  })
  @MaxLength(128)
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/, {
    message:
      'Password must contain uppercase, lowercase, number and special character',
  })
  password!: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty({ message: 'Confirm password is required' })
  confirmPassword!: string;
}

export class NodalOfficerDto {
  @ApiPropertyOptional({
    description: 'Page number for pagination',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  page?: number = 1;

  @ApiPropertyOptional({ description: 'Number of items per page' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  limit?: number = 10;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString({ message: 'Search must be a string' })
  search?: string;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional role ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Role must be a number' })
  roleId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional ministry ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Ministry must be a number' })
  ministryId?: number;

  @ApiPropertyOptional({
    example: 2,
    required: false,
    description: 'Optional department ID for the user',
  })
  @IsOptional()
  @IsInt({ message: 'Department must be a number' })
  departmentId?: number;
}

export class ChangeRoleDto {
  @ApiProperty()
  @IsInt({ message: 'Role must be a number' })
  roleId?: number;
}

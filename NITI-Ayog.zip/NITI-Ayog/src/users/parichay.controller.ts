import { Controller, Get, Res, Req, Query } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiTags } from '@nestjs/swagger';
import { ParichayService } from './parichay.service';

@ApiTags('Parichay')
@Controller({
  path: '',
  version: '1',
})
export class ParichayController {
  constructor(private parichayService: ParichayService) {}

  @Get('parichay-login')
  async getParichayLogin(
    // @Res() res
  ) { // @Res() res
    const redirectUrl = await this.parichayService.parichayLogin();
    return redirectUrl;
    // return res.redirect(redirectUrl);
  }

  @Get('redirect-parichay')
  async redirectParichay(
    @Query('string') handshakingId: string,
    @Query('status') status: string,
    @Res() res,
  ) {
    const frontendUrl = process.env.FRONTEND_URL;

    // 2️⃣ Missing handshake
    if (!handshakingId) {
      return res.redirect(
        `${frontendUrl}?status=failure&error=missing_handshake_id`,
      );
    }

    // 3️⃣ Process callback
    const result = await this.parichayService.callbackParichay(handshakingId);

    // 4️⃣ Internal failure
    if (!result?.success) {
      const reason = encodeURIComponent(result?.reason || 'login_failed');
      return res.redirect(
        `${frontendUrl}?status=failure&error=${reason}`,
      );
    }

    // 5️⃣ SUCCESS
    return res.redirect(
      `${frontendUrl}?status=success&token=${result.token}`,
    );
  }
}

import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import axios, { AxiosInstance } from 'axios';
import { User } from 'src/entities/users.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ParichayService {
  private readonly PARICHAY_LOGIN_URL: string;
  private readonly SERVICE_NAME: string;

  private readonly cryptoClient: AxiosInstance;

  constructor(
    private readonly configService: ConfigService,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    private readonly jwtService: JwtService,
  ) {
    this.PARICHAY_LOGIN_URL =
      this.configService.get<string>('PARICHAY_LOGIN_URL') ?? '';

    this.SERVICE_NAME = this.configService.get<string>('SERVICE_NAME') ?? '';

    /** Axios instance for local crypto service */
    this.cryptoClient = axios.create({
      baseURL: `${this.configService.get<string>('PROXY_URL')}:${this.configService.get<string>('PROXY_PORT')}`,
      timeout: 3000,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  /**
   * Generate Client Signature (cs)
   */
  private async generateHMAC(tid: number): Promise<string> {
    const rawString = `Parichay${tid}${this.PARICHAY_LOGIN_URL}${this.SERVICE_NAME}`;
    try {
      const { data } = await this.cryptoClient.post('/hmac', {
        hmacString: rawString,
      });

      if (!data?.data?.signature) {
        throw new Error('Invalid HMAC response');
      }

      return data.data.signature;
    } catch (err) {
      throw new InternalServerErrorException('Failed to generate HMAC');
    }
  }

  /**
   * Encrypt Session ID
   */
  private async encryptSessionId(sessionId: string): Promise<string> {
    try {
      const { data } = await this.cryptoClient.post('/encryption', {
        AESString: sessionId,
      });

      if (!data?.data?.signature) {
        throw new Error('Invalid encryption response');
      }

      return data.data.signature;
    } catch (err) {
      throw new InternalServerErrorException('Failed to encrypt session ID');
    }
  }

  /**
   * Decrypt Session ID
   */
  private async decrypt(encryptedString: string): Promise<string> {
    try {
      const { data } = await this.cryptoClient.post('/decryption', {
        EncryptedString: encryptedString,
      });
      if (!data?.data?.signature) {
        throw new Error('Invalid encryption response');
      }

      return data.data.signature;
    } catch (err) {
      console.log('error ->', err);
      throw new InternalServerErrorException('Failed to decrypt session ID');
    }
  }

  private async handshake(handshakingId: string): Promise<any> {
    try {
      const { data } = await this.cryptoClient.get(
        `/handshake/${handshakingId}/${this.SERVICE_NAME}`,
      );
      return data;
    } catch (err) {
      throw new InternalServerErrorException('Failed to handshake');
    }
  }

  async parichayAllLogout(user: {
    userName: string;
    sessionId: string;
    browserId: string;
    localTokenId: string;
  }) {
    try {
      const { data } = await this.cryptoClient.get(
        `/logoutAll` +
          `?userName=${encodeURIComponent(user.userName)}` +
          `&service=${encodeURIComponent(this.SERVICE_NAME)}` +
          `&sessionId=${encodeURIComponent(user.sessionId)}` +
          `&browserId=${encodeURIComponent(user.browserId)}` +
          `&localTokenId=${encodeURIComponent(user.localTokenId)}`,
      );

      return data?.status === 'success';
    } catch (error) {
      throw new InternalServerErrorException('Parichay global logout failed');
    }
  }

  /**
   * Build Parichay Redirect URL
   */
  async parichayLogin(): Promise<string> {
    const tid = Date.now();
    const clientSessionId = `HLC-${tid}`;

    const cs = await this.generateHMAC(tid);
    const encryptedSessionId = await this.encryptSessionId(clientSessionId);

    const redirectUrl =
      `${this.PARICHAY_LOGIN_URL}` +
      `?sid=${encodeURIComponent(this.SERVICE_NAME)}` +
      `&tid=${tid}` +
      `&cs=${encodeURIComponent(cs)}` +
      `&string=${encodeURIComponent(encryptedSessionId)}`;

    return redirectUrl;
  }

  async callbackParichay(handshakingId: string) {
    if (!handshakingId) {
      return {
        success: false,
        reason: 'Handshake Id Missing',
      };
    }

    const encryptedData = await this.handshake(handshakingId);

    if (encryptedData == 'False') {
      return {
        success: false,
        reason: 'Handshake Failed',
      };
    }

    const decryptedPayload: any = await this.decrypt(encryptedData);

    if (!decryptedPayload) {
      return {
        success: false,
        reason: 'Login Failed',
      };
    }

    // console.log('User ---> ', decryptedPayload);

    const relations = [
      'role',
      'role.rolePermissions',
      'role.rolePermissions.permission',
      'ministry',
      'userHlcs',
      'userHlcs.hlc',
    ];

    const user = await this.userRepository.findOne({
      where: [
        { email: decryptedPayload.email },
        { email: decryptedPayload.userName },
      ],
      relations,
    });

    if (!user) {
      return {
        success: false,
        reason:
          'The provided email address or mobile number is not registered on the HLC Sameeksha portal. Please try again with valid registered credentials.',
      };
    }

    if (user && user.isDisabled) {
      return {
        success: false,
        reason:
          'User does not exist',
      };
    }

    // 5. Prepare role & permissions
    const roleName = user.role?.roleName;
    const permissions =
      user.role?.rolePermissions?.map((rp) => rp.permission.permissionName) ??
      [];

    const jwtPayload = {
      id: user.id,
      email: user.email,
      roleId: user.role?.id ?? null,
      ministryId: user.ministry?.id ?? null,
      roleName,
      permissions,
      dashboardView: user.dashboardView,
      sessionId: decryptedPayload.sessionId,
      userName: decryptedPayload.userName,
      localTokenId: decryptedPayload.localTokenId,
      browserId: decryptedPayload.browserId,
      loginProcess: 'parichay',
    };

    const token = await this.jwtService.signAsync(jwtPayload, {
      secret: this.configService.get<string>('JWT_SECRET'),
      expiresIn: this.configService.get<string>('JWT_EXPIRES_IN') ?? '30m',
    } as any);

    await this.userRepository.update(user.id, {
      lastLogin: new Date(),
    });

    // 8. Final response (controller will redirect using this)
    return {
      success: true,
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.displayName || user.name,
        email: user.email,
        role: roleName,
        permissions,
        ministry: user.ministry
          ? {
              id: user.ministry.id,
              name: user.ministry.name,
            }
          : null,
        dashboardView: user.dashboardView,
        lastLogin: user.lastLogin,
        hlcs: user.userHlcs.map((u) => u.hlc),
      },
      token,
    };
  }

  async logout(token: string) {
    try {
      const user = await this.jwtService.verifyAsync(token, {
        secret: this.configService.get<string>('JWT_SECRET'),
        // publicKey
      });
      if (user?.loginProcess === 'parichay') {
        const parichayLoggedOut = await this.parichayAllLogout({
          userName: user.userName,
          sessionId: user.sessionId,
          browserId: user.browserId,
          localTokenId: user.localTokenId,
        });

        return {
          success: parichayLoggedOut,
          message: parichayLoggedOut
            ? 'Logout successful'
            : 'Logout partially completed',
        };
      }
      return {
        success: true,
        message: 'Logout successful',
      };
    } catch (error) {
      return {
        success: false,
        message: 'Logout completed locally, Parichay logout failed',
      };
    }
  }
}

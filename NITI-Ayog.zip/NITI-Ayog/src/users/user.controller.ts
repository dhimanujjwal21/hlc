import {
  Controller,
  Post,
  Body,
  BadRequestException,
  UseGuards,
  Put,
  Param,
  Req,
  Get,
  Query,
} from '@nestjs/common';
import { UserService } from './user.service';
import {
  ChangeRoleDto,
  LoginUserDto,
  NodalOfficerDto,
  RegisterUserDto,
  UpdateUserDto,
  UpdateUserPasswordDto,
} from './dto/users.dto';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { UserResponseDto } from './dto/user-response.dto';
import { Public } from 'src/decorators/public.decorator';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
import { ParichayService } from './parichay.service';
import { Throttle } from '@nestjs/throttler';

@ApiTags('Users')
@Controller({
  path: 'users',
  version: '1',
})
export class UsersController {
  constructor(
    private readonly userService: UserService,
    private parichayService: ParichayService,
  ) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.CREATE_USER)
  @ApiBearerAuth()
  @Post('register')
  @ApiOperation({ summary: 'Register a new user' })
  async register(
    @Body() data: RegisterUserDto,
  ): Promise<UserResponseDto | any> {
    return this.userService.registerUser(data);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.USER_LIST)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get Users list' })
  @Get('list')
  async getUserList(): Promise<UserResponseDto | any> {
    return this.userService.getUserList();
  }

  @Public()
  @Post('login')
  @Throttle({ default: { limit: 6, ttl: 60000 } })
  @ApiOperation({ summary: 'Login user' })
  async login(@Body() data: LoginUserDto) {
    return this.userService.login(data);
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('change-password')
  @Throttle({ default: { limit: 6, ttl: 60000 } })
  @ApiOperation({ summary: 'Change user password' })
  async updateUserPassword(@Req() req, @Body() data: UpdateUserPasswordDto) {
    const userId = req?.user?.id;
    await this.userService.updateUserPassword(userId, data);
    return { message: 'User Password Updated Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('switch-role')
  @ApiOperation({ summary: 'Switch role' })
  async switchRole(@Req() req, @Body() data: ChangeRoleDto) {
    const userId = req?.user?.id;
    await this.userService.switchRole(userId, data);
    return { message: 'User Role Updated Successfully' };
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_USER)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Edit user details' })
  async updateUser(@Param('id') id: number, @Body() data: UpdateUserDto) {
    await this.userService.updateUser(id, data);
    return { message: 'User Details Updated Successfully' };
  }

  // @UseGuards(AuthGuard)
  @Post('logout')
  async logout(@Body('token') token: string) {
    await this.parichayService.logout(token);
  }

  @UseGuards(AuthGuard)
  @Get('my-profile')
  async fetchMyProfile(@Req() req) {
    return this.userService.fetchMyProfile(req.user.email);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.USER_LIST)
  @Get('nodal-officer')
  async fetchNodalOfficer(@Query() query: NodalOfficerDto) {
    return this.userService.fetchNodalOfficer(query);
  }

  @Get('assign-roles')
  @PermissionsDecorator(PermissionsEnum.ASSIGN_ROLE_PERMISSION)
  @UseGuards(AuthGuard)
  async assignrole() {
    return this.userService.assignRoles();
  }
}

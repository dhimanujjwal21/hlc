import { Module } from '@nestjs/common';
import { UsersController } from './user.controller';
import { UserService } from './user.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/entities/users.entity';
import { Role } from 'src/entities/roles.entity';
import { JwtModule, JwtModuleOptions, JwtService } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Hlc } from 'src/entities/hlc.entity';
import { UserHlc } from 'src/entities/user-hlc.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { ParichayController } from './parichay.controller';
import { ParichayService } from './parichay.service';
import { Departments } from 'src/entities/departments.entity';
import { UserRoles } from 'src/entities/user-roles.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Role, UserHlc, Hlc, Ministry, Departments, UserRoles]),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const secret = configService.getOrThrow<string>('JWT_SECRET');
        const expiresIn = configService.get<string>('JWT_EXPIRES_IN') ?? '1m';
        return {
          global: true,
          secret,
          signOptions: {
            expiresIn,
          },
        } as JwtModuleOptions;
      },
    }),
    // JwtModule.register({
    //       global: true,
    //       secret: process.env.JWT_SECRET,
    //       signOptions: {
    //         expiresIn: process.env.JWT_EXPIRES_IN as any
    //       }
    // })
  ],
  controllers: [UsersController, ParichayController],
  providers: [UserService, ParichayService, JwtService],
  exports: [UserService],
})
export class UsersModule {}

import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Put,
  Delete,
  ParseIntPipe,
  HttpCode,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { PermissionsService } from './permissions.service';
import {
  CreatePermissionDto,
  UpdatePermissionDto,
} from './dto/permissions.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
import { Public } from 'src/decorators/public.decorator';

@ApiTags('Permissions')
@Controller({
  path: 'permissions',
  version: '1',
})
export class PermissionsController {
  constructor(private readonly permissionsService: PermissionsService) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_PERMISSION)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Create a new permission' })
  async create(@Body() createPermissionDto: CreatePermissionDto) {
    return this.permissionsService.create(createPermissionDto);
  }

  @Public()
  @Get()
  @ApiOperation({ summary: 'List all permissions' })
  async findAll() {
    return this.permissionsService.findAll();
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_PERMISSION)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Update an existing permission' })
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updatePermissionDto: UpdatePermissionDto,
  ) {
    return this.permissionsService.update(id, updatePermissionDto);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DELETE_PERMISSION)
  @ApiBearerAuth()
  @Delete(':id')
  @HttpCode(204)
  @ApiOperation({ summary: 'Delete a permission' })
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.permissionsService.remove(id);
  }
}

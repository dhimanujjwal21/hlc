import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Permission } from 'src/entities/permissions.entity';
import {
  CreatePermissionDto,
  UpdatePermissionDto,
} from './dto/permissions.dto';

@Injectable()
export class PermissionsService {
  constructor(
    @InjectRepository(Permission)
    private readonly permissionRepository: Repository<Permission>,
  ) {}

  async create(createPermissionDto: CreatePermissionDto) {
    const { permissionName } = createPermissionDto;
    const exists = await this.permissionRepository.findOne({
      where: { permissionName },
    });
    if (exists) throw new ConflictException('Permission already exists');

    const permission = this.permissionRepository.create(createPermissionDto);
    return await this.permissionRepository.save(permission);
  }

  async findAll() {
    return await this.permissionRepository.find({
      order: { id: 'ASC' },
    });
  }

  async update(id: number, updatePermissionDto: UpdatePermissionDto) {
    const { permissionName } = updatePermissionDto;
    const permission = await this.permissionRepository.findOne({
      where: { id },
    });
    if (!permission) {
      throw new NotFoundException('Permission not found');
    }

    const exists = await this.permissionRepository.findOne({
      where: { permissionName },
    });
    if (exists && exists.id !== id)
      throw new ConflictException('Permission already exists');

    Object.assign(permission, updatePermissionDto);
    return await this.permissionRepository.save(permission);
  }

  async remove(id: number) {
    const permission = await this.permissionRepository.findOne({
      where: { id },
    });
    if (!permission) {
      throw new NotFoundException('Permission not found');
    }

    await this.permissionRepository.delete(id);
    return { message: 'Permission deleted successfully' };
  }
}

import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreatePermissionDto {
  @ApiProperty({ example: 'CREATE_USER' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(100)
  permissionName: string;

  @ApiProperty({ example: 'Allows user creation', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description?: string;
}

export class UpdatePermissionDto extends PartialType(CreatePermissionDto) {}
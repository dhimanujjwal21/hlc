import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import {
  AssignPermissionsDto,
  CreateRoleDto,
  UpdateRoleDto,
} from './dto/roles.dto';
import { Role } from 'src/entities/roles.entity';
import { Permission } from 'src/entities/permissions.entity';
import { RolePermission } from 'src/entities/role-permission.entity';

@Injectable()
export class RolesService {
  constructor(
    @InjectRepository(Role)
    private readonly roleRepository: Repository<Role>,

    @InjectRepository(Permission)
    private readonly permissionRepository: Repository<Permission>,

    @InjectRepository(RolePermission)
    private readonly rolePermissionRepository: Repository<RolePermission>,
  ) {}

  async createRole(data: CreateRoleDto) {
    const { roleName } = data;
    const exists = await this.roleRepository.findOne({
      where: { roleName },
    });
    if (exists) throw new ConflictException('Role already exists');
    const role = this.roleRepository.create(data);
    return await this.roleRepository.save(role);
  }

  async getAllRoles() {
    return await this.roleRepository.find();
  }

  async updateRole(id: number, dto: UpdateRoleDto) {
    const role = await this.roleRepository.findOne({ where: { id } });
    if (!role) throw new NotFoundException('Role not found');

    const exists = await this.roleRepository.findOne({
      where: { roleName: dto.roleName },
    });
    if (exists && exists.id !== id) throw new ConflictException('Role already exists');

    Object.assign(role, dto);
    return await this.roleRepository.save(role);
  }

  async deleteRole(id: number) {
    const role = await this.roleRepository.findOne({ where: { id } });
    if (!role) throw new NotFoundException('Role not found');

    await this.roleRepository.delete(id);
    return { message: 'Role deleted successfully' };
  }

  async assignPermissionsToRole(roleId: number, dto: AssignPermissionsDto) {
    const role = await this.roleRepository.findOne({
      where: { id: roleId },
      relations: ['rolePermissions', 'rolePermissions.permission'],
    });

    if (!role) {
      throw new NotFoundException(`Role with ID ${roleId} not found`);
    }

    // Get all permissions by IDs
    const permissions = await this.permissionRepository.find({
      where: { id: In(dto.permissionIds) },
    });

    if (permissions.length !== dto.permissionIds.length) {
      throw new BadRequestException('One or more permission IDs are invalid');
    }

    // Delete existing role-permission links (to avoid duplicates)
    await this.rolePermissionRepository.delete({ role: { id: roleId } });

    // Create new RolePermission entries
    const newRolePermissions = permissions.map((permission) =>
      this.rolePermissionRepository.create({
        role,
        permission,
      }),
    );

    await this.rolePermissionRepository.save(newRolePermissions);

    return {
      message: 'Permissions assigned successfully',
      role: {
        id: role.id,
        roleName: role.roleName,
        permissions: permissions.map((p) => ({
          id: p.id,
          name: p.permissionName,
        })),
      },
    };
  }

  async getPermissionsByRole(roleId: number) {
    const role = await this.roleRepository.findOne({
      where: { id: roleId },
      relations: ['rolePermissions', 'rolePermissions.permission'],
    });

    if (!role) {
      throw new NotFoundException(`Role with ID ${roleId} not found`);
    }

    const permissions = role.rolePermissions.map((rp) => ({
      id: rp.permission.id,
      name: rp.permission.permissionName,
      description: rp.permission.description,
    }));

    return {
      roleId: role.id,
      roleName: role.roleName,
      permissions,
    };
  }
}

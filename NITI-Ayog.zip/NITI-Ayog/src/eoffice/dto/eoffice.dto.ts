import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, MaxLength } from 'class-validator';

export enum EofficeStatus {
  SUCCESS = 'success',
  FAILURE = 'failure',
}

export class EofficeOverdueRequestDto {
  @ApiProperty({
    example: 'secretary-xyz@gov.in',
    description: 'Email of the Ministry Secretary logged in to e-Office',
  })
  @IsNotEmpty({ message: 'Email is required' })
  @IsEmail({}, { message: 'Email must be a valid email address' })
  @MaxLength(150)
  email!: string;
}

export interface EofficeOverdueRecommendation {
  id: number;
  recommendation_slug: string;
  name: string | null;
  description: string | null;
  hlc_name: string | null;
  report_number: string | null;
  ministry_name: string | null;
  department_name: string | null;
  timeline: string | null;
  due_date: string | null;
  days_overdue: number;
  current_status: string;
  current_stage: string | null;
  last_updated: string | null;
}

export interface EofficeOverdueResponse {
  status: EofficeStatus;
  message: string;
  user_email: string;
  last_updated: string | null;
  recommendations: EofficeOverdueRecommendation[];
}

import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { EofficeStatus } from './dto/eoffice.dto';

// Keeps error responses in the same shape e-Office expects for success responses
@Catch()
export class EofficeExceptionFilter implements ExceptionFilter {
  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    let message: string | string[] = 'Internal server error';
    if (exception instanceof HttpException) {
      const errorResponse = exception.getResponse();
      message =
        typeof errorResponse === 'string'
          ? errorResponse
          : (errorResponse as any)?.message || exception.message;
    } else {
      console.error('e-Office API error:', exception);
    }

    const email = request.body?.email;

    response.status(status).json({
      status: EofficeStatus.FAILURE,
      message: Array.isArray(message) ? message.join(', ') : message,
      user_email: typeof email === 'string' ? email : null,
      last_updated: null,
      recommendations: [],
    });
  }
}

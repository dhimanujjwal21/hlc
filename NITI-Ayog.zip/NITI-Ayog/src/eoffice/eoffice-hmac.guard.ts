import {
  CanActivate,
  ExecutionContext,
  Injectable,
  InternalServerErrorException,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { timingSafeEqual } from 'crypto';
import { Request } from 'express';
import {
  buildStringToSign,
  EOFFICE_HEADERS,
  getMaxSkewSeconds,
  isStrongSecret,
  signEofficeRequest,
} from './eoffice-signature.util';

@Injectable()
export class EofficeHmacGuard implements CanActivate {
  // nonce -> expiry (ms). Per-instance; see README note on multi-instance deployments.
  private readonly usedNonces = new Map<string, number>();

  constructor(private readonly configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context
      .switchToHttp()
      .getRequest<Request & { rawBody?: Buffer; eofficeClientId?: string }>();

    const expectedClientId = this.configService.get<string>('EOFFICE_CLIENT_ID');
    const secret = this.configService.get<string>('EOFFICE_CLIENT_SECRET');
    if (!expectedClientId || !isStrongSecret(secret)) {
      throw new InternalServerErrorException('e-Office integration is not configured');
    }

    const clientId = request.header(EOFFICE_HEADERS.CLIENT_ID);
    const timestamp = request.header(EOFFICE_HEADERS.TIMESTAMP);
    const nonce = request.header(EOFFICE_HEADERS.NONCE);
    const signature = request.header(EOFFICE_HEADERS.SIGNATURE);

    if (!clientId || !timestamp || !nonce || !signature) {
      throw new UnauthorizedException('Missing authentication headers');
    }

    if (clientId !== expectedClientId) {
      throw new UnauthorizedException('Unknown client');
    }

    // 1. Freshness: reject requests outside the allowed clock skew
    const maxSkew = getMaxSkewSeconds(
      this.configService.get('EOFFICE_MAX_SKEW_SECONDS'),
    );
    const ts = Number(timestamp);
    if (!/^\d{10}$/.test(timestamp) || Math.abs(Date.now() / 1000 - ts) > maxSkew) {
      throw new UnauthorizedException('Request timestamp is invalid or expired');
    }

    if (!/^[A-Za-z0-9-]{16,64}$/.test(nonce)) {
      throw new UnauthorizedException('Invalid nonce');
    }

    // 2. Integrity + authenticity: recompute HMAC over method, path, timestamp, nonce and body
    if (!/^[0-9a-fA-F]{64}$/.test(signature)) {
      throw new UnauthorizedException('Invalid signature');
    }
    const expected = Buffer.from(
      signEofficeRequest(
        secret,
        buildStringToSign(
          request.method,
          request.originalUrl,
          timestamp,
          nonce,
          request.rawBody ?? '',
        ),
      ),
      'hex',
    );
    const given = Buffer.from(signature, 'hex');
    if (!timingSafeEqual(given, expected)) {
      throw new UnauthorizedException('Invalid signature');
    }

    // 3. Replay protection: only checked after the signature, so unsigned traffic can't fill the store
    this.pruneNonces();
    if (this.usedNonces.has(nonce)) {
      throw new UnauthorizedException('Duplicate request');
    }
    this.usedNonces.set(nonce, Date.now() + maxSkew * 2 * 1000);

    request.eofficeClientId = clientId;
    return true;
  }

  private pruneNonces() {
    const now = Date.now();
    for (const [nonce, expiry] of this.usedNonces) {
      if (expiry <= now) this.usedNonces.delete(nonce);
    }
  }
}

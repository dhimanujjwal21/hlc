import { createHash, createHmac, randomUUID } from 'crypto';

export const EOFFICE_HEADERS = {
  CLIENT_ID: 'x-client-id',
  TIMESTAMP: 'x-timestamp',
  NONCE: 'x-nonce',
  SIGNATURE: 'x-signature',
} as const;

export const MAX_SKEW_SECONDS = 300;

export const getMaxSkewSeconds = (configured: unknown) => {
  const value = Number(configured);
  return value > 0 ? Math.min(value, MAX_SKEW_SECONDS) : MAX_SKEW_SECONDS;
};

// 256-bit key, hex encoded
export const isStrongSecret = (secret?: string): secret is string =>
  !!secret && /^[0-9a-fA-F]{64,}$/.test(secret);

export const sha256Hex =(data: Buffer | string) =>
  createHash('sha256').update(data).digest('hex');

/**
 * String to sign:
 *   METHOD \n PATH \n TIMESTAMP \n NONCE \n SHA256_HEX(raw body)
 * PATH is the request path including query string, e.g. /api/v1/eoffice/overdue-recommendations
 */
export const buildStringToSign = (
  method: string,
  path: string,
  timestamp: string,
  nonce: string,
  body: Buffer | string,
) =>
  [method.toUpperCase(), path, timestamp, nonce, sha256Hex(body)].join('\n');

export const signEofficeRequest = (secret: string, stringToSign: string) =>
  createHmac('sha256', secret).update(stringToSign).digest('hex');

export const generateSignedHeaders = (
  clientId: string,
  secret: string,
  method: string,
  path: string,
  body: string,
) => {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = randomUUID();
  const signature = signEofficeRequest(
    secret,
    buildStringToSign(method, path, timestamp, nonce, body),
  );

  return {
    'Content-Type': 'application/json',
    [EOFFICE_HEADERS.CLIENT_ID]: clientId,
    [EOFFICE_HEADERS.TIMESTAMP]: timestamp,
    [EOFFICE_HEADERS.NONCE]: nonce,
    [EOFFICE_HEADERS.SIGNATURE]: signature,
  };
};

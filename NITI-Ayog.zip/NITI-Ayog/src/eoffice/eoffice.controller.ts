import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Post,
  Req,
  UseFilters,
  UseGuards,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiHeader, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { Request } from 'express';
import { RawResponse } from 'src/decorators/raw-response.decorator';
import { EofficeOverdueRequestDto } from './dto/eoffice.dto';
import { EofficeExceptionFilter } from './eoffice-exception.filter';
import { EofficeHmacGuard } from './eoffice-hmac.guard';
import { EOFFICE_HEADERS } from './eoffice-signature.util';
import { EofficeService } from './eoffice.service';

@ApiTags('e-Office')
@Controller({
  path: 'eoffice',
  version: '1',
})
export class EofficeController {
  constructor(
    private readonly eofficeService: EofficeService,
    private readonly configService: ConfigService,
  ) {}

  @Post('overdue-recommendations')
  @HttpCode(HttpStatus.OK)
  @UseGuards(EofficeHmacGuard)
  @UseFilters(EofficeExceptionFilter)
  @RawResponse()
  // All e-Office users arrive from the same server IP, so the global per-IP limit is too low
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @ApiOperation({
    summary: 'Overdue recommendations for a Ministry Secretary (HMAC signed, server-to-server)',
  })
  @ApiHeader({ name: EOFFICE_HEADERS.CLIENT_ID, required: true })
  @ApiHeader({ name: EOFFICE_HEADERS.TIMESTAMP, required: true, description: 'Unix time in seconds' })
  @ApiHeader({ name: EOFFICE_HEADERS.NONCE, required: true, description: 'Unique UUID per request' })
  @ApiHeader({
    name: EOFFICE_HEADERS.SIGNATURE,
    required: true,
    description:
      'hex(HMAC_SHA256(secret, METHOD\\nPATH\\nTIMESTAMP\\nNONCE\\nSHA256_HEX(body)))',
  })
  getOverdueRecommendations(@Body() body: EofficeOverdueRequestDto) {
    return this.eofficeService.getOverdueRecommendations(body.email);
  }

  @Post('generate-request')
  @HttpCode(HttpStatus.OK)
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  @ApiOperation({
    summary:
      'Generate a signed sample request for the overdue API (enabled only when EOFFICE_SIGNER_ENABLED=true)',
  })
  generateRequest(@Body() body: EofficeOverdueRequestDto, @Req() req: Request) {
    // Anyone who can call this can mint valid requests, so keep it off outside testing
    if (
      this.configService.get<string>('APP_ENV')?.toLowerCase() === 'production' ||
      this.configService.get<string>('EOFFICE_SIGNER_ENABLED') !== 'true'
    ) {
      throw new NotFoundException();
    }
    const baseUrl =
      this.configService.get<string>('EOFFICE_API_BASE_URL') ||
      `${req.protocol}://${req.get('host')}`;
    return this.eofficeService.generateOverdueRequest(body.email, baseUrl);
  }
}

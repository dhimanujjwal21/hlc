import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'src/entities/users.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import {
  ClosureStatusEnum,
  RoleEnum,
  StageEnum,
  StatusEnum,
} from 'src/constants/enums';
import {
  EofficeOverdueRecommendation,
  EofficeOverdueResponse,
  EofficeStatus,
} from './dto/eoffice.dto';
import {
  generateSignedHeaders,
  getMaxSkewSeconds,
  isStrongSecret,
} from './eoffice-signature.util';

export const EOFFICE_OVERDUE_PATH = '/api/v1/eoffice/overdue-recommendations';

// Same due-date logic as the dashboard overdue buckets
const DUE_DATE_SQL = `DATE(COALESCE(r.updated_timeline, r.timeline) AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata')`;

@Injectable()
export class EofficeService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,
    private readonly configService: ConfigService,
  ) {}

  async getOverdueRecommendations(email: string): Promise<EofficeOverdueResponse> {
    const secretary = await this.findMinistrySecretary(email);

    const qb = this.recommendationRepository
      .createQueryBuilder('r')
      .leftJoin('r.hlc', 'hlc')
      .leftJoin('r.ministry', 'm')
      .leftJoin('r.department', 'd')
      .select([
        'r.id AS id',
        'r.recommendationSlug AS recommendation_slug',
        'r.name AS name',
        'r.description AS description',
        'hlc.name AS hlc_name',
        'r.reportNumber AS report_number',
        'm.name AS ministry_name',
        'd.name AS department_name',
        `TO_CHAR(DATE(r.timeline AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata'), 'YYYY-MM-DD') AS timeline`,
        `TO_CHAR(${DUE_DATE_SQL}, 'YYYY-MM-DD') AS due_date`,
        `(CURRENT_DATE - ${DUE_DATE_SQL}) AS days_overdue`,
        'r.currentStatus AS current_status',
        'r.currentStage AS current_stage',
        'r.updatedAt AS updated_at',
      ])
      .where('r.ministry_id = :ministryId', {
        ministryId: secretary.ministry!.id,
      })
      .andWhere('r.niti_approved = true')
      .andWhere('r.closure_status = :open', { open: ClosureStatusEnum.OPEN })
      .andWhere(
        '(r.current_stage IS NULL OR r.current_stage NOT IN (:...closedStages))',
        { closedStages: [StageEnum.CLOSED_BY_HLC, StageEnum.CLOSED_BY_IGOM] },
      )
      .andWhere(
        `(r.current_status IN (:...statuses) OR r.current_status IS NULL OR r.current_status = '')`,
        {
          statuses: [
            StatusEnum.PARTIALLY_IMPLEMENTED,
            StatusEnum.UNDER_IMPLEMENTATION,
            StatusEnum.YET_TO_INITIATE,
          ],
        },
      )
      .andWhere(`${DUE_DATE_SQL} < CURRENT_DATE`)
      .orderBy('due_date', 'ASC')
      .addOrderBy('r.recommendationSlug', 'ASC');

    // A department-level secretary sees their department's items plus ministry-level ones
    if (secretary.department?.id) {
      qb.andWhere('(r.department_id IS NULL OR r.department_id = :departmentId)', {
        departmentId: secretary.department.id,
      });
    }

    const rows = await qb.getRawMany();

    let lastUpdated: Date | null = null;
    const recommendations: EofficeOverdueRecommendation[] = rows.map((row) => {
      const updatedAt = row.updated_at ? new Date(row.updated_at) : null;
      if (updatedAt && (!lastUpdated || updatedAt > lastUpdated)) {
        lastUpdated = updatedAt;
      }
      return {
        id: row.id,
        recommendation_slug: row.recommendation_slug,
        name: row.name,
        description: row.description,
        hlc_name: row.hlc_name,
        report_number: row.report_number,
        ministry_name: row.ministry_name,
        department_name: row.department_name,
        timeline: row.timeline,
        due_date: row.due_date,
        days_overdue: Number(row.days_overdue) || 0,
        current_status: row.current_status || StatusEnum.YET_TO_INITIATE,
        current_stage: row.current_stage,
        last_updated: updatedAt?.toISOString() ?? null,
      };
    });

    return {
      status: EofficeStatus.SUCCESS,
      message: recommendations.length
        ? `${recommendations.length} overdue recommendation(s) found`
        : 'No overdue recommendations found',
      user_email: secretary.email,
      last_updated: (lastUpdated as Date | null)?.toISOString() ?? null,
      recommendations,
    };
  }

  /**
   * Builds a ready-to-send signed request for the overdue API.
   * For integration testing / sharing a reference request with the e-Office team.
   */
  generateOverdueRequest(email: string, baseUrl: string) {
    const clientId = this.configService.get<string>('EOFFICE_CLIENT_ID');
    const secret = this.configService.get<string>('EOFFICE_CLIENT_SECRET');
    if (!clientId || !isStrongSecret(secret)) {
      throw new NotFoundException('e-Office integration is not configured');
    }

    const method = 'POST';
    // Must be sent byte-for-byte as-is: the signature covers the exact body string
    const body = JSON.stringify({ email });
    const headers = generateSignedHeaders(
      clientId,
      secret,
      method,
      EOFFICE_OVERDUE_PATH,
      body,
    );

    return {
      method,
      url: `${baseUrl}${EOFFICE_OVERDUE_PATH}`,
      headers,
      body,
      expires_in_seconds: getMaxSkewSeconds(
        this.configService.get('EOFFICE_MAX_SKEW_SECONDS'),
      ),
    };
  }

  private async findMinistrySecretary(email: string) {
    const user = await this.userRepository
      .createQueryBuilder('u')
      .leftJoinAndSelect('u.role', 'role')
      .leftJoinAndSelect('u.userRoles', 'ur', 'ur.isActive = true')
      .leftJoinAndSelect('ur.role', 'urRole')
      .leftJoinAndSelect('u.ministry', 'ministry')
      .leftJoinAndSelect('u.department', 'department')
      .where('LOWER(u.email) = LOWER(:email)', { email: email.trim() })
      .getOne();

    if (!user) {
      throw new NotFoundException('No user found with the given email');
    }
    if (user.isDisabled) {
      throw new ForbiddenException('User account is disabled');
    }

    const isSecretary =
      user.role?.roleName === RoleEnum.MINISTRY_SECRETARY ||
      user.userRoles?.some(
        (ur) => ur.role?.roleName === RoleEnum.MINISTRY_SECRETARY,
      );
    if (!isSecretary) {
      throw new ForbiddenException('User is not a Ministry Secretary');
    }
    if (!user.ministry?.id) {
      throw new NotFoundException('No ministry is mapped to this user');
    }

    return user;
  }
}

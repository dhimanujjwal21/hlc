import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/entities/users.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { EofficeController } from './eoffice.controller';
import { EofficeService } from './eoffice.service';
import { EofficeHmacGuard } from './eoffice-hmac.guard';

@Module({
  imports: [TypeOrmModule.forFeature([User, Recommendation])],
  controllers: [EofficeController],
  providers: [EofficeService, EofficeHmacGuard],
})
export class EofficeModule {}

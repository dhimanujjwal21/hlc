import { Module } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecommendationDraft } from 'src/entities/recommendation-draft.entity';
import { RecommendationDraftService } from './recommendation-draft.service';
import { RecommendationDraftController } from './recommendation-draft.controller';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { RecommendationService } from 'src/recommendation/recommendation.service';
import { RecommendationTrail } from 'src/entities/recommendation-trail.entity';
import { RecommendationUpdates } from 'src/entities/recommendation-updates.entity';
import { RecommendationFile } from 'src/entities/recommendation-file.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      RecommendationDraft,
      Hlc,
      User,
      Departments,
      Ministry,
      Recommendation,
      RecommendationTrail,
      RecommendationUpdates,
      RecommendationFile
    ]),
  ],
  controllers: [RecommendationDraftController],
  providers: [RecommendationDraftService, JwtService, RecommendationService],
  exports: [],
})
export class RecommendationDraftModule {}

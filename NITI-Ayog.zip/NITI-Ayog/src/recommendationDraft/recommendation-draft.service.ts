import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { RecommendationDraft } from 'src/entities/recommendation-draft.entity';
import { Recommendation } from 'src/entities/recommendation.entity';
import { Not, Repository } from 'typeorm';
import {
  ApproveRejectDraftDto,
  GetRecommendationDraftQueryDto,
  RecommendationDraftDto,
} from './dto/recommendation-draft.dto';
import {
  DraftRoleEnum,
  DraftStatusEnum,
  RoleEnum,
  StatusEnum,
} from 'src/constants/enums';
import { Departments } from 'src/entities/departments.entity';
import { Ministry } from 'src/entities/ministry.entity';
import { Hlc } from 'src/entities/hlc.entity';
import { User } from 'src/entities/users.entity';
import { RecommendationService } from 'src/recommendation/recommendation.service';
import { Role } from 'src/entities/roles.entity';

@Injectable()
export class RecommendationDraftService {
  constructor(
    @InjectRepository(Recommendation)
    private readonly recommendationRepository: Repository<Recommendation>,
    @InjectRepository(RecommendationDraft)
    private readonly recommendationDraftRepository: Repository<RecommendationDraft>,
    @InjectRepository(Departments)
    private readonly departmentRepository: Repository<Departments>,
    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,
    @InjectRepository(Hlc)
    private readonly hlcRepository: Repository<Hlc>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    private recommendationService: RecommendationService,
  ) {}

  async draftRecommendation(body: RecommendationDraftDto, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role', 'userHlcs', 'userHlcs.hlc'],
    });

    if (!user) {
      throw new BadRequestException('Invalid user');
    }

    const hlcIds: any = user?.userHlcs?.map((h) => h.hlc.id) || [];
    if (
      user.role?.roleName == RoleEnum.NITI_DIRECTOR &&
      !hlcIds.includes(body.hlcId)
    ) {
      throw new BadRequestException(
        `You cannot add recommendation for this HLC.`,
      );
    }

    const role = user.role?.roleName as RoleEnum | undefined;

    if (
      !role ||
      (role !== RoleEnum.NITI_DIRECTOR && role !== RoleEnum.MINISTRY_DIRECTOR)
    ) {
      throw new ForbiddenException(
        'You are not allowed to create or update drafts',
      );
    }

    // ❗ Ministry Director cannot create new recommendations
    if (role === RoleEnum.MINISTRY_DIRECTOR && !body.recommendationId) {
      throw new BadRequestException(
        'Ministry Director must draft against an existing recommendation',
      );
    }

    /* -----------------------------
     ✅ Fetch Recommendation (if any)
  ----------------------------- */
    let recommendation: Recommendation | null = null;
    if (body.recommendationId) {
      recommendation = await this.recommendationRepository.findOne({
        where: { id: body.recommendationId },
        relations: ['department', 'ministry', 'hlc'],
      });

      if (!recommendation) {
        throw new BadRequestException('Recommendation not found');
      }
    }

    /* -----------------------------
     ✅ Validate masters (override capable)
  ----------------------------- */
    const [department, ministry, hlc, primaryDepartment, primaryMinistry] = await Promise.all([
      body.departmentId
        ? this.departmentRepository.findOne({
            where: {
              id: body.departmentId,
              ministry: { id: body.ministryId },
            },
          })
        : (recommendation?.department ?? null),

      body.ministryId
        ? this.ministryRepository.findOne({ where: { id: body.ministryId } })
        : (recommendation?.ministry ?? null),

      body.hlcId
        ? this.hlcRepository.findOne({ where: { id: body.hlcId } })
        : (recommendation?.hlc ?? null),

      body.primaryDepartmentId
        ? this.departmentRepository.findOne({ where: { id: body.primaryDepartmentId, ministry: { id: body.primaryMinistryId }, } })
        : (recommendation?.primaryDepartment ?? null),

      body.primaryMinistryId
        ? this.ministryRepository.findOne({ where: { id: body.primaryMinistryId } })
        : (recommendation?.primaryMinistry ?? null),
    ]);

    /* -----------------------------
     ✅ NITI DIRECTOR VALIDATIONS
  ----------------------------- */
    if (role === RoleEnum.NITI_DIRECTOR) {
      if (!body.recommendationSlug && !recommendation) {
        throw new BadRequestException(
          'Recommendation slug is required for NITI Director',
        );
      }

      // Slug collision check (only when slug is changed / new)
      if (body.recommendationSlug) {
        const query: any = { recommendationSlug: body.recommendationSlug };
        if (ministry) query.ministry = ministry;
        if (department) query.department = department;
        const existingCombination = await this.recommendationRepository.findOne(
          {
            where: query,
          },
        );

        if (existingCombination) {
          throw new ConflictException(
            'The recommendation number for this ministry/department already exists',
          );
        }

        const draftSlugExists =
          await this.recommendationDraftRepository.findOne({
            where: {
              ...query,
              draftStatus: Not(DraftStatusEnum.APPROVED),
            },
          });

        if (draftSlugExists) {
          throw new ConflictException(
            'Draft for this recommendation number for this ministry/department already exists',
          );
        }
      }
    }

    /* -----------------------------
     ✅ Prevent duplicate pending drafts
  ----------------------------- */

    const whereClause: any = {
      role,
      draftStatus: DraftStatusEnum.PENDING,
      user: { id: userId },
    };
    if (recommendation) whereClause.recommendation = recommendation;
    const existingDraft = await this.recommendationDraftRepository.findOne({
      where: whereClause,
    });

    if (existingDraft && recommendation) {
      throw new BadRequestException(
        'Draft for this recommendation number already exists',
      );
    }

    /* -----------------------------
     ✅ CREATE DRAFT
  ----------------------------- */
    const draft = this.recommendationDraftRepository.create({
      user,
      role,
      recommendation,
      draftStatus: DraftStatusEnum.PENDING,
    });

    /* -----------------------------
     ✅ Assign fields (NITI)
  ----------------------------- */
    if (role === RoleEnum.NITI_DIRECTOR) {
      Object.assign(draft, {
        recommendationSlug:
          body.recommendationSlug ?? recommendation?.recommendationSlug,
        name: body.name ?? recommendation?.name,
        description: body.description ?? recommendation?.description,
        department,
        ministry,
        hlc,
        primaryDepartment,
        primaryMinistry,
        timeline: body.timeline ?? recommendation?.timeline,
        reportNumber: body.reportNumber ?? recommendation?.reportNumber,
      });
    }

    /* -----------------------------
     ✅ Assign fields (Ministry)
  ----------------------------- */
    if (role === RoleEnum.MINISTRY_DIRECTOR) {
      Object.assign(draft, {
        currentStatus: body.status,
        actionTakenByMinistry: body.actionTakenByMinistry,
        reasonNotImplemented: body.reasonIfNotImplemented,
      });
    }

    await this.recommendationDraftRepository.save(draft);

    return {
      message: 'Draft saved successfully',
      data: draft,
    };
  }

  async getDraftRecommendation(
    data: GetRecommendationDraftQueryDto,
    userId: number,
  ) {
    const {
      departmentId,
      ministryId,
      hlcId,
      status,
      search,
      reportNumber,
      page = 1,
      limit = 10,
    } = data;

    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['ministry', 'role'],
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const qb = this.recommendationDraftRepository
      .createQueryBuilder('draft')
      .leftJoin('draft.recommendation', 'recommendation')

      // Recommendation relations
      .leftJoin('recommendation.department', 'recDept')
      .leftJoin('recommendation.ministry', 'recMin')
      .leftJoin('recommendation.primaryDepartment', 'recPrimaryDept')
      .leftJoin('recommendation.primaryMinistry', 'recPrimaryMin')
      .leftJoin('recommendation.hlc', 'recHlc')

      // Draft relations
      .leftJoin('draft.department', 'draftDept')
      .leftJoin('draft.ministry', 'draftMin')
      .leftJoin('draft.primaryDepartment', 'draftPrimaryDept')
      .leftJoin('draft.primaryMinistry', 'draftPrimaryMin')
      .leftJoin('draft.hlc', 'draftHlc');

    // ---- SELECT MERGED FIELDS ----
    qb.select([
      'draft.id AS id',
      'draft.role AS role',
      'draft.draft_status AS draftStatus',

      // merged recommendation details
      'COALESCE(draft.recommendation_slug, recommendation.recommendation_slug) AS recommendationSlug',
      'COALESCE(draft.name, recommendation.name) AS name',
      'COALESCE(draft.description, recommendation.description) AS description',
      'COALESCE(draft.timeline, recommendation.timeline) AS timeline',
      'COALESCE(draft.report_number, recommendation.report_number) AS reportNumber',

      // ministry director fields
      'draft.current_status AS currentStatus',
      'draft.action_taken_by_ministry AS actionTakenByMinistry',
      'draft.reason_not_implemented AS reasonNotImplemented',

      // department
      'draftDept.id AS draftdeptid',
      'draftDept.name AS draftdeptname',

      'draftPrimaryDept.id AS draftprimarydeptid',
      'draftPrimaryDept.name AS draftprimarydeptname',

      'recDept.id AS recdeptid',
      'recDept.name AS recdeptname',

      'recPrimaryDept.id AS recprimarydeptid',
      'recPrimaryDept.name AS recprimarydeptname',

      // ministry
      'draftMin.id AS draftminid',
      'draftMin.name AS draftminname',

      'draftPrimaryMin.id AS draftprimaryminid',
      'draftPrimaryMin.name AS draftprimaryminname',

      'recMin.id AS recminid',
      'recMin.name AS recminname',

      'recPrimaryMin.id AS recprimaryminid',
      'recPrimaryMin.name AS recprimaryminname',

      // hlc
      'draftHlc.id AS drafthlcid',
      'draftHlc.name AS drafthlcname',
      'draftHlc.slug AS drafthlcslug',

      'recHlc.id AS rechlcid',
      'recHlc.name AS rechlcname',
      'recHlc.slug AS rechlcslug',
    ]);

    // ---- ONLY USER DRAFTS ----
    qb.where('draft.user_id = :userId', { userId }).andWhere(
      'draft.draft_status = :draftStatus',
      { draftStatus: 'pending' },
    );

    // ---- FILTERS ----
    if (departmentId)
      qb.andWhere('draft.department_id = :departmentId', { departmentId });
    if (ministryId && user.role?.roleName !== 'MINISTRY_DIRECTOR')
      qb.andWhere('draft.ministry_id = :ministryId', { ministryId });
    if (hlcId) qb.andWhere('draft.hlc_id = :hlcId', { hlcId });
    if (status) qb.andWhere('draft.draft_status = :status', { status });

    if (reportNumber) {
      qb.andWhere(
        `COALESCE(draft.report_number, recommendation.report_number) ILIKE :reportNumber`,
        { reportNumber: `%${reportNumber}%` },
      );
    }

    if (search) {
      qb.andWhere(
        `(COALESCE(draft.name, recommendation.name) ILIKE :search 
        OR COALESCE(draft.description, recommendation.description) ILIKE :search 
        OR COALESCE(draft.recommendation_slug, recommendation.recommendation_slug) ILIKE :search)`,
        { search: `%${search}%` },
      );
    }

    // ---- PAGINATION ----
    qb.orderBy('draft.updated_at', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    const [rawRows, total] = await Promise.all([
      qb.getRawMany(),
      qb.getCount(),
    ]);

    // ---- FORMAT THE RESULT ----
    const results = rawRows.map((row) => {
      // determine final dept/ministry/hlc by fallback
      const department = row.draftdeptid
        ? { id: row.draftdeptid, name: row.draftdeptname }
        : row.recdeptid
          ? { id: row.recdeptid, name: row.recdeptname }
          : null;

      const ministry = row.draftminid
        ? { id: row.draftminid, name: row.draftminname }
        : row.recminid
          ? { id: row.recminid, name: row.recminname }
          : null;

      const primaryDepartment = row.draftprimarydeptid
        ? { id: row.draftprimarydeptid, name: row.draftprimarydeptname }
        : row.recprimarydeptid
          ? { id: row.recprimarydeptid, name: row.recprimarydeptname }
          : null;

      const primaryMinistry = row.draftprimaryminid
        ? { id: row.draftprimaryminid, name: row.draftprimaryminname }
        : row.recprimaryminid
          ? { id: row.recprimaryminid, name: row.recprimaryminname }
          : null;

      const hlc = row.drafthlcid
        ? {
            id: row.drafthlcid,
            name: row.drafthlcname,
            slug: row.drafthlcslug,
          }
        : row.rechlcid
          ? { id: row.rechlcid, name: row.rechlcname, slug: row.rechlcslug }
          : null;

      return {
        id: row.id,
        recommendationSlug: row.recommendationslug,
        name: row.name,
        description: row.description,
        department,
        ministry,
        primaryDepartment,
        primaryMinistry,
        hlc,
        timeline: row.timeline,
        reportNumber: row.reportnumber,

        currentStatus: row.currentstatus,
        actionTakenByMinistry: row.actiontakenbyministry,
        reasonNotImplemented: row.reasonnotimplemented,

        draftStatus: row.draftstatus,
        role: row.role,
      };
    });

    return { total, page, limit, results };
  }

  async approveRejectDraft(
    draftId: number,
    body: ApproveRejectDraftDto,
    userId: number,
  ) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role'],
    });

    if (!user) {
      throw new BadRequestException('Invalid user');
    }

    const draft = await this.recommendationDraftRepository.findOne({
      where: { id: draftId, draftStatus: DraftStatusEnum.PENDING },
      relations: [
        'recommendation',
        'department',
        'ministry',
        'hlc',
        'user',
        'primaryDepartment',
        'primaryMinistry',
      ],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found or already processed');
    }

    if (user.id !== draft.user?.id) {
      throw new BadRequestException('You cannot approve / reject this draft');
    }

    // ❌ Reject case
    if (body.status === DraftStatusEnum.REJECTED) {
      draft.draftStatus = DraftStatusEnum.REJECTED;
      await this.recommendationDraftRepository.save(draft);
      return { message: 'Draft rejected successfully' };
    }

    // ✅ APPROVE CASE
    if (draft.role === RoleEnum.NITI_DIRECTOR && !draft.recommendation) {
      await this.recommendationService.createRecommendation(
        {
          recommendationSlug: draft?.recommendationSlug || '',
          name: draft?.name || '',
          description: draft?.description || '',
          departmentId: draft.department?.id || 0,
          ministryId: draft.ministry?.id || 0,
          primaryDepartmentId: draft.primaryDepartment?.id || 0,
          primaryMinistryId: draft.primaryMinistry?.id || 0,
          hlcId: draft.hlc?.id || 0,
          timeline: draft.timeline || new Date(),
          reportNumber: draft?.reportNumber || '',
        },
        userId,
      );
    } else if (draft.role === RoleEnum.NITI_DIRECTOR && draft.recommendation) {
      await this.recommendationService.updateRecommendation(
        draft.recommendation.id,
        {
          recommendationSlug: draft?.recommendationSlug || '',
          name: draft?.name || '',
          description: draft?.description || '',
          departmentId: draft.department?.id || 0,
          ministryId: draft.ministry?.id || 0,
          primaryDepartmentId: draft.primaryDepartment?.id || 0,
          primaryMinistryId: draft.primaryMinistry?.id || 0,
          hlcId: draft.hlc?.id || 0,
          timeline: draft.timeline || new Date(),
          reportNumber: draft?.reportNumber || '',
        },
        userId,
      );
    } else if (draft.role === RoleEnum.MINISTRY_DIRECTOR) {
      if (!draft.recommendation) {
        throw new BadRequestException('Recommendation not linked');
      }
      await this.recommendationService.ministryDirectorRequest(
        {
          status: draft?.currentStatus as StatusEnum,
          actionTakenByMinistry: draft?.actionTakenByMinistry || '',
          reasonIfNotImplemented: draft?.reasonNotImplemented || '',
        },
        draft.recommendation?.id,
        userId,
      );
    }

    draft.draftStatus = DraftStatusEnum.APPROVED;
    await this.recommendationDraftRepository.save(draft);

    return { message: 'Draft approved successfully' };
  }

  async editDraft(
    draftId: number,
    body: RecommendationDraftDto,
    userId: number,
  ) {
    const draft = await this.recommendationDraftRepository.findOne({
      where: { id: draftId },
      relations: ['user', 'recommendation', 'department', 'ministry', 'hlc'],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found');
    }

    if (draft.draftStatus !== DraftStatusEnum.PENDING) {
      throw new ForbiddenException('Only pending drafts can be edited');
    }

    if (draft.user?.id !== userId) {
      throw new ForbiddenException('You are not allowed to edit this draft');
    }

    const [department, ministry, hlc, primaryDepartment, primaryMinistry] = await Promise.all([
      body.departmentId
        ? this.departmentRepository.findOne({
            where: {
              id: body.departmentId,
              ministry: { id: body.ministryId },
            },
          })
        : (draft?.department ?? null),

      body.ministryId
        ? this.ministryRepository.findOne({ where: { id: body.ministryId } })
        : (draft?.ministry ?? null),

      body.hlcId
        ? this.hlcRepository.findOne({ where: { id: body.hlcId } })
        : (draft?.hlc ?? null),

      body.primaryDepartmentId
        ? this.departmentRepository.findOne({ where: { id: body.primaryDepartmentId, ministry: { id: body.primaryMinistryId }, } })
        : (draft?.primaryDepartment ?? null),

      body.primaryMinistryId
        ? this.ministryRepository.findOne({ where: { id: body.primaryMinistryId } })
        : (draft?.primaryMinistry ?? null),
    ]);

    if (body.departmentId && !department) {
      throw new BadRequestException('Invalid department');
    }
    if (body.ministryId && !ministry) {
      throw new BadRequestException('Invalid ministry');
    }
    if (body.primaryDepartmentId && !primaryDepartment) {
      throw new BadRequestException('Invalid primary department');
    }
    if (body.primaryMinistryId && !primaryMinistry) {
      throw new BadRequestException('Invalid primary ministry');
    }
    if (body.hlcId && !hlc) {
      throw new BadRequestException('Invalid HLC');
    }

    // ✅ ROLE-BASED FIELD UPDATE
    if (draft.role === RoleEnum.NITI_DIRECTOR) {
      Object.assign(draft, {
        recommendationSlug: body.recommendationSlug ?? draft.recommendationSlug,
        name: body.name ?? draft.name,
        description: body.description ?? draft.description,
        department,
        ministry,
        hlc,
        primaryDepartment,
        primaryMinistry,
        timeline: body.timeline ?? draft.timeline,
        reportNumber: body.reportNumber ?? draft.reportNumber,
      });
    } else if (draft.role === RoleEnum.MINISTRY_DIRECTOR) {
      Object.assign(draft, {
        currentStatus: body.status ?? draft.currentStatus,
        actionTakenByMinistry:
          body.actionTakenByMinistry ?? draft.actionTakenByMinistry,
        reasonNotImplemented:
          body.reasonIfNotImplemented ?? draft.reasonNotImplemented,
      });
    }

    await this.recommendationDraftRepository.save(draft);

    return {
      message: 'Draft updated successfully',
      data: draft,
    };
  }

  async deleteDraft(draftId: number, userId: number) {
    const user = await this.userRepository.findOne({
      where: { id: userId },
      relations: ['role', 'ministry'],
    });

    if (!user) {
      throw new BadRequestException('Invalid user');
    }

    const draft = await this.recommendationDraftRepository.findOne({
      where: { id: draftId },
      relations: ['recommendation', 'recommendation.ministry', 'user'],
    });

    if (!draft) {
      throw new NotFoundException('Draft not found');
    }

    if (draft.draftStatus !== DraftStatusEnum.PENDING) {
      throw new BadRequestException('Only pending drafts can be deleted');
    }

    if (user.id !== draft.user?.id) {
      throw new ForbiddenException(
        'You do not have permission to delete this draft',
      );
    }

    await this.recommendationDraftRepository.remove(draft);

    return {
      message: 'Draft deleted successfully',
    };
  }
}

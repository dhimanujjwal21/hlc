import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  IsNumber,
  IsEnum,
  IsDateString,
  IsInt,
} from 'class-validator';
import { DraftRoleEnum, DraftStatusEnum } from '../../constants/enums';
import { Type } from 'class-transformer';

export class RecommendationDraftDto {
  // ---- NITI Director Fields ----

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  recommendationSlug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ description: 'Department ID' })
  @IsOptional()
  @IsNumber()
  departmentId?: number;

  @ApiPropertyOptional({ description: 'Ministry ID' })
  @IsOptional()
  @IsNumber()
  ministryId?: number;

  
  @ApiPropertyOptional({ description: 'Primary Department ID' })
  @IsOptional()
  @IsNumber()
  primaryDepartmentId?: number;

  @ApiPropertyOptional({ description: 'Primary Ministry ID' })
  @IsOptional()
  @IsNumber()
  primaryMinistryId?: number;

  @ApiPropertyOptional({ description: 'HLC ID' })
  @IsOptional()
  @IsNumber()
  hlcId?: number;

  @ApiPropertyOptional({ description: 'Timeline (YYYY-MM-DD)' })
  @IsOptional()
  @IsDateString()
  timeline?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reportNumber?: string;

  // ---- Ministry Director Fields ----

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reasonIfNotImplemented?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  actionTakenByMinistry?: string;

  // ---- Linking to Recommendation ----

  @ApiPropertyOptional({
    description: 'Existing Recommendation ID (for editing)',
  })
  @IsOptional()
  @IsNumber()
  recommendationId?: number;

  // ---- Role ----

  // @ApiPropertyOptional({ enum: DraftRoleEnum })
  // @IsOptional()
  // @IsEnum(DraftRoleEnum)
  // role?: DraftRoleEnum;

  // ---- Draft Status ----

  @ApiPropertyOptional({ enum: DraftStatusEnum })
  @IsOptional()
  @IsEnum(DraftStatusEnum)
  draftStatus?: DraftStatusEnum;
}

export class GetRecommendationDraftQueryDto {
  @ApiPropertyOptional({ description: 'Filter by department ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  departmentId?: number;

  @ApiPropertyOptional({ description: 'Filter by ministry ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  ministryId?: number;

  @ApiPropertyOptional({ description: 'Filter by HLC ID' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  hlcId?: number;

  @ApiPropertyOptional({
    description: 'Filter by current status',
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional({
    description: 'Page number for pagination',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  page?: number = 1;

  @ApiPropertyOptional({ description: 'Number of items per page' })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  limit?: number = 10;

  @ApiPropertyOptional({ description: 'Report Number' })
  @IsOptional()
  @IsString()
  reportNumber?: string;

  @ApiPropertyOptional({
    description: 'Search by name, slug, description, or report number',
  })
  @IsOptional()
  @IsString()
  search?: string;
}

export class ApproveRejectDraftDto {
  @ApiProperty({
    enum: [DraftStatusEnum.APPROVED, DraftStatusEnum.REJECTED],
  })
  @IsEnum(DraftStatusEnum)
  status: DraftStatusEnum;
}

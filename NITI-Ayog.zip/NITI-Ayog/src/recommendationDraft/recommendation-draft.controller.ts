import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RecommendationDraftService } from './recommendation-draft.service';
import {
  ApproveRejectDraftDto,
  GetRecommendationDraftQueryDto,
  RecommendationDraftDto,
} from './dto/recommendation-draft.dto';
import { AuthGuard } from 'src/guards/auth.guard';

@ApiTags('Recommendation Draft')
@Controller({
  path: 'recommendation-draft',
  version: '1',
})
export class RecommendationDraftController {
  constructor(
    private readonly recommendationDraftService: RecommendationDraftService,
  ) {}

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Post('')
  async draftRecommendation(@Req() req, @Body() body: RecommendationDraftDto) {
    await this.recommendationDraftService.draftRecommendation(
      body,
      req?.user?.id,
    );
    return { message: 'Recommendation Drafted Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Get('')
  async getDraftRecommendation(
    @Req() req,
    @Query() query: GetRecommendationDraftQueryDto,
  ) {
    return this.recommendationDraftService.getDraftRecommendation(
      query,
      req?.user?.id,
    );
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put(':id')
  async editDraft(
    @Req() req,
    @Param('id') id: number,
    @Body() body: RecommendationDraftDto,
  ) {
    await this.recommendationDraftService.editDraft(id, body, req.user.id);
    return { message: 'Recommendation Draft Edited Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Put('approve/:id')
  async approveRejectDraft(
    @Req() req,
    @Param('id') id: number,
    @Body() body: ApproveRejectDraftDto,
  ) {
    await this.recommendationDraftService.approveRejectDraft(id, body, req.user.id);
    return { message: 'Recommendation Draft Edited Successfully' };
  }

  @UseGuards(AuthGuard)
  @ApiBearerAuth()
  @Delete(':id')
  async deleteDraft(@Req() req, @Param('id') id: number) {
    await this.recommendationDraftService.deleteDraft(id, req.user.id);
    return { message: 'Recommendation Draft deleted Successfully' };
  }
}

import { Module } from "@nestjs/common";
import { MinistryService } from "./ministry.service";
import { MinistryController } from "./ministry.controller";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Ministry } from "src/entities/ministry.entity";
import { JwtService } from "@nestjs/jwt";

@Module({
  imports: [
    TypeOrmModule.forFeature([Ministry])
  ],
  controllers: [MinistryController],
  providers: [MinistryService, JwtService],
  exports: [],
})
export class MinistryModule {}
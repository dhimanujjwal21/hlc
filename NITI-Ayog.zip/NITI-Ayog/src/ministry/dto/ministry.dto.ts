import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateMinistryDto {
  @ApiProperty({ example: 'Ministry of Education', description: 'Name of the ministry' })
  @IsNotEmpty({ message: 'Name is required' })
  @IsString({ message: 'Name must be a string' })
  name: string;
}


export class UpdateMinistryDto extends PartialType(CreateMinistryDto) {}


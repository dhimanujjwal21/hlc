import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateMinistryDto, UpdateMinistryDto } from './dto/ministry.dto';
import { Ministry } from 'src/entities/ministry.entity';

@Injectable()
export class MinistryService {
  constructor(
    @InjectRepository(Ministry)
    private readonly ministryRepository: Repository<Ministry>,
  ) {}

  async createMinistry(dto: CreateMinistryDto) {
    const nameExists = await this.ministryRepository.findOne({
      where: { name: dto.name },
    });

    if (nameExists) {
      throw new ConflictException('Ministry already exists');
    }
    
    const ministry = this.ministryRepository.create(dto);
    return await this.ministryRepository.save(ministry);
  }

  async findAllMinistry() {
    return await this.ministryRepository.find();
  }

  async updateMinistry(id: number, dto: UpdateMinistryDto) {
    const { name } = dto;
    const ministry: any = await this.ministryRepository.findOne({ where: { id } });
    if (!ministry) throw new NotFoundException('Ministry not found');

    const nameExists = await this.ministryRepository.findOne({
      where: { name },
    });
    if (nameExists && nameExists.id !== id) {
      throw new ConflictException('Ministry already exists');
    }

    ministry.name = name;
    ministry.updatedAt = new Date();
    return await this.ministryRepository.save(ministry);
  }

  async deleteMinistry(id: number) {
    const ministry = await this.ministryRepository.findOne({ where: { id } });
    if (!ministry) throw new NotFoundException('Ministry not found');

    await this.ministryRepository.delete(id);
    return { message: 'Ministry deleted successfully' };
  }
}

import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { MinistryService } from './ministry.service';
import { CreateMinistryDto, UpdateMinistryDto } from './dto/ministry.dto';
import { AuthGuard } from 'src/guards/auth.guard';
import { PermissionsDecorator } from 'src/decorators/permisions.decorator';
import { PermissionsEnum } from 'src/constants/enums';
import { Public } from 'src/decorators/public.decorator';

@ApiTags('Ministry')
@Controller({
  path: 'ministry',
  version: '1',
})
export class MinistryController {
  constructor(private readonly ministryService: MinistryService) {}

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.ADD_MINISTRY)
  @ApiBearerAuth()
  @Post()
  @ApiOperation({ summary: 'Create a new ministry' })
  create(@Body() data: CreateMinistryDto) {
    return this.ministryService.createMinistry(data);
  }

  @Public()
  @Get()
  @ApiOperation({ summary: 'List all ministries' })
  findAllMinistry() {
    return this.ministryService.findAllMinistry();
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.EDIT_MINISTRY)
  @ApiBearerAuth()
  @Put(':id')
  @ApiOperation({ summary: 'Update a ministry by ID' })
  updateMinistry(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateMinistryDto,
  ) {
    return this.ministryService.updateMinistry(id, dto);
  }

  @UseGuards(AuthGuard)
  @PermissionsDecorator(PermissionsEnum.DELETE_MINISTRY)
  @ApiBearerAuth()
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a ministry by ID' })
  deleteMinistry(@Param('id', ParseIntPipe) id: number) {
    return this.ministryService.deleteMinistry(id);
  }
}
